package com.scb.edmhdpif.datatransform;

import groovy.lang.Binding;
import groovy.lang.GroovyShell;
import groovy.lang.Script;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.verifytypes.checker.TransformRule;
import com.scb.edmhdpif.verifytypes.checker.VerifySchema;
import com.scb.edmhdpif.verifytypes.checker.VerifySchemaColumn;

public class DataTransformMapper extends Mapper<WritableComparable<?>, Text, Text, Text> {

    private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
    private String DATA_SEPARATOR = EdmHdpIfConstants.DATA_SEPARATOR;
    private Configuration conf = null;
    private Boolean FIXEDWIDTH;
    private Map<String, VerifySchema> verifySchemaMap = new HashMap<>();

    private Map<String, TransformRule> ruleMap = new HashMap<>();
    private String DATATRANSFORM_OUTPUT_VALID;
    private String DATATRANSFORM_OUTPUT_INVALID;
    private Map<String, Script> gcsMap = new HashMap<>();
    private GroovyShell engine = new GroovyShell();

    private static final Logger logger = Logger.getLogger(DataTransformMapper.class);

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        logger.info("Setup initiated");
        conf = context.getConfiguration();
        COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
                COL_SEPARATOR));
        DATA_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR,
                DATA_SEPARATOR));
        FIXEDWIDTH = Boolean.valueOf(conf.get(EdmHdpIfConstants.EDMHDPIF_FIXWIDTH));

        DATATRANSFORM_OUTPUT_VALID = conf.get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID);
        DATATRANSFORM_OUTPUT_INVALID = conf.get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID);

        logger.info("Setup finished");
    }

    @Override
    protected void map(WritableComparable<?> key, Text value, Context context) throws IOException, InterruptedException {
        String vcolumns[] = value.toString().split(COL_SEPARATOR, -1);
        String tableName = vcolumns[0];
        String rowid = vcolumns[1];

        boolean headerAndFooter = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + ".header") != null;

        String[] columns = null;
        String data = null;
        try {
            data = vcolumns[2];
            // Append data if more than one columns
            for (int i = 3; i < vcolumns.length; i++) {
                data = data + COL_SEPARATOR + vcolumns[i];
            }
            if (headerAndFooter) {
                int type = data.charAt(0);
                switch (type) {
                case 'D':
                    columns = processData(tableName, data);
                    break;
                default:
                    context.write(new Text(DATATRANSFORM_OUTPUT_INVALID + tableName), new Text(tableName
                            + COL_SEPARATOR + rowid + COL_SEPARATOR + data + COL_SEPARATOR
                            + "Record type is not 'Data'"));
                    return;
                }
            } else {
                columns = processData(tableName, data);
            }
        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
            context.write(new Text(DATATRANSFORM_OUTPUT_INVALID + tableName), new Text(tableName + COL_SEPARATOR
                    + rowid + COL_SEPARATOR + data + COL_SEPARATOR + e.getMessage()));
            return;
        }

        StringBuilder text = new StringBuilder(tableName).append(COL_SEPARATOR).append(rowid).append(COL_SEPARATOR);
        boolean nofirst = false;
        for (String c : columns) {
            if (nofirst) {
                text.append(DATA_SEPARATOR);
            } else {
                nofirst = true;
            }
            text.append(c);
        }
        context.write(new Text(DATATRANSFORM_OUTPUT_VALID + tableName), new Text(text.toString()));
    }

    private String[] processData(String tableName, String value) throws Exception {
        VerifySchema schema = verifySchemaMap.get(tableName);

        if (schema == null) {
            String schemaDefinition = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
                    + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA);
            if (schemaDefinition == null) {
                throw new Exception("Schema not defined for table " + tableName);
            }
            schema = new VerifySchema(schemaDefinition, true);
            verifySchemaMap.put(tableName, schema);
        }

        String[] columns;
        if (FIXEDWIDTH) {
            columns = new String[schema.getSchemaColumns().size()];
            int colCount = 0;
            int posCount = 0;
            if (schema.getLineLength() != value.length()) {
                throw new Exception("Line lenght " + value.length() + " differs from expected length "
                        + schema.getLineLength());
            }
            for (VerifySchemaColumn col : schema.getSchemaColumns()) {
                columns[colCount] = value.substring(posCount, posCount + col.getWidth()).trim();
                if (col.getRules() != null && !col.getRules().isEmpty()) {
                    for (String rule : col.getRules()) {
                        columns[colCount] = applyRule(retrieveRule(rule), columns[colCount]);
                    }
                }
                posCount += col.getWidth();
                colCount++;
            }

        } else {
            columns = value.split("\\" + DATA_SEPARATOR, -1);
            int colCount = 0;
            for (VerifySchemaColumn col : schema.getSchemaColumns()) {
                if (col.getRules() != null && !col.getRules().isEmpty()) {
                    for (String rule : col.getRules()) {
                        columns[colCount] = applyRule(retrieveRule(rule), columns[colCount]);
                    }
                }
                colCount++;
            }
        }

        List<Integer> droppedColumns = getDroppedColumns(schema);
        for (Integer drop : droppedColumns) {
            columns = removeFromArray(columns, drop);
        }

        return columns;
    }

    private String[] removeFromArray(String[] array, Integer index) {
        int length = array.length;
        if (index < 0 || index >= length) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Length: " + length);
        }

        String[] result = new String[length - 1];
        System.arraycopy(array, 0, result, 0, index);
        if (index < length - 1) {
            System.arraycopy(array, index + 1, result, index, length - index - 1);
        }

        return result;
    }

    /**
     * Retrieves the rule from configuration
     * 
     * @param ruleName
     *            The rule to retrieve
     * @return A TransformRule object with the rule details
     */
    private TransformRule retrieveRule(String ruleName) {
        TransformRule rule = ruleMap.get(ruleName);
        if (rule == null) {
            rule = new TransformRule();
            String cleanName = ruleName;
            if (ruleName.contains("(")) {
                cleanName = ruleName.substring(0, ruleName.indexOf('('));
            }
            rule.setName(cleanName);
            rule.setParameters(new HashMap<String, String>());
            String params = conf.get("edmhdpif.rules." + cleanName + ".params");
            if (params != null) {
                String[] paramKeys = params.split(",", -1);
                String[] paramValues = null;
                if (ruleName.contains("(")) {
                    String values = ruleName.substring(ruleName.indexOf('(') + 1, ruleName.indexOf(")"));
                    paramValues = values.split(",", -1);
                }
                for (int i = 0; i < paramKeys.length; i++) {
                    if (paramValues != null && paramValues.length > i) {
                        rule.getParameters().put(paramKeys[i], cleanValue(paramValues[i]));
                    } else {
                        rule.getParameters().put(paramKeys[i], null);
                    }
                }
            }

            rule.setCode(conf.get("edmhdpif.rules." + cleanName + ".code"));

            if (rule.getCode() == null) {
                throw new RuntimeException("Rule " + rule.getName() + " not defined.");
            }

            ruleMap.put(ruleName, rule);
        }
        return rule;
    }

    private String cleanValue(String value) {
        String result = value;
        if (result.startsWith("'") && result.endsWith("'")) {
            result = result.substring(1, result.length() - 1);
        }
        if (result.startsWith("\"") && result.endsWith("\"")) {
            result = result.substring(1, result.length() - 1);
        }
        return result;
    }

    /**
     * Applies a rule over certain column data
     * 
     * @param rule
     *            The TransformRule object with the rule details
     * @param data
     *            The data of the column where apply the rule
     * @return The transformed data
     * @throws Exception
     */
    private String applyRule(TransformRule rule, String data) throws Exception {
        if (data == null) {
            return null;
        }
        try {
            // Send parameters to Groovy
            Binding binding = new Binding(rule.getParameters());
            binding.setVariable("DATA", data);
            // Create Groovy shell engine
            if (!gcsMap.containsKey(rule.getName())) {
                gcsMap.put(rule.getName(), engine.parse(rule.getCode()));
            }
            Script script = gcsMap.get(rule.getName());
            script.setBinding(binding);
            script.run();
            Object result = binding.getVariable("result");
            binding = null;
            return result == null ? null : result.toString();
        } catch (Exception e) {
            throw new Exception("Rule: " + rule.getName() + " Data:" + data + " Error:" + e.getMessage());
        }
    }

    private List<Integer> getDroppedColumns(VerifySchema schema) {
        List<Integer> dropList = new ArrayList<>();
        for (int i = 0; i < schema.getSchemaColumns().size(); i++) {
            if (schema.getSchemaColumns().get(i).isDrop()) {
                dropList.add(i);
            }
        }
        Collections.sort(dropList, Collections.reverseOrder());
        return dropList;
    }
}