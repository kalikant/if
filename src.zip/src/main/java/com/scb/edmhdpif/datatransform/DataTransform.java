package com.scb.edmhdpif.datatransform;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineSequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.LazyOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.PathFinder;
import com.scb.edmhdpif.lib.PathFinder.MatchType;
import com.scb.edmhdpif.lib.input.CFInputFormat;

public class DataTransform extends Configured implements Tool {

	private static final Logger logger = Logger.getLogger(DataTransform.class);

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new DataTransform(), args);
		System.exit(res);
	}

	@Override
	public int run(String[] args) throws IllegalStateException, ClassNotFoundException, InstantiationException,
			IllegalAccessException, IOException {

		Configuration conf = super.getConf();

		String oozieConfigurationLocation = System.getProperty("oozie.action.conf.xml");
		if (oozieConfigurationLocation != null) {
			logger.info("Loading Oozie configuration from " + oozieConfigurationLocation);
			conf.addResource(new Path(oozieConfigurationLocation));
		}

		EdmHdpIfCommon.checkRequiredParameters(conf,
				new String[] { EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH,
						EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE,
						EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION,
						EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_VALID_DATABASE,
						EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_INVALID_DATABASE,
						EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_VALID_TABLE,
						EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_INVALID_TABLE,
						EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_VALID_PARTITION,
						EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_INVALID_PARTITION });

		Job job;
		try {
			job = Job.getInstance(conf, "EdmHdpIf-DataTransform");
		} catch (IOException e) {
			e.printStackTrace();
			return 1;
		}

		job.setJarByClass(DataTransform.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(DataTransformMapper.class);
		job.setReducerClass(DataTransformReducer.class);

		job.setInputFormatClass(CFInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		// Delete output directory
		FileSystem fileSystem = FileSystem.get(conf);
		Path outputPath = new Path(conf.get(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH));
		logger.info("Output path set to " + outputPath);
		EdmHdpIfCommon.deletePath(fileSystem, outputPath + "/");
		job.setOutputFormatClass(LazyOutputFormat.class);
		LazyOutputFormat.setOutputFormatClass(job, TextOutputFormat.class);
		TextOutputFormat.setOutputPath(job, outputPath);

		String hiveWarehouse = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/");
		String inputDatabase = conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "");
		String inputTable = conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "");
		String inputPartition = EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, ""));
		Path inputPath = new Path(hiveWarehouse + "/" + inputDatabase + "/" + inputTable + "/" + inputPartition);

		// Output paths
		Path validOutputPath = new Path(
				hiveWarehouse + "/"
						+ conf.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_VALID_DATABASE) + "/" + conf
								.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_VALID_TABLE)
						+ "/" + EdmHdpIfCommon
								.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_VALID_PARTITION)));
		Path invalidOutputPath = new Path(
				hiveWarehouse + "/"
						+ conf.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_INVALID_DATABASE) + "/" + conf
								.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_INVALID_TABLE)
						+ "/" + EdmHdpIfCommon
								.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_INVALID_PARTITION)));
		String validOutput = Path.getPathWithoutSchemeAndAuthority(validOutputPath) + "/";
		String invalidOutput = Path.getPathWithoutSchemeAndAuthority(invalidOutputPath) + "/";
		logger.info("Valid records path: " + validOutput);
		logger.info("Invalid records path: " + invalidOutput);
		String tablePrefix = conf.get(EdmHdpIfConstants.EDMHDPIF_INDIVIDUAL_TABLEPREFIX);

		List<Path> outputPathList = new ArrayList<Path>();
		try {
			// If it's a rerun, only load the table to rerun
			final String rerunTables = conf.get(EdmHdpIfConstants.EDMHDPIF_RERUN_TABLE);
			if (rerunTables == null) {
				if (fileSystem.exists(inputPath)) {
					logger.info("Adding input path: " + inputPath);
					MultipleInputs.addInputPath(job, inputPath, CombineSequenceFileInputFormat.class);
				} else {
					logger.info("Input path doesn't exist, skipping: " + inputPath);
				}
				/*
				 * Output directories to delete
				 */
				// Open path
				PathFinder validPath = new PathFinder(conf, validOutput);
				validPath.setTableName(tablePrefix);
				validPath.setTableMatchType(MatchType.STARTSWITH);
				validPath.setPartition(EdmHdpIfCommon
						.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_VALID_PARTITION)));
				outputPathList.addAll(validPath.getFiles());
				// Non open path
				PathFinder invalidPath = new PathFinder(conf, invalidOutput);
				invalidPath.setTableName(tablePrefix);
				invalidPath.setTableMatchType(MatchType.STARTSWITH);
				invalidPath.setPartition(EdmHdpIfCommon
						.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_INVALID_PARTITION)));
				outputPathList.addAll(invalidPath.getFiles());
			} else {
				logger.info("RERUN of table(s) " + rerunTables);
				String[] names = rerunTables.split(",");
				for (String table : names) {
					PathFinder inputPathFinder = new PathFinder(conf,
							hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, ""));
					inputPathFinder.setTableName(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, ""));
					inputPathFinder.setPartition(
							EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "")));
					inputPathFinder.setFileName(table + "-");

					for (Path file : inputPathFinder.getFiles()) {
						logger.info("Adding input file: " + file);
						MultipleInputs.addInputPath(job, file, CombineSequenceFileInputFormat.class);
					}
					outputPathList
							.add(new Path(validOutput + table + "/"
									+ EdmHdpIfCommon.getPartition(
											conf.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_VALID_PARTITION, ""))
							+ "/"));
					outputPathList
							.add(new Path(invalidOutput + table + "/"
									+ EdmHdpIfCommon.getPartition(
											conf.get(EdmHdpIfConstants.EDMHDPIF_DATATRANSFORM_INVALID_PARTITION, ""))
							+ "/"));
				}

				// If no input paths set (e.g. rerun for a table that has no
				// file), then set
				// input path to empty directory so that job succeeds
				if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
					EdmHdpIfCommon.setEmptyInputPath(job, fileSystem, outputPath);
				}
			}
			job.getConfiguration().set(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID, validOutput);
			job.getConfiguration().set(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID, invalidOutput);

			// Delete output paths
			for (Path deletePath : outputPathList) {
				EdmHdpIfCommon.deletePath(fileSystem, deletePath.toString());
			}

			MultipleOutputs.addNamedOutput(job, "output", SequenceFileOutputFormat.class, NullWritable.class,
					Text.class);
			MultipleOutputs.addNamedOutput(job, "rowcounts", SequenceFileOutputFormat.class, NullWritable.class,
					Text.class);

			if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
				// No input paths
				logger.warn("Job not launched: no input paths");
				return 0;
			}
			return (job.waitForCompletion(true) ? 0 : 1);
		} catch (ClassNotFoundException | IOException | InterruptedException e) {
			e.printStackTrace();
			return 1;
		}
	}
}
