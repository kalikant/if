package com.scb.edmhdpif.verifytypes.checker;

import java.util.HashMap;
import java.util.Map;

public class TransformRule {
	private String name;
	private Map<String, String> parameters = new HashMap<>();
	private String code;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, String> getParameters() {
		return parameters;
	}

	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "TransformRule [" + (name != null ? "name=" + name + ", " : "")
				+ (parameters != null ? "parameters=" + parameters + ", " : "") + (code != null ? "code=" + code : "")
				+ "]";
	}
}
