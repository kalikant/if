package com.scb.edmhdpif.verifytypes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineSequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.LazyOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.PathFinder;
import com.scb.edmhdpif.lib.PathFinder.MatchType;

public class VerifyTypes extends Configured implements Tool {

	private static final Logger logger = Logger.getLogger(VerifyTypes.class);

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new VerifyTypes(), args);
		System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {

		Configuration conf = super.getConf();

		String oozieConfigurationLocation = System.getProperty("oozie.action.conf.xml");
		if (oozieConfigurationLocation != null) {
			logger.info("Loading Oozie configuration from " + oozieConfigurationLocation);
			conf.addResource(new Path(oozieConfigurationLocation));
		}

		EdmHdpIfCommon.checkRequiredParameters(conf,
				new String[] { EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH,
						EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE,
						EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS,
						EdmHdpIfConstants.EDMHDPIF_INDIVIDUAL_TABLEPREFIX,
						EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_ARGS,
						EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_ONETABLE,
						EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_DATABASE,
						EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_DATABASE,
						EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_DATABASE,
						EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_PARTITION,
						EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_PARTITION,
						EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_PARTITION});

		// Read JSON arguments
		try {
			JSONObject argumentsObject = new JSONObject(conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_ARGS));
			Iterator<?> keys = argumentsObject.keys();
			while (keys.hasNext()) {
				String key = (String) keys.next();
				System.out.println("Argument key: " + key + " value:" + argumentsObject.getString(key));
				conf.set(key, argumentsObject.getString(key));
			}
		} catch (JSONException e) {
			logger.error("Can't read arguments: " + e.getMessage());
			e.printStackTrace();
		}

		if (conf.get(EdmHdpIfConstants.EDMHDPIF_EOD_MARKER) != null) {
			logger.info("Found EOD Marker: " + conf.get(EdmHdpIfConstants.EDMHDPIF_EOD_MARKER));
		}

		// Create job
		Job job;
		try {
			job = Job.getInstance(conf, "EdmHdpIf-VerifyTypes");
		} catch (IOException e) {
			e.printStackTrace();
			return 1;
		}

		job.setJarByClass(VerifyTypes.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(VerifyTypesMapper.class);
		job.setReducerClass(VerifyTypesReducer.class);

		// Delete output directory
		FileSystem fileSystem = FileSystem.get(conf);
		Path outputPath = new Path(conf.get(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH));
		logger.info("Output path set to " + outputPath);
		EdmHdpIfCommon.deletePath(fileSystem, outputPath + "/");
		job.setOutputFormatClass(LazyOutputFormat.class);
		LazyOutputFormat.setOutputFormatClass(job, TextOutputFormat.class);
		TextOutputFormat.setOutputPath(job, outputPath);

		String hiveWarehouse = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/");
		Path inputPath = new Path(hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "") + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "") + "/"
				+ EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "")));

		// Output paths
		String validOutput;
		String invalidOutput;
		String warnOutput;
		boolean oneTable = Boolean.parseBoolean(conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_ONETABLE));
		String tablePrefix = conf.get(EdmHdpIfConstants.EDMHDPIF_INDIVIDUAL_TABLEPREFIX);
		if (oneTable) {
			EdmHdpIfCommon.checkRequiredParameters(conf,
					new String[] { EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_TABLE,
							EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_TABLE,EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_TABLE });

			Path validOutputPath = new Path(hiveWarehouse + "/"
					+ conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_DATABASE, "") + "/"
					+ conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_TABLE, "") + "/" + EdmHdpIfCommon
							.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_PARTITION, "")));
			Path invalidOutputPath = new Path(
					hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_DATABASE, "")
							+ "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_TABLE, "") + "/"
							+ EdmHdpIfCommon.getPartition(
									conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_PARTITION, "")));
			Path warnOutputPath = new Path(
					hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_DATABASE, "")
							+ "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_TABLE, "") + "/"
							+ EdmHdpIfCommon.getPartition(
							conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_PARTITION, "")));

			validOutput = Path.getPathWithoutSchemeAndAuthority(validOutputPath) + "/";
			invalidOutput = Path.getPathWithoutSchemeAndAuthority(invalidOutputPath) + "/";
			warnOutput = Path.getPathWithoutSchemeAndAuthority(warnOutputPath) + "/";
		} else {
			Path validOutputPath = new Path(
					hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_DATABASE, ""));
			Path invalidOutputPath = new Path(
					hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_DATABASE, ""));
			Path warnOutputPath = new Path(
					hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_DATABASE, ""));

			validOutput = Path.getPathWithoutSchemeAndAuthority(validOutputPath) + "/";
			invalidOutput = Path.getPathWithoutSchemeAndAuthority(invalidOutputPath) + "/";
			warnOutput = Path.getPathWithoutSchemeAndAuthority(warnOutputPath) + "/";
		}

		List<Path> outputPathList = new ArrayList<Path>();
		try {
			// If it's a rerun, only load the table to rerun
			final String rerunTables = conf.get(EdmHdpIfConstants.EDMHDPIF_RERUN_TABLE);
			if (rerunTables == null) {
				if (fileSystem.exists(inputPath)) {
					logger.info("Adding input path: " + inputPath);
					MultipleInputs.addInputPath(job, inputPath, CombineSequenceFileInputFormat.class);
				} else {
					logger.info("Input path doesn't exist, skipping: " + inputPath);
				}
				if (oneTable) {
					outputPathList.add(new Path(validOutput));
					outputPathList.add(new Path(invalidOutput));
					outputPathList.add(new Path(warnOutput));
				} else {
					/*
					 * Output directories to delete
					 */
					// Open path
					PathFinder validPath = new PathFinder(conf, validOutput);
					validPath.setTableName(tablePrefix);
					validPath.setTableMatchType(MatchType.STARTSWITH);
					validPath.setPartition(EdmHdpIfCommon
							.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_PARTITION)));
					outputPathList.addAll(validPath.getFiles());
					// Non open path
					PathFinder invalidPath = new PathFinder(conf, invalidOutput);
					invalidPath.setTableName(tablePrefix);
					invalidPath.setTableMatchType(MatchType.STARTSWITH);
					invalidPath.setPartition(EdmHdpIfCommon
							.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_PARTITION)));
					outputPathList.addAll(invalidPath.getFiles());

					PathFinder warnPath=new PathFinder(conf, warnOutput);
					warnPath.setTableName(tablePrefix);
					warnPath.setTableMatchType(MatchType.STARTSWITH);
					warnPath.setPartition(EdmHdpIfCommon
							.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_PARTITION)));
					outputPathList.addAll(warnPath.getFiles());
				}
			} else {
				logger.info("RERUN of table(s) " + rerunTables);
				String[] names = rerunTables.split(",");
				for (String table : names) {
					PathFinder inputPathFinder = new PathFinder(conf,
							hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, ""));
					inputPathFinder.setTableName(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, ""));
					inputPathFinder.setPartition(
							EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "")));
					inputPathFinder.setFileName(table + "-");

					for (Path file : inputPathFinder.getFiles()) {
						logger.info("Adding input file: " + file);
						MultipleInputs.addInputPath(job, file, CombineSequenceFileInputFormat.class);
					}
					if (oneTable) {
						outputPathList.add(new Path(validOutput + table));
						outputPathList.add(new Path(invalidOutput + table));
						outputPathList.add(new Path(warnOutput + table));
					} else {
						outputPathList
								.add(new Path(validOutput + table + "/"
										+ EdmHdpIfCommon.getPartition(conf
												.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_PARTITION, ""))
								+ "/"));
						outputPathList
								.add(new Path(invalidOutput + table + "/"
										+ EdmHdpIfCommon.getPartition(conf.get(
												EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_PARTITION, ""))
								+ "/"));
						outputPathList
								.add(new Path(warnOutput + table + "/"
										+ EdmHdpIfCommon.getPartition(conf.get(
										EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_PARTITION, ""))
										+ "/"));
					}
				}

				// If no input paths set (e.g. rerun for a table that has no
				// file), then set
				// input path to empty directory so that job succeeds
				if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
					EdmHdpIfCommon.setEmptyInputPath(job, fileSystem, outputPath);
				}
			}
			job.getConfiguration().set(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_VALID, validOutput);
			job.getConfiguration().set(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_INVALID, invalidOutput);
			job.getConfiguration().set(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_WARN, warnOutput);

			// Delete output paths
			for (Path deletePath : outputPathList) {
				EdmHdpIfCommon.deletePath(fileSystem, deletePath.toString());
			}

			MultipleOutputs.addNamedOutput(job, "data", SequenceFileOutputFormat.class, NullWritable.class, Text.class);
			MultipleOutputs.addNamedOutput(job, "rowcounts", SequenceFileOutputFormat.class, NullWritable.class,
					Text.class);

			if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
				// No input paths
				logger.warn("Job not launched: no input paths");
				return 0;
			}
			return (job.waitForCompletion(true) ? 0 : 1);
		} catch (ClassNotFoundException | IOException | InterruptedException e) {
			e.printStackTrace();
			return 1;
		}
	}
}

