package com.scb.edmhdpif.verifytypes;

import java.io.IOException;
import java.nio.channels.ClosedChannelException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;

public class VerifyTypesReducer extends Reducer<Text, Text, NullWritable, Text> {

	private MultipleOutputs<NullWritable, Text> mout;
	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
	private String DATA_SEPARATOR = EdmHdpIfConstants.DATA_SEPARATOR;

	private final Map<String, String> rowCountPathsMap = new HashMap<>();
	private Configuration conf = null;

	private String rowCountPath = null;
	private static final Logger logger = Logger.getLogger(VerifyTypesReducer.class);
	private final String tcStartTime = EdmHdpIfCommon.getUnixTime();

	private Context context;

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info("Setup initiated");

		this.context = context;
		conf = context.getConfiguration();
		COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
				COL_SEPARATOR));
		DATA_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR,
				DATA_SEPARATOR));

		rowCountPath = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "") + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_ROWCOUNTS_DATABASE, "") + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_ROWCOUNTS_TABLE, "") + "/"
				+ EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_ROWCOUNTS_PARTITION, ""));
		logger.info("Setup finished");
	}

	@Override
	protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

		// Open outputs
		mout = new MultipleOutputs<NullWritable, Text>(context);

		String outpaths[] = key.toString().split("/");
		// <root>/warehouse_path/database/outputTable/partition/ebbsTable
		// warehouse_path can be of any nesting but rest are affixed by mapper
		if (outpaths.length < 6) {
			throw new RuntimeException("Incorrect write path: " + key.toString());
		}
		final String database = outpaths[outpaths.length - 4];
		final String outputTable = outpaths[outpaths.length - 3];

		/*
		 * Write to output path directory, using the file with the table name.
		 * This file will be overwrite later if we rerun the batch for this
		 * table.
		 */
		Path writePath = new Path(key.toString());
		String tableName = writePath.getName();

		int writeCount = 0;
		for (Text t : values) {
			writeCount++;
			mout.write("data", NullWritable.get(), t, writePath.toString());
		}

		// Force write to save memory
		try {
			mout.close();
		} catch (ClosedChannelException e) {
			// If we use compression, then the channel could be already closed.
			// Ignore the exception
		}

		// Write rowcount
		writeRowCount(database, outputTable, writeCount, tableName);
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		// Write row count
		mout = new MultipleOutputs<NullWritable, Text>(context);

		// Write row count
		Text writeValue = new Text();
		String fileName = rowCountPath + "/" + context.getJobName() + "-" + UUID.randomUUID();
		for (String row : rowCountPathsMap.values()) {
			String[] splittedRow = row.split(COL_SEPARATOR, -1);
			String database = splittedRow[0];
			String outputtable = splittedRow[1];
			String count = splittedRow[2];
			String table = splittedRow[3];
			logger.info("Adding row count information for table " + database + "." + outputtable + " for " + table
					+ " Count: " + count + " File: " + fileName);
			writeValue.set(row);
			mout.write("rowcounts", NullWritable.get(), writeValue, fileName);
		}

		// Close outputs
		try {
			mout.close();
		} catch (ClosedChannelException e) {
			// If we use compression, then the channel could be already closed.
			// Ignore the exception
		}
	}

	/**
	 * Write a row count line. The row count is wrote in the cleanup method,
	 * this method stores the count in a Map, or modifies the stored line if
	 * already exists.
	 * 
	 * @param database
	 *            Database field of the RowCount table.
	 * @param outputTable
	 *            Table field of the RowCount table.
	 * @param writeCount
	 *            Row count to be set or added.
	 * @param tableName
	 *            The functional table name
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void writeRowCount(String database, String outputTable, int writeCount, String tableName)
			throws IOException, InterruptedException {

		// Use composite key since tableName alone counts rowid + rowhist
		// together
		String composite = new StringBuilder(database).append("#").append(outputTable).append("#").append(tableName)
				.toString();
		String row = rowCountPathsMap.get(composite);
		if (row == null) {
			row = new StringBuilder(database).append(COL_SEPARATOR).append(outputTable).append(COL_SEPARATOR)
					.append(writeCount).append(COL_SEPARATOR).append(tableName).append(COL_SEPARATOR)
					.append(tcStartTime).append(COL_SEPARATOR).append(context.getJobName()).append(COL_SEPARATOR)
					.append(context.getTaskAttemptID()).toString();
		} else {
			Integer count = Integer.valueOf(row.split(COL_SEPARATOR, -1)[2]);
			row = new StringBuilder(database).append(COL_SEPARATOR).append(outputTable).append(COL_SEPARATOR)
					.append((count + writeCount)).append(COL_SEPARATOR).append(tableName).append(COL_SEPARATOR)
					.append(tcStartTime).append(COL_SEPARATOR).append(context.getJobName()).append(COL_SEPARATOR)
					.append(context.getTaskAttemptID()).toString();
		}
		rowCountPathsMap.put(composite, row);
	}
}