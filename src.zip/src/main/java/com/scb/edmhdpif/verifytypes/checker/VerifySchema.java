package com.scb.edmhdpif.verifytypes.checker;

import com.scb.edmhdpif.lib.EdmHdpIfColumnType;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VerifySchema {

    private final List<VerifySchemaColumn> schemaColumns = new ArrayList<VerifySchemaColumn>();

    public VerifySchema(String colSchema, boolean includeDropColumns) {
        if (colSchema == null) {
            throw new RuntimeException("Null column schema");
        }

        String cols[] = colSchema.split(EdmHdpIfConstants.PROP_LINE_SEPARATOR);
        for (String col : cols) {
            VerifySchemaColumn column = new VerifySchemaColumn(col);
            if (includeDropColumns || !column.isDrop()) {
                schemaColumns.add(column);
            }
        }
    }

    public String verify(String value, String data_separator, EdmHdpIfColumnType row) {
        String column[] = value.split("\\" + data_separator, -1);

        // Check number of columns
        if (column.length != schemaColumns.size()) {
            return "Unexpected number of columns. Expected: " + schemaColumns.size() + "; received: " + column.length;
        }

        // Check column by column
        StringBuilder error = new StringBuilder();
        StringBuilder data_mod = new StringBuilder();
        String e = null;
        int col = 0;
        for (VerifySchemaColumn vsc : schemaColumns) {
            if (vsc.isDrop()) {
                continue;
            }
            e = vsc.verify(getTrimmedNumber(column[col], vsc.getDatatype()));
            if (e.toLowerCase().contains("ERROR: ".toLowerCase())) {
                if (error.length() == 0) {
                    error.append(e);
                } else {
                    error.append(data_separator).append(e);
                }

                error.toString();
            } else if (e.startsWith("WARN")) {
                String data[] = e.split("\\$: ");
                column[col] = data[data.length - 1];
                if (error.length() == 0) {
                    error.append(e);
                } else {
                    error.append(data_separator).append(e);
                }
            } else {
                column[col] = e;
            }

            data_mod.append(column[col]);

            if (col < column.length - 1) {

                data_mod.append(data_separator);
            }
            col++;
        }
        row.setData(data_mod.toString());

        return error.toString();
    }

    public List<VerifySchemaColumn> getSchemaColumns() {
        return schemaColumns;
    }

    /**
     * Get the index of the key columns of a table.
     * 
     * @param keycols
     *            The name of the column keys.
     * @return An array with the indexes.
     * @throws IOException
     */
    public Integer[] getKeyColNumbers(String keycols) throws IOException {

        String keycolumns[] = keycols.split(",", -1);
        Integer keycolNumbers[] = new Integer[keycolumns.length];

        // Column names into hashmap
        Map<String, Integer> colPositions = new HashMap<>();
        for (int i = 0; i < schemaColumns.size(); i++) {
            colPositions.put(schemaColumns.get(i).getName(), i);
        }

        // Search key columns in the hashmap
        for (int j = 0; j < keycolumns.length; j++) {
            String keyName = keycolumns[j].trim();

            if (colPositions.containsKey(keyName)) {
                keycolNumbers[j] = colPositions.get(keyName);
            } else {
                throw new RuntimeException("key column '" + keyName + "' not found");
            }
        }
        return keycolNumbers;
    }

    public String getTrimmedNumber(String val, String datatype) {
        // Fix for HIVE-7373 (https://issues.apache.org/jira/i#browse/HIVE-7373)

        // Fix for HIVE-7373 in INT types
        // (https://issues.apache.org/jira/i#browse/HIVE-7373)
        if (handleLeadTrailZeros(val, datatype)) {
            val = val.indexOf(".") < 0 ? val : val.replaceAll("0*$", "").replaceAll("\\.$", "");
            if(val.contains(".") && (val.indexOf(".")==1))
                    return val.replaceFirst("^0+(?!$)","0");
            else
                return val.replaceFirst("^0+(?!$)", "");
        }
        if (hive7373Check(val, datatype)) {
            val = val.replaceAll("0*$", "").replaceAll("\\.$", "");
        }
        return val;
    }

    /**
     * DECIMAL with precision is not handled correctly when there are trailing
     * zeros Even though HIVE-7373 is marked as Resolved in Hive-0.14, a comment
     * later confirms that the resolution has been reverted by HIVE-8745
     * 
     * @param string
     *            The string to verify.
     * @param datatype
     *            The expected datatype of the string.
     * @return
     */
    private boolean hive7373Check(String string, String datatype) {
        return datatype.startsWith("DECIMAL") && string.indexOf('.') >= 0 && string.endsWith("0");
    }

    private boolean handleLeadTrailZeros(String string, String datatype) {
        if (!string.startsWith("0")) {
            return false;
        }
        return (datatype.equals("TINYINT") || datatype.startsWith("SMALLINT") || datatype.startsWith("INT")|| datatype.startsWith("BIGINT") || datatype.startsWith("DECIMAL"));

    }

    public int getLineLength() {
        int total = 0;
        for (VerifySchemaColumn col : schemaColumns) {
            total += col.getWidth();
        }
        return total;
    }
}
