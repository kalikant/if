package com.scb.edmhdpif.verifytypes.checker;

import org.apache.hadoop.hive.serde2.io.DateWritable;
import org.apache.hadoop.hive.serde2.lazy.ByteArrayRef;
import org.apache.hadoop.hive.serde2.lazy.LazyFactory;
import org.apache.hadoop.hive.serde2.lazy.LazyPrimitive;
import org.apache.hadoop.hive.serde2.lazy.objectinspector.primitive.AbstractPrimitiveLazyObjectInspector;
import org.apache.hadoop.hive.serde2.lazy.objectinspector.primitive.LazyPrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.typeinfo.PrimitiveTypeInfo;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfoFactory;
import org.apache.hadoop.io.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VerifySchemaColumn {

    private String name;
    private String datatype;
    private String comment;
    private boolean notNull = false;
    private boolean drop = false;
    private Integer width = 0;
    private boolean Default = false;
    private String defaultValue = null;
    private Map<String, String> defaultColumnValue = new HashMap<String, String>();
    private List<String> rules = new ArrayList<>();

    private final ByteArrayRef _byteRef = new ByteArrayRef();

    private final Pattern pattern = Pattern.compile("([^\\s]+)\\s+([^\\s]+)");
    private final String otherThanCloseParenthesis = " [^\\)] ";
    private final String paranthesisString = String.format(" \\( %s* \\) ", otherThanCloseParenthesis);
    private final String regex = String.format("(?x)" + // enable comments,
                                                        // ignore white spaces
            "," + // match a comma
            "(?=" + // start positive look ahead
            "(" + // start group 1
            "%s*" + // match 'otherThanParenthesis' zero or more times
            "%s" + // match 'parenthesisString'
            ")*" + // end group 1 and repeat it zero or more times
            "%s* " + // match 'otherThanParenthesis'
            "$ " + // match the end of the string
            ") ", // stop positive look ahead
            otherThanCloseParenthesis, paranthesisString, otherThanCloseParenthesis);

    public VerifySchemaColumn(String columnLine) {

        if (columnLine == null) {
            throw new RuntimeException("Null column schema");
        }
        Matcher m = pattern.matcher(columnLine);
        if (!m.find()) {
            throw new RuntimeException("Invalid column schema: " + columnLine);
        }
        name = m.group(1);
        datatype = m.group(2);
        if (columnLine.contains("NOT NULL")) {
            notNull = true;
        }
        // Definition words
        String[] words = columnLine.split("\\s+");
        for (int i = 0; i < words.length; i++) {
            if ("DROP".equals(words[i])) {
                drop = true;
                continue;
            }
            if ("WIDTH".equals(words[i])) {
                i++;
                width = Integer.valueOf(words[i]);
                continue;
            }
            if ("RULES".equals(words[i])) {
                i++;
                String[] ruleNames = words[i].split(regex);
                for (String ruleName : ruleNames) {
                    rules.add(ruleName);
                }
                continue;
            }
            if ("DEFAULT".equals(words[i])) {
                i++;

                defaultValue = words[i];
                // Trim quotes
                if ((defaultValue.startsWith("'") && defaultValue.endsWith("'"))
                        || (defaultValue.startsWith("\"") && defaultValue.endsWith("\""))) {
                    defaultValue = defaultValue.substring(1, defaultValue.length() - 1);
                }
                defaultColumnValue.put(name, defaultValue);
                Default = true;

            }
        }

        // Decimal part with decimal
        if (datatype.startsWith("DECIMAL") && !datatype.contains(",")) {
            datatype = datatype.replace(")", ",0)");
        }
    }

    public String getName() {
        return name;
    }

    public String getDatatype() {
        return datatype;
    }

    public boolean isNotNull() {
        return notNull;
    }

    public boolean hasDefault() {
        return Default;
    }

    public String getComment() {
        return comment;
    }

    public boolean isDrop() {
        return drop;
    }

    public Integer getWidth() {
        return width;
    }

    public String getDefaultValue(String col) {
        Set<String> keys = defaultColumnValue.keySet();
        Iterator<String> itr = keys.iterator();

        String key;
        String value = null;
        while (itr.hasNext()) {
            key = itr.next();
            if (key.equals(col))
                value = defaultColumnValue.get(key);
        }
        return value;
    }

    /**
     * Method used in VerifyTypesTest
     **/
    public void setDefaultValue(String name, String value) {
        defaultColumnValue.put(name, value);
        notNull = true; // setting "TRUE" for testing purpose-> when used
                        // elsewhere in the code see if this is a necessary
                        // assumption
    }

    public List<String> getRules() {
        return rules;
    }

    /**
     * Performs the verification of the string.
     * 
     * @param string
     *            The string to verify.
     * @return null, if the string is valid, or a String describing the error,
     *         if the string is invalid.
     * @throws RuntimeException
     */
    public String verify(String string) throws RuntimeException {
        String ret_val = string;
        if (string == null || string.isEmpty()) {
            if (isNotNull()) {
                if (defaultColumnValue.get(name) != null) {
                    string = defaultColumnValue.get(name);
                    ret_val = "WARNING: Replacing NULL value with DEFAULT value for " + name + " Data$: " + string;
                } else
                    ret_val = "ERROR: NULL value for NOT NULL column " + name + " Null? " + isNotNull()
                            + " HasDefault? " + hasDefault();
            } else {
                return "";
            }
        }

        String dataTypeValidation = isValOfType(string, datatype);
        if (dataTypeValidation == null) { // Valid
            return ret_val;
        } else {
            if (defaultColumnValue.get(name) != null) {
                string = defaultColumnValue.get(name);
                return "WARNING: Replacing NULL value with DEFAULT value for " + name + dataTypeValidation + " Data$: "
                        + string;
            } else {
                return "ERROR: " + dataTypeValidation;
            }
        }
    }

    /**
     * Checks the string with its Hive data type object.
     * 
     * @param val
     *            The string to verify.
     * @param datatype
     *            The Hive data type.
     * @return null, if the string is valid, or a String describing the error,
     *         if the string is invalid.
     */
    private String isValOfType(String val, String datatype) {
        Text t = new Text(val);
        _byteRef.setData(t.getBytes());

        // capture and rethrow with descriptive error msg, if type not
        // recognized
        PrimitiveTypeInfo p;
        try {
            p = TypeInfoFactory.getPrimitiveTypeInfo(datatype.toLowerCase());
        } catch (RuntimeException e) {
            throw new RuntimeException("'" + datatype + "' not recognized" + ", only Hive Primitive types supported");
        }

        // this will get object inspector already cached in this execution;
        // if not, will create and add to cache only as many objects as there
        // are distinct types are created
        AbstractPrimitiveLazyObjectInspector<?> oi = LazyPrimitiveObjectInspectorFactory.getLazyObjectInspector(p);
        LazyPrimitive<?, ?> lp = LazyFactory.createLazyPrimitiveClass(oi);
        lp.init(_byteRef, 0, t.getLength());

        String d = lp.toString();
        if (d == null || !d.equals(val)) {
            // HIVE-8102: Partitions of type 'date' behave incorrectly with
            // daylight saving time
            // If the type if DateWritable then do our own checking to avoid
            // that bug of Hive 0.13. The bug is fixed in Hive 0.14 so if using
            // Hive 0.14 this code is no longer needed
            if (lp.getWritableObject() instanceof DateWritable) {
                if (hive8102Check(val)) {
                    return null;
                }
            }
            return "'" + val + "' for column '" + name + "' not of type " + datatype + ", type enforced='" + d + "'";
        }

        return null;
    }

    /**
     * HIVE-8102: Partitions of type 'date' behave incorrectly with daylight
     * saving time. If the type if DateWritable then do our own checking to
     * avoid that bug of Hive 0.13. The bug is fixed in Hive 0.14 so if using
     * Hive 0.14 this code is no longer needed.
     * 
     * @param d
     *            The date to check.
     * @return True if the date is correct, false otherwise.
     */
    private boolean hive8102Check(String d) {
        final long MILLIS_PER_DAY = TimeUnit.DAYS.toMillis(1);
        final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        final TimeZone LOCAL_TIMEZONE = Calendar.getInstance().getTimeZone();

        java.sql.Date sqlDate = new java.sql.Date(0);
        try {
            sqlDate.setTime(formatter.parse(d).getTime());
        } catch (ParseException e) {
            return false;
        }

        // Date to Days
        long millisLocal = sqlDate.getTime();
        long millisUtc = millisLocal + LOCAL_TIMEZONE.getOffset(millisLocal);
        // Hive check
        int j;
        if (millisUtc >= 0L) {
            j = (int) (millisUtc / MILLIS_PER_DAY);
        } else {
            j = (int) ((millisUtc - 86399999) / MILLIS_PER_DAY);
        }
        // Non-hive check
        // int j = (int) Math.round((double) millisUtc / MILLIS_PER_DAY);

        // Days to millis
        long millisUtcBack = j * MILLIS_PER_DAY;
        long tmpTime = millisUtcBack - LOCAL_TIMEZONE.getOffset(millisUtcBack);
        long milis = millisUtcBack - LOCAL_TIMEZONE.getOffset(tmpTime);

        sqlDate.setTime(milis);

        return d.equals(formatter.format(sqlDate));
    }

}
