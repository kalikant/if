package com.scb.edmhdpif.verifytypes;

import com.scb.edmhdpif.lib.EdmHdpIfColumnType;
import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.verifytypes.checker.VerifySchema;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class VerifyTypesMapper extends Mapper<WritableComparable<?>, Text, Text, Text> {
    private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
    private String DATA_SEPARATOR = EdmHdpIfConstants.DATA_SEPARATOR;

    private final Map<String, VerifySchema> verifySchemaMap = new HashMap<>();
    private Configuration conf = null;
    private String MULTIPLETABLE_VERIFYTYPES_SUFFIX;
    private String MULTIPLETABLE_INVALIDTYPES_SUFFIX;
    private String MULTIPLETABLE_WARNTYPES_SUFFIX;
    private boolean ONETABLE;
    private static final Logger logger = Logger.getLogger(VerifyTypesMapper.class);
    private String EODMARKER = null;
    private String VERIFYTYPES_OUTPUT_VALID = null;
    private String VERIFYTYPES_OUTPUT_INVALID = null;
    private String VERIFYTYPES_OUTPUT_WARN = null;
    private Boolean CDC = null;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        logger.info(this.getClass() + " setup initiated for task " + context.getTaskAttemptID());
        conf = context.getConfiguration();
        COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
                COL_SEPARATOR));
        DATA_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR,
                DATA_SEPARATOR));
        CDC = Boolean.parseBoolean(conf.get(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS));

        conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);
        conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, DATA_SEPARATOR);
        conf.setBoolean(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS_BOOLEAN, CDC);

        VERIFYTYPES_OUTPUT_VALID = conf.get(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_VALID);
        VERIFYTYPES_OUTPUT_INVALID = conf.get(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_INVALID);
        VERIFYTYPES_OUTPUT_WARN = conf.get(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_WARN);

        EODMARKER = conf.get(EdmHdpIfConstants.EDMHDPIF_EOD_MARKER);
        if (EODMARKER != null) {
            logger.info("EOD marker found: " + EODMARKER);
        }

        ONETABLE = "true".equalsIgnoreCase(conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_ONETABLE));
        logger.info("Onetable: " + conf.get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_ONETABLE));
        if (ONETABLE) {
            logger.info("Writing to output valid directory: " + VERIFYTYPES_OUTPUT_VALID);
            logger.info("Writing to output invalid directory: " + VERIFYTYPES_OUTPUT_INVALID);
            logger.info("Writing to output warning directory: " + VERIFYTYPES_OUTPUT_WARN);
        } else {
            MULTIPLETABLE_VERIFYTYPES_SUFFIX = "/"
                    + EdmHdpIfCommon.getPartition(conf
                            .get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_PARTITION)) + "/";
            MULTIPLETABLE_INVALIDTYPES_SUFFIX = "/"
                    + EdmHdpIfCommon.getPartition(conf
                            .get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_PARTITION)) + "/";
            MULTIPLETABLE_WARNTYPES_SUFFIX = "/"
                    + EdmHdpIfCommon.getPartition(conf
                            .get(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_PARTITION)) + "/";
            logger.info("Writing to output valid directory: " + VERIFYTYPES_OUTPUT_VALID + "<tableName>"
                    + MULTIPLETABLE_VERIFYTYPES_SUFFIX);
            logger.info("Writing to output invalid directory: " + VERIFYTYPES_OUTPUT_INVALID + "<tableName>"
                    + MULTIPLETABLE_INVALIDTYPES_SUFFIX);
            logger.info("Writing to output warning directory: " + VERIFYTYPES_OUTPUT_WARN + "<tableName>"
                    + MULTIPLETABLE_WARNTYPES_SUFFIX);
        }

        logger.info(this.getClass() + " setup finished");
    }

    @Override
    protected void map(WritableComparable<?> key, Text value, Context context) throws IOException, InterruptedException {

        // Expected columns are:
        // ROWID,
        // TABLENAME,
        // C_JOURNALTIME,
        // C_TRANSACTIONID,
        // C_OPERATIONTYPE,
        // C_USERID,
        // $HIVE_COL_TYPES_CHECK

        String errors;
        String tableName = null;
        EdmHdpIfColumnType row = null;

        try {
            row = new EdmHdpIfColumnType(value.toString(), false, conf);
            tableName = row.getTableName();

            // Try to get VerifySchema from hashmap
            VerifySchema schema = verifySchemaMap.get(tableName);
            if (schema == null) {
                String colSchema = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA);
                if (colSchema == null) {
                    errors = "config for '" + tableName + "' likely does not exist";

                    // Line is invalid: append errors and write to invalid
                    context.write(getOutputPath(false, tableName, false), getValue(row, errors));
                    return;
                } else {
                    // Col Schema
                    schema = new VerifySchema(colSchema, false);
                    verifySchemaMap.put(tableName, schema);
                }
            }
            errors = schema.verify(row.getData(), DATA_SEPARATOR, row);

        } catch (Exception e) {
            errors = e.getMessage();
        }

        if (errors == null || errors.isEmpty()) {
            // Line is valid
            boolean afterEOD = false;
            if (EODMARKER != null && row.getJournalTime() != null) {
                afterEOD = (EODMARKER.compareTo(row.getJournalTime()) < 0);
            }

            context.write(getOutputPath(true, tableName, afterEOD), getValue(row, ""));
        } else if (errors.contains("WARN")) {
            context.write(getOutputPath(true, tableName, false), getValue(row, "WARNING"));
            StringBuilder warnPath = new StringBuilder(VERIFYTYPES_OUTPUT_WARN).append(tableName);
            if (!ONETABLE) {
                warnPath.append(MULTIPLETABLE_WARNTYPES_SUFFIX).append(tableName);
            }
            context.write(new Text(warnPath.toString()), getValue(row, "WARNING"));
        } else {
            // Line is invalid: append errors and write to invalid
            if (row == null) {
                context.write(getOutputPath(false, tableName, false), new Text(value.toString() + COL_SEPARATOR
                        + errors));
            } else {
                context.write(getOutputPath(false, tableName, false), getValue(row, errors));
            }
        }
    }

    private Text getValue(EdmHdpIfColumnType row, String toAppend) {
        StringBuilder sb = new StringBuilder();
        if (ONETABLE) {
            sb.append(row.getRowWithTableName(COL_SEPARATOR, DATA_SEPARATOR, false));
            if (!toAppend.isEmpty())
                sb.append(COL_SEPARATOR).append(toAppend);
        } else {
            sb.append(row.getRow(DATA_SEPARATOR, DATA_SEPARATOR, false));
            if (!toAppend.isEmpty())
                sb.append(DATA_SEPARATOR).append(toAppend);
        }

        return new Text(sb.toString());
    }

    private Text getOutputPath(boolean valid, String tableName, boolean afterEOD) {
        StringBuilder output;
        if (valid) {
            output = new StringBuilder(VERIFYTYPES_OUTPUT_VALID).append(tableName);
        } else {
            output = new StringBuilder(VERIFYTYPES_OUTPUT_INVALID).append(tableName);
        }

        if (ONETABLE) {
            if (valid && afterEOD) {
                output.append(EdmHdpIfConstants.SUFFIX_EOD_VERIFYTYPES_FILES);
            }
        } else {
            if (valid) {
                output.append(MULTIPLETABLE_VERIFYTYPES_SUFFIX).append(tableName);
            } else {
                output.append(MULTIPLETABLE_INVALIDTYPES_SUFFIX).append(tableName);
            }
        }

        return new Text(output.toString());
    }
}
