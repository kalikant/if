package com.scb.edmhdpif.sri;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.PathFilter;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineSequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.PathFinder;
import com.scb.edmhdpif.lib.PathFinder.MatchType;

public class SRI extends Configured implements Tool {

	private static final Logger logger = Logger.getLogger(SRI.class);

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new SRI(), args);
		System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {

		Configuration conf = super.getConf();

		String oozieConfigurationLocation = System.getProperty("oozie.action.conf.xml");
		if (oozieConfigurationLocation != null) {
			logger.info("Loading Oozie configuration from " + oozieConfigurationLocation);
			conf.addResource(new Path(oozieConfigurationLocation));
		}
		EdmHdpIfCommon.checkRequiredParameters(conf, new String[] { EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE,
				EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH, EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE,
				EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION,
				EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE,
				EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE, EdmHdpIfConstants.EDMHDPIF_INDIVIDUAL_TABLEPREFIX,
				EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION_PREVIOUS, EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION,
				EdmHdpIfConstants.EDMHDPIF_NONOPEN_PARTITION, EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE,
				EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE, EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_PARTITION });

		logger.info("Next working date: " + conf.get(EdmHdpIfConstants.EDMHDPIF_SRI_NEXTWORKINGDATE));

		Job job;
		try {
			job = Job.getInstance(conf, "EdmHdpIf-SRI");
		} catch (IOException e) {
			e.printStackTrace();
			return 1;
		}

		job.setJarByClass(SRI.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(SRIMapper.class);
		job.setReducerClass(SRIReducer.class);

		// Delete output folder
		FileSystem fileSystem = FileSystem.get(conf);
		Path outputPath = new Path(conf.get(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH));
		logger.info("Output path set to " + outputPath);
		EdmHdpIfCommon.deletePath(fileSystem, outputPath + "/");

		String hiveWarehouse = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/");
		Path inputPath = new Path(hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "") + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "") + "/"
				+ EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "")));
		// Looking for EOD files in the previous partition
		Path inputPathPreviousPartition = new Path(
				hiveWarehouse + "/"
						+ conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "") + "/" + conf
								.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "")
						+ "/" + EdmHdpIfCommon
								.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION_PREVIOUS, "")));

		final String nonOpenLocation = hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE)
				+ "/";
		final String openLocation = hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + "/";
		final String tablePrefix = conf.get(EdmHdpIfConstants.EDMHDPIF_INDIVIDUAL_TABLEPREFIX);
		final String rerunTables = conf.get(EdmHdpIfConstants.EDMHDPIF_RERUN_TABLE);
		final String previousPartition = EdmHdpIfCommon
				.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION_PREVIOUS));
		logger.info("Open table location: " + openLocation);
		logger.info("Previous partition: " + previousPartition);
		List<Path> outputPathList = new ArrayList<Path>();

		try {
			// If not a rerun, load all tables
			if (rerunTables == null) {
				if (fileSystem.exists(inputPath)) {
					FileStatus[] beforeEODFiles = getEODFiles(fileSystem, inputPath, null, false);
					for (FileStatus file : beforeEODFiles) {
						logger.info("Adding input file: " + file.getPath());
						MultipleInputs.addInputPath(job, file.getPath(), CombineSequenceFileInputFormat.class,
								SRIMapper.class);
					}
				} else {
					logger.info("Input path doesn't exist, skipping: " + inputPath);
				}
				if (fileSystem.exists(inputPathPreviousPartition)) {
					FileStatus[] afterEODFiles = getEODFiles(fileSystem, inputPathPreviousPartition, null, true);
					for (FileStatus file : afterEODFiles) {
						logger.info("Adding input file previous partition, after EOD split: " + file.getPath());
						MultipleInputs.addInputPath(job, file.getPath(), CombineSequenceFileInputFormat.class,
								SRIMapper.class);
					}
				}

				// Add SRI input files
				logger.info("Looking for previous SRI files on location " + openLocation + " with table prefix "
						+ tablePrefix + " on partition " + previousPartition);
				PathFinder sriFiles = new PathFinder(conf, openLocation);
				sriFiles.setTableName(tablePrefix);
				sriFiles.setTableMatchType(MatchType.STARTSWITH);
				sriFiles.setTableSourceType("delta");
				sriFiles.setPartition(previousPartition);
				for (Path path : sriFiles.getFiles()) {
					logger.info("Adding SRI file: " + path);
					MultipleInputs.addInputPath(job, path, CombineSequenceFileInputFormat.class, SRIOpenMapper.class);
				}

				/*
				 * Output directories to delete
				 */
				// Open path
				PathFinder openPath = new PathFinder(conf, openLocation);
				openPath.setTableName(tablePrefix);
				openPath.setTableMatchType(MatchType.STARTSWITH);
				openPath.setPartition(EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION)));
				outputPathList.addAll(openPath.getFiles());
				// Non open path
				PathFinder nonopenPath = new PathFinder(conf, nonOpenLocation);
				nonopenPath.setTableName(tablePrefix);
				nonopenPath.setTableMatchType(MatchType.STARTSWITH);
				nonopenPath.setPartition(
						EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_PARTITION)));
				outputPathList.addAll(nonopenPath.getFiles());
				// Duplicates path
				PathFinder duplicatesPath = new PathFinder(conf, conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE)
						+ "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE));
				duplicatesPath.setTableName(conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE));
				duplicatesPath.setPartition(
						EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_PARTITION)));
				duplicatesPath.setFileName(job.getJobName());
				outputPathList.addAll(duplicatesPath.getFiles());
			} else { // If it's a rerun, only load the table to rerun
				logger.info("RERUN of table(s) " + rerunTables);
				String[] rerunTableNames = rerunTables.split(",");
				for (String rerunTableName : rerunTableNames) {
					if (fileSystem.exists(inputPath)) {
						FileStatus[] beforeEODFiles = getEODFiles(fileSystem, inputPath, rerunTableName, false);
						for (FileStatus file : beforeEODFiles) {
							logger.info("Adding input file: " + file.getPath());
							MultipleInputs.addInputPath(job, file.getPath(), CombineSequenceFileInputFormat.class,
									SRIMapper.class);
						}
					}
					if (fileSystem.exists(inputPathPreviousPartition)) {
						FileStatus[] afterEODFiles = getEODFiles(fileSystem, inputPathPreviousPartition, rerunTableName,
								true);
						for (FileStatus file : afterEODFiles) {
							logger.info("Adding input file, after EOD split: " + file.getPath());
							MultipleInputs.addInputPath(job, file.getPath(), CombineSequenceFileInputFormat.class,
									SRIMapper.class);
						}
					}

					// Add SRI input files
					logger.info("Looking for previous SRI files on location " + openLocation + " with table name "
							+ rerunTableName + " on partition " + previousPartition);

					PathFinder sriFiles = new PathFinder(conf, openLocation);
					sriFiles.setTableName(rerunTableName);
					sriFiles.setTableSourceType("delta");
					sriFiles.setPartition(previousPartition);
					for (Path path : sriFiles.getFiles()) {
						logger.info("Adding SRI file: " + path);
						MultipleInputs.addInputPath(job, path, CombineSequenceFileInputFormat.class,
								SRIOpenMapper.class);
					}

					/*
					 * Output paths to delete
					 */
					// Open path
					PathFinder openPath = new PathFinder(conf, openLocation);
					openPath.setTableName(rerunTableName);
					openPath.setPartition(
							EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION)));
					outputPathList.addAll(openPath.getFiles());
					// Non open path
					PathFinder nonopenPath = new PathFinder(conf, nonOpenLocation);
					nonopenPath.setTableName(rerunTableName);
					nonopenPath.setPartition(
							EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_PARTITION)));
					outputPathList.addAll(nonopenPath.getFiles());
					// Duplicates path
					PathFinder duplicatesPath = new PathFinder(conf, conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE)
							+ "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE));
					duplicatesPath.setTableName(conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE));
					duplicatesPath.setPartition(
							EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_PARTITION)));
					duplicatesPath.setFileName(job.getJobName() + "-" + rerunTableName);
					outputPathList.addAll(duplicatesPath.getFiles());

					outputPathList.add(new Path(nonOpenLocation + rerunTableName + "/"
							+ EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_PARTITION))
							+ "/"));
					outputPathList.add(new Path(openLocation + rerunTableName + "/"
							+ EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION)) + "/"));
				}

				// If no input paths set (e.g. rerun for a table that has no
				// file), then set
				// input path to empty directory so that job succeeds
				if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
					EdmHdpIfCommon.setEmptyInputPath(job, fileSystem, outputPath);
				}
			}

			// Delete output paths
			for (Path deletePath : outputPathList) {
				EdmHdpIfCommon.deletePath(fileSystem, deletePath.toString());
			}

			FileOutputFormat.setOutputPath(job, outputPath);
			MultipleOutputs.addNamedOutput(job, "data", SequenceFileOutputFormat.class, NullWritable.class, Text.class);
			MultipleOutputs.addNamedOutput(job, "rowcounts", SequenceFileOutputFormat.class, NullWritable.class,
					Text.class);
			MultipleOutputs.addNamedOutput(job, "duplicates", SequenceFileOutputFormat.class, NullWritable.class,
					Text.class);

			if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
				// No input paths
				logger.warn("Job not launched: no input paths");
				return 0;
			}
			return (job.waitForCompletion(true) ? 0 : 1);
		} catch (ClassNotFoundException | IOException | InterruptedException e) {
			e.printStackTrace();
			return 1;
		}
	}

	private FileStatus[] getEODFiles(FileSystem fileSystem, final Path parentPath, final String name,
			final boolean afterEOD) throws IllegalArgumentException, IOException {
		try {
			FileStatus[] fileList = fileSystem.listStatus(parentPath, new PathFilter() {
				@Override
				public boolean accept(Path path) {
					String fileName = path.getName();
					if (name != null && !fileName.startsWith(name)) {
						return false;
					}
					if (afterEOD) {
						return fileName.contains(EdmHdpIfConstants.SUFFIX_EOD_VERIFYTYPES_FILES);
					} else {
						return !fileName.contains(EdmHdpIfConstants.SUFFIX_EOD_VERIFYTYPES_FILES);
					}
				}
			});
			if (fileList == null) {
				fileList = new FileStatus[] {};
			}
			return fileList;
		} catch (FileNotFoundException e) {
			logger.warn("Ignoring path " + parentPath + ": " + e.getMessage());
			return new FileStatus[] {};
		}
	}
}
