package com.scb.edmhdpif.sri;

import java.io.IOException;
import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfColumnType;
import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.verifytypes.checker.VerifySchema;

public class SRIOpenMapper extends Mapper<WritableComparable<?>, Text, Text, Text> {

	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
	private String DATA_SEPARATOR = EdmHdpIfConstants.DATA_SEPARATOR;
	private Boolean CDC = null;

	Configuration conf = null;
	private static final Logger logger = Logger.getLogger(SRIOpenMapper.class);

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info(this.getClass() + " setup initiated for task " + context.getTaskAttemptID());

		conf = context.getConfiguration();
		COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
				COL_SEPARATOR));
		DATA_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR,
				DATA_SEPARATOR));
		CDC = Boolean.parseBoolean(conf.get(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS));
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);
		conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, DATA_SEPARATOR);
		conf.setBoolean(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS_BOOLEAN, CDC);

		logger.info(this.getClass() + " setup finished");
	}

	@Override
	protected void map(WritableComparable<?> key, Text value, Context context) throws IOException, InterruptedException {

		String tableName = EdmHdpIfCommon.getTableNameFromContext(context);
		if (tableName == null) {
			throw new RuntimeException("Could not get table name from input files");
		}
		EdmHdpIfColumnType sri = new EdmHdpIfColumnType(tableName + DATA_SEPARATOR + value.toString(), DATA_SEPARATOR,
				DATA_SEPARATOR, true, conf);

		Integer keycolNumbers[] = null;
		try {
			VerifySchema schema = null;
			String colSchema = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
					+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA);
			if (colSchema == null) {
				throw new RuntimeException("config for '" + tableName + "' likely does not exist");
			} else {
				// Col Schema
				schema = new VerifySchema(colSchema, false);
			}

			keycolNumbers = schema.getKeyColNumbers(conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
					+ ".keycols"));
		} catch (Exception e) {
			logger.error("Error extracting key column numbers for table " + sri.getTableName(), e);
			throw e;
		}

		// Build key
		String[] cols = sri.getData().split("\\" + DATA_SEPARATOR, -1);
		StringBuilder keyStr = new StringBuilder("#").append(tableName);
		try {
			for (Integer n : keycolNumbers) {
				keyStr.append("#").append(cols[n]);
			}
		} catch (Exception e) {
			throw new RuntimeException("Incorrect key number " + Arrays.toString(keycolNumbers)
					+ ", for column length " + cols.length + ". Table:" + tableName + ". RowId:" + cols[1], e);
		}

		context.write(new Text(keyStr.toString()),
				new Text(sri.getRowWithTableName(COL_SEPARATOR, DATA_SEPARATOR, true)));
	}
}
