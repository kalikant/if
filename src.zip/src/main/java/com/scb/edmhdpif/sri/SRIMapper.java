package com.scb.edmhdpif.sri;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfColumnType;
import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.verifytypes.checker.VerifySchema;

public class SRIMapper extends Mapper<WritableComparable<?>, Text, Text, Text> {

	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
	private String DATA_SEPARATOR = EdmHdpIfConstants.DATA_SEPARATOR;

	private final Map<String, Integer[]> keyColNumbersMap = new HashMap<>();
	private Configuration conf = null;
	private static final Logger logger = Logger.getLogger(SRIMapper.class);
	private String WRITE_SRI_START = null;
	private String WRITE_SRI_END = null;
	private Boolean CDC = null;

	private final HashMap<String, Boolean> deltaTableMap = new HashMap<>();

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info(this.getClass() + " setup initiated for task " + context.getTaskAttemptID());
		conf = context.getConfiguration();
		COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
				COL_SEPARATOR));
		DATA_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR,
				DATA_SEPARATOR));
		CDC = Boolean.parseBoolean(conf.get(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS));
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);
		conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, DATA_SEPARATOR);
		conf.setBoolean(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS_BOOLEAN, CDC);

		WRITE_SRI_START = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE) + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + "/";
		WRITE_SRI_END = "/" + EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION)) + "/";

		logger.info("Write SRI directory: " + WRITE_SRI_START + "<tablename>" + WRITE_SRI_END + "<tablename>");

		logger.info(this.getClass() + " setup finished");
	}

	@Override
	protected void map(WritableComparable<?> key, Text value, Context context) throws IOException, InterruptedException {
		EdmHdpIfColumnType sri = new EdmHdpIfColumnType(addTimeColumns(value.toString()), true, conf);

		// Ignore operation type Before
		if ("B".equalsIgnoreCase(sri.getOperationType())) {
			context.write(EdmHdpIfConstants.B_VALUES_TEXT, new Text(sri.getTableName()));
			return;
		}

		Boolean deltaTable = deltaTableMap.get(sri.getTableName());
		if (deltaTable == null) {
			String sourceType = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + sri.getTableName()
					+ ".sourcetype");
			deltaTable = "delta".equalsIgnoreCase(sourceType);
			deltaTableMap.put(sri.getTableName(), deltaTable);
		}

		if (deltaTable) {
			prepareSRI(sri, context);
		} else {
			writeSRI(sri, context);
		}
	}

	/**
	 * Writes the data to the file. If the data comes from a non-delta table,
	 * then the key is the file to write the data, and the value the data to be
	 * written.
	 * 
	 * @param sri
	 *            The row with the data.
	 * @param context
	 *            The context.
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void prepareSRI(EdmHdpIfColumnType sri, Context context) throws IOException, InterruptedException {

		String tableName = sri.getTableName();

		// Extract the key for SRI
		Integer[] keycolNumbers = keyColNumbersMap.get(tableName);
		if (keycolNumbers == null) {
			VerifySchema schema = null;
			String colSchema = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
					+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA);
			if (colSchema == null) {
				throw new RuntimeException("config for '" + tableName + "' likely does not exist");
			} else {
				// Col Schema
				schema = new VerifySchema(colSchema, false);
			}

			String keycols = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + ".keycols");
			if (keycols == null) {
				throw new RuntimeException("key columns config for '" + tableName + "' likely does not exist");
			} else {
				keycolNumbers = schema.getKeyColNumbers(keycols);
				keyColNumbersMap.put(tableName, keycolNumbers);
			}
		}

		// Build key
		String[] dataCols = sri.getData().split("\\" + DATA_SEPARATOR, -1);
		StringBuilder keyStr = new StringBuilder("#").append(tableName);
		for (Integer n : keycolNumbers) {
			if (n > dataCols.length - 1) {
				String error = "Incorrect number of columns when retrieving key: cols=" + dataCols.length
						+ " expected: " + n;
				logger.error(error);
				throw new RuntimeException(error);
			}
			keyStr.append("#").append(dataCols[n]);
		}

		context.write(new Text(keyStr.toString()),
				new Text(sri.getRowWithTableName(COL_SEPARATOR, DATA_SEPARATOR, true)));

	}

	/**
	 * 
	 * Send the reducer the data to be written to a file. The data comes from a
	 * non-delta table: the generated key is the file to write the data, and the
	 * value is the data to be written.
	 * 
	 * 
	 * @param sri
	 *            The row with the data.
	 * @param context
	 *            The context.
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void writeSRI(EdmHdpIfColumnType sri, Context context) throws IOException, InterruptedException {

		String tableName = sri.getTableName();

		Path writePath = new Path(new StringBuilder(WRITE_SRI_START).append(tableName).append(WRITE_SRI_END)
				.append(tableName).toString());
		Text writeKey = new Text(Path.getPathWithoutSchemeAndAuthority(writePath).toString());

		context.write(writeKey, new Text(sri.getRowWithTableName(DATA_SEPARATOR, DATA_SEPARATOR, true)));
	}

	/**
	 * Add the datetime information for SRI row: start time, end time and delete
	 * flag (all three empty by default).
	 * 
	 * @param row
	 *            The row.
	 * @return The row with the time columns.
	 */
	private String addTimeColumns(String row) {
		return new StringBuilder(row).append(COL_SEPARATOR).append(COL_SEPARATOR).append("-1").append(COL_SEPARATOR)
				.append(COL_SEPARATOR).append("-1").append(COL_SEPARATOR).append("0").toString();
	}
}
