package com.scb.edmhdpif.sri;

import java.io.IOException;
import java.nio.channels.ClosedChannelException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfColumnType;
import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;

public class SRIReducer extends Reducer<Text, Text, NullWritable, Writable> {

    /**
     * Constants for physical table field in row counts for B Values and Non
     * open records not written.
     */
    private static final String B_VALUES_TABLE = "B records";
    private static final String NON_OPEN_RECORDS_TABLE = "Non open records";

    /**
     * Variables initialized at setup
     */
    private String NON_OPEN_PATH_START;
    private String NON_OPEN_PATH_END;
    private String OPEN_PATH_START;
    private String OPEN_PATH_END;
    private String OPEN_DATABASE, NONOPEN_DATABASE;
    private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
    private String DATA_SEPARATOR = EdmHdpIfConstants.DATA_SEPARATOR;
    private Boolean CDC = null;

    private MultipleOutputs<NullWritable, Writable> mout;

    private Configuration conf = null;

    private final Map<String, String> rowCountPathsMap = new HashMap<>();
    private String tcStartDate = "";
    private final String tcStartTime = EdmHdpIfCommon.getUnixTime();
    private String rowCountPath = null;
    private static final Logger logger = Logger.getLogger(SRIReducer.class);

    private String lastTableProcessed = null;
    private String nonOpenPath = null;
    private String openPath = null;
    private String duplicatesPath = null;
    private Boolean writeNonOpen = true;

    private Context context;

    @Override
    protected void setup(Context context) throws IOException, InterruptedException {
        logger.info("Setup initiated");

        this.context = context;
        conf = context.getConfiguration();
        COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
                COL_SEPARATOR));
        DATA_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR,
                DATA_SEPARATOR));
        CDC = Boolean.parseBoolean(conf.get(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS));
        conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);
        conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, DATA_SEPARATOR);
        conf.setBoolean(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS_BOOLEAN, CDC);

        OPEN_DATABASE = conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE);
        NONOPEN_DATABASE = conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE);

        if (NONOPEN_DATABASE == null) {
            writeNonOpen = false;
        } else {
            NON_OPEN_PATH_START = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE) + "/"
                    + conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + "/";
            NON_OPEN_PATH_END = "/"
                    + EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_PARTITION)) + "/";
            logger.info("Non open path: " + NON_OPEN_PATH_START + "<tablename>" + NON_OPEN_PATH_END);
        }

        OPEN_PATH_START = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE) + "/"
                + conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + "/";
        OPEN_PATH_END = "/" + EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION)) + "/";
        logger.info("Open path: " + OPEN_PATH_START + "<tablename>" + OPEN_PATH_END);

        duplicatesPath = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE) + "/"
                + conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE) + "/"
                + conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE) + "/"
                + EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_PARTITION)) + "/"
                + context.getJobName();

        tcStartDate = conf.get(EdmHdpIfConstants.EDMHDPIF_SRI_NEXTWORKINGDATE);
        if (tcStartDate == null) {
            tcStartDate = EdmHdpIfCommon.getPartitionDate(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION));
        }

        rowCountPath = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "") + "/"
                + conf.get(EdmHdpIfConstants.EDMHDPIF_ROWCOUNTS_DATABASE, "") + "/"
                + conf.get(EdmHdpIfConstants.EDMHDPIF_ROWCOUNTS_TABLE, "") + "/"
                + EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_ROWCOUNTS_PARTITION, ""));

        logger.info(this.getClass() + " setup finished");

    }

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

        if (EdmHdpIfConstants.B_VALUES_TEXT.equals(key)) {
            Map<String, Integer> tables = new HashMap<>();
            Integer count = 0;
            for (Text val : values) {
                count = tables.get(val.toString());
                if (count == null) {
                    count = 0;
                }
                count++;
                tables.put(val.toString(), count);
            }
            for (Entry<String, Integer> entry : tables.entrySet()) {
                logger.info("B records for table " + entry.getKey() + " : " + entry.getValue());
                writeRowCount(OPEN_DATABASE, B_VALUES_TABLE, entry.getValue(), entry.getKey());
            }
            return;
        }
        /*
         * Close the outputs and open again for each new table.
         * 
         * Each table is written to a new file. The ORC output format keeps one
         * Record Writer for each file, and buffers the rows and compress them
         * before flushing to disk. Since this buffers are maintained in memory,
         * this leads to out of memory exceptions.
         * 
         * To avoid that, after processing one table, the outputs are closed to
         * force the flushing to disk.
         */
        if (key.toString().startsWith("#")) {
            // Get all the values
            List<EdmHdpIfColumnType> valuesSet = new ArrayList<EdmHdpIfColumnType>();
            for (Text t : values) {
                valuesSet.add(new EdmHdpIfColumnType(t.toString(), true, conf));
            }
            String tableName = valuesSet.get(0).getTableName();
            // Sort the values for SRI
            Collections.sort(valuesSet);
            if (conf.getBoolean(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
                    + EdmHdpIfConstants.SUFFIX_SRI_FULLDUMP, false)) {
                processSRIFullDump(key, valuesSet, context);
            } else {
                processSRIIncremental(key, valuesSet, context);
            }
        } else {
            // Write directly to the key directory
            writeSRI(key, values, context);
        }
    }

    /**
     * Process SRI, only for Full Dump process type
     * 
     * @param key
     * @param values
     * @param context
     * @throws IOException
     * @throws InterruptedException
     */
    private void processSRIFullDump(Text key, List<EdmHdpIfColumnType> valuesSet,
            Reducer<Text, Text, NullWritable, Writable>.Context context) throws IOException, InterruptedException {
        if (valuesSet.size() == 1) {
            // Record has been deleted or created new
            EdmHdpIfColumnType val = valuesSet.get(0);
            if (val.getStartDate() != null && !val.getStartDate().isEmpty()) {
                // Record has been deleted in that partition
                // EdmHdpIfColumnType deleteRecord = new
                // EdmHdpIfColumnType(val);
                // deleteRecord.setOperationTypeDelete();
                // valuesSet.add(deleteRecord);
                val.setOperationTypeDelete();
            }
        } else {
            // Record unchanged or updated. Remove duplicates, if the result is
            // 1 record, it means the record has not changes. If the result are
            // 2 records, the record has been updated.
            List<EdmHdpIfColumnType> valuesSet2 = new ArrayList<EdmHdpIfColumnType>();
            EdmHdpIfColumnType currentValue = null;
            for (EdmHdpIfColumnType value : valuesSet) {
                if (!value.dataEquals(currentValue)) {
                    currentValue = value;
                    valuesSet2.add(currentValue);
                }
            }
            valuesSet = valuesSet2;
        }

        processSRI(key, valuesSet, context);
    }

    /**
     * Process SRI for incremental type
     * 
     * @param key
     * @param values
     * @param context
     * @throws IOException
     * @throws InterruptedException
     */
    private void processSRIIncremental(Text key, List<EdmHdpIfColumnType> values,
            Reducer<Text, Text, NullWritable, Writable>.Context context) throws IOException, InterruptedException {
        processSRI(key, values, context);
    }

    /**
     * Process the data using the SRI logic for delta tables. If the data comes
     * from a delta table, then the key a combination of the table name and the
     * values of the key columns, and the values are the rows that share the
     * same key.
     * 
     * @param key
     *            The key that comes from the mapper.
     * @param values
     *            The values that come from the mapper.
     * @param context
     *            The context.
     * @throws IOException
     * @throws InterruptedException
     */
    private void processSRI(Text key, Iterable<EdmHdpIfColumnType> valuesSet, Context context) throws IOException,
            InterruptedException {

        Iterator<EdmHdpIfColumnType> it = valuesSet.iterator();
        EdmHdpIfColumnType currentRow = it.next();
        String tableName = currentRow.getTableName();

        if (!tableName.equals(lastTableProcessed)) {
            if (mout != null) {
                try {
                    mout.close();
                } catch (ClosedChannelException e) {

                }
            }
            mout = new MultipleOutputs<NullWritable, Writable>(context);
            lastTableProcessed = tableName;
            // Intermediate rows are stores in the non open table
            if (writeNonOpen) {
                nonOpenPath = new StringBuilder(NON_OPEN_PATH_START).append(tableName).append(NON_OPEN_PATH_END)
                        .append(tableName).toString();
            }
            openPath = new StringBuilder(OPEN_PATH_START).append(tableName).append(OPEN_PATH_END).append(tableName)
                    .toString();
        }

        // Set start date for new row
        if (currentRow.getStartDate().isEmpty()) {
            currentRow.setStartDate(tcStartDate);
            currentRow.setStartTime(tcStartTime);
        }
        int nonOpenCount = 0;
        EdmHdpIfColumnType nextRow;
        while (it.hasNext()) {
            nextRow = it.next();
            // Set start date for new row
            if (nextRow.getStartDate().isEmpty()) {
                nextRow.setStartDate(tcStartDate);
                nextRow.setStartTime(tcStartTime);
            }
            // Remove duplicates
            if (currentRow.dataEquals(nextRow) && !currentRow.isOperationTypeDelete()
                    && !nextRow.isOperationTypeDelete()) {
                StringBuilder duplicatedRowEntry = new StringBuilder(currentRow.getRowId()).append(COL_SEPARATOR)
                        .append(nextRow.getRowId()).append(COL_SEPARATOR).append(context.getJobName());
                mout.write("duplicates", NullWritable.get(), new Text(duplicatedRowEntry.toString()), duplicatesPath
                        + "-" + currentRow.getTableName());
                writeRowCount(conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE),
                        conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE), 1, tableName);
                continue;
            }
            currentRow.setEndDate(nextRow.getStartDate());
            currentRow.setEndTime(nextRow.getStartTime());
            if (currentRow.isOperationTypeDelete()) {
                currentRow.setDeleteFlag("1");
            }
            if (writeNonOpen) {
                StringBuilder currentRowData = new StringBuilder();
                currentRowData.append(currentRow.getRow(DATA_SEPARATOR, DATA_SEPARATOR, true));
                mout.write("data", NullWritable.get(), new Text(currentRowData.toString()), nonOpenPath);
            }
            // Keep non open records count even if we don't write non-open
            // records
            nonOpenCount++;
            currentRow = nextRow;
        }
        // If not type delete, Last row is stored in the out open table
        if (currentRow.isOperationTypeDelete()) {
            currentRow.setDeleteFlag("1");
            currentRow.setEndDate(tcStartDate);
            currentRow.setEndTime(tcStartTime);
            if (writeNonOpen) {
                StringBuilder rowData = new StringBuilder();
                rowData.append(currentRow.getRow(DATA_SEPARATOR, DATA_SEPARATOR, true));
                mout.write("data", NullWritable.get(), new Text(rowData.toString()), nonOpenPath);
            }
            // Keep non open records count even if we don't write non-open
            // records
            nonOpenCount++;
        } else {
            StringBuilder rowData = new StringBuilder();
            rowData.append(currentRow.getRow(DATA_SEPARATOR, DATA_SEPARATOR, true));
            mout.write("data", NullWritable.get(), new Text(rowData.toString()), openPath);
            writeRowCount(OPEN_DATABASE, tableName, 1, tableName);
        }

        if (nonOpenCount > 0) {
            if (writeNonOpen) {
                writeRowCount(NONOPEN_DATABASE, tableName, nonOpenCount, tableName);
            } else {
                writeRowCount(OPEN_DATABASE, NON_OPEN_RECORDS_TABLE, nonOpenCount, tableName);
            }
        }
    }

    /**
     * Writes the data to the file. If the data comes from a non-delta table,
     * then the key is the file to write the data, and the value is the data to
     * be written.
     * 
     * @param key
     *            The key that comes from the mapper.
     * @param values
     *            The values that come from the mapper.
     * @param context
     *            The context.
     * @throws IOException
     * @throws InterruptedException
     */
    private void writeSRI(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        // Write directly to the key directory
        if (mout != null) {
            // Force write to save memory
            try {
                mout.close();
            } catch (ClosedChannelException e) {
                // If we use compression, then the channel could be already
                // closed. Ignore the exception
            }
        }
        mout = new MultipleOutputs<NullWritable, Writable>(context);

        String outpaths[] = key.toString().split("/");
        // <root>/warehouse_path/database/outputTable/partition/ebbsTable
        // warehouse_path can be of any nesting but rest are affixed by mapper
        if (outpaths.length < 6) {
            throw new RuntimeException("Incorrect write path: " + key.toString());
        }
        final String database = outpaths[outpaths.length - 4];
        final String outputTable = outpaths[outpaths.length - 3];

        Path writePath = new Path(key.toString());

        int writeCount = 0;
        for (Text t : values) {

            EdmHdpIfColumnType sri = new EdmHdpIfColumnType(t.toString(), DATA_SEPARATOR, DATA_SEPARATOR, true, conf);
            sri.setStartDate(tcStartDate);
            sri.setStartTime(tcStartTime);
            writeCount++;
            mout.write("data", NullWritable.get(), new Text(sri.getRow(DATA_SEPARATOR, DATA_SEPARATOR, true)),
                    writePath.toString());
        }

        // Write rowcount
        writeRowCount(database, outputTable, writeCount, outputTable);
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        logger.info("Cleanup initiated");
        // Force write to save memory
        try {
            if (mout != null) {
                mout.close();
            }
        } catch (ClosedChannelException e) {
            // If we use compression, then the channel could be already
            // closed. Ignore the exception
        }

        // Write row count
        mout = new MultipleOutputs<NullWritable, Writable>(context);
        Text writeValue = new Text();
        String fileName = rowCountPath + "/sri-" + UUID.randomUUID();
        for (String row : rowCountPathsMap.values()) {
            String[] splittedRow = row.split(COL_SEPARATOR, -1);
            String database = splittedRow[0];
            String outputtable = splittedRow[1];
            String count = splittedRow[2];

            logger.info("Adding row count information for table " + database + "." + outputtable + " Count: " + count
                    + " File: " + fileName);
            writeValue.set(row);
            mout.write("rowcounts", NullWritable.get(), writeValue, fileName);
        }

        try {
            mout.close();
        } catch (ClosedChannelException e) {
            // If we use compression, then the channel could be already closed.
            // Ignore the exception
        }
        logger.info(this.getClass() + " cleanup finished");
    }

    /**
     * Write a row count line. The row count is wrote in the cleanup method,
     * this method stores the count in a Map, or modifies the stored line if
     * already exists.
     * 
     * @param database
     *            Database field of the RowCount table.
     * @param outputTable
     *            Table field of the RowCount table.
     * @param writeCount
     *            Row count to be set or added.
     * @param tableName
     *            The functional table name
     * @throws IOException
     * @throws InterruptedException
     */
    private void writeRowCount(String database, String outputTable, int writeCount, String tableName)
            throws IOException, InterruptedException {

        // Use composite key since tableName alone counts rowid + rowhist
        // together
        String composite = new StringBuilder(database).append("#").append(outputTable).append("#").append(tableName)
                .toString();
        String row = rowCountPathsMap.get(composite);
        if (row == null) {
            row = new StringBuilder(database).append(COL_SEPARATOR).append(outputTable).append(COL_SEPARATOR)
                    .append(writeCount).append(COL_SEPARATOR).append(tableName).append(COL_SEPARATOR)
                    .append(tcStartTime).append(COL_SEPARATOR).append(context.getJobName()).append(COL_SEPARATOR)
                    .append(context.getTaskAttemptID()).toString();
        } else {
            Integer count = Integer.valueOf(row.split(COL_SEPARATOR, -1)[2]);
            row = new StringBuilder(database).append(COL_SEPARATOR).append(outputTable).append(COL_SEPARATOR)
                    .append((count + writeCount)).append(COL_SEPARATOR).append(tableName).append(COL_SEPARATOR)
                    .append(tcStartTime).append(COL_SEPARATOR).append(context.getJobName()).append(COL_SEPARATOR)
                    .append(context.getTaskAttemptID()).toString();
        }
        rowCountPathsMap.put(composite, row);
    }
}
