package com.scb.edmhdpif.rowid;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.input.FileLineWritable;

public class RowIdMapper extends Mapper<FileLineWritable, Text, Text, Text> {

	private int rowCount = 0;
	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
	private Configuration conf = null;
	private static final Logger logger = Logger.getLogger(RowIdMapper.class);
	private String ROWID_OUTPUT;
	private String ROWHISTORY_OUTPUT;

	@Override
	protected void setup(Mapper<FileLineWritable, Text, Text, Text>.Context context) throws IOException,
			InterruptedException {
		logger.info("Setup initiated for task " + context.getTaskAttemptID());
		conf = context.getConfiguration();
		COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
				COL_SEPARATOR));
		ROWID_OUTPUT = conf.get(EdmHdpIfConstants.EDMHDPIF_ROWID_OUTPUT);
		logger.info("Writing RowId output to " + ROWID_OUTPUT);
		ROWHISTORY_OUTPUT = conf.get(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_OUTPUT);
		logger.info("Writing RowHistory output to " + ROWHISTORY_OUTPUT);
		logger.info("Setup finished");
	}

	@Override
	protected void map(FileLineWritable key, Text value, Context context) throws IOException, InterruptedException {
		String p[] = key.getFileName().split("/");
		String tableName = p[p.length - 1].split("\\.")[0];

		Text writeKey = new Text(ROWID_OUTPUT + tableName);
		Text writeKeyHistory = new Text(ROWHISTORY_OUTPUT + tableName);

		String rowId = getRowId(context);
		StringBuilder line = new StringBuilder(tableName).append(COL_SEPARATOR).append(rowId).append(COL_SEPARATOR)
				.append(value.toString());

		// default delim is ^A
		Text writeValue = new Text(line.toString());
		context.write(writeKey, writeValue);

		Text writeValueHistory = new Text(rowId + COL_SEPARATOR + key.getFileName());
		context.write(writeKeyHistory, writeValueHistory);
	}

	private String getRowId(Context context) {
		rowCount++;
		return context.getTaskAttemptID() + "_" + rowCount;
	}
}
