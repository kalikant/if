package com.scb.edmhdpif.rowid;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.CompressionCodec;
import org.apache.hadoop.io.compress.CompressionCodecFactory;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.PathFinder;
import com.scb.edmhdpif.lib.input.CFInputFormat;

public class RowId extends Configured implements Tool {

	private static final Logger logger = Logger.getLogger(RowId.class);
	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new RowId(), args);
		System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {

		Configuration conf = super.getConf();

		String oozieConfigurationLocation = System.getProperty("oozie.action.conf.xml");
		if (oozieConfigurationLocation != null) {
			logger.info("Loading Oozie configuration from " + oozieConfigurationLocation);
			conf.addResource(new Path(oozieConfigurationLocation));
		}

		EdmHdpIfCommon.checkRequiredParameters(conf,
				new String[] { EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH,
						EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE,
						EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, EdmHdpIfConstants.EDMHDPIF_ROWID_DATABASE,
						EdmHdpIfConstants.EDMHDPIF_ROWID_TABLE, EdmHdpIfConstants.EDMHDPIF_ROWID_PARTITION,
						EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_DATABASE, EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_TABLE,
						EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_PARTITION });

		COL_SEPARATOR = conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);

		// Check file validator output
		String hiveWarehouse = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/");
		FileSystem fileSystem = FileSystem.get(conf);

		String fileValidatorType = conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_TYPE);

		ArrayList<String> validFiles = null;
		if (fileValidatorType != null
				&& !("NONE".equalsIgnoreCase(fileValidatorType) || "FALSE".equalsIgnoreCase(fileValidatorType))) {

			EdmHdpIfCommon.checkRequiredParameters(conf,
					new String[] { EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_DATABASE,
							EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_TABLE,
							EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_PARTITION });

			Path validatorOutputPath = new Path(
					hiveWarehouse + "/"
							+ conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_DATABASE) + "/" + conf
									.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_TABLE)
							+ "/" + EdmHdpIfCommon
									.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_PARTITION)));

			logger.info("Validator output path: " + validatorOutputPath);

			if (fileSystem.exists(validatorOutputPath)) {
				validFiles = new ArrayList<String>();
				// Read the file for valid input files
				PathFinder validatedFiles = new PathFinder(conf,
						hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_DATABASE));
				validatedFiles.setTableName(conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_TABLE));
				validatedFiles.setPartition(
						EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_PARTITION)));
				validatedFiles.setFileName("");
				for (Path file : validatedFiles.getFiles()) {
					logger.info("Loading validator output file: " + file);
					validFiles.addAll(getValidFiles(fileSystem, file));
				}
			}
		}

		Job job;
		try {
			job = Job.getInstance(conf, "EdmHdpIf-RowId");
		} catch (IOException e) {
			e.printStackTrace();
			return 1;
		}
		logger.info("Job " + job.getJobName() + " created.");

		job.setJarByClass(RowId.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(RowIdMapper.class);
		job.setReducerClass(RowIdReducer.class);

		// Delete output directory
		Path outputPath = new Path(conf.get(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH));
		logger.info("Output path set to " + outputPath);
		EdmHdpIfCommon.deletePath(fileSystem, outputPath + "/");

		String inputDatabase = conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "");
		String inputTable = conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "");
		String inputPartition = EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, ""));
		Path inputPath = new Path(hiveWarehouse + "/" + inputDatabase + "/" + inputTable + "/" + inputPartition);
		// Output paths
		Path rowidOutputPath = new Path(hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_ROWID_DATABASE, "")
				+ "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_ROWID_TABLE, "") + "/"
				+ EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_ROWID_PARTITION, "")));
		Path rowhistoryOutputPath = new Path(
				hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_DATABASE, "") + "/"
						+ conf.get(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_TABLE, "") + "/"
						+ EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_PARTITION, "")));
		String rowidOutput = Path.getPathWithoutSchemeAndAuthority(rowidOutputPath) + "/";
		String rowhistoryOutput = Path.getPathWithoutSchemeAndAuthority(rowhistoryOutputPath) + "/";
		logger.info("Row Id output: " + rowidOutputPath);
		logger.info("Row History output: " + rowhistoryOutputPath);

		try {
			// If it's a rerun, only load the tables to rerun
			final String rerunTables = conf.get(EdmHdpIfConstants.EDMHDPIF_RERUN_TABLE);
			if (rerunTables == null) {
				if (validFiles != null) {
					for (String file : validFiles) {
						logger.info("Adding validated file: " + file);
						MultipleInputs.addInputPath(job, new Path(file), CFInputFormat.class);
					}
				} else {
					if (fileSystem.exists(inputPath)) {
						logger.info("Adding input path: " + inputPath);
						MultipleInputs.addInputPath(job, inputPath, CFInputFormat.class);
					} else {
						logger.info("Input path doesn't exist, skipping: " + inputPath);
					}
				}
				EdmHdpIfCommon.deletePath(fileSystem, rowidOutput);
				EdmHdpIfCommon.deletePath(fileSystem, rowhistoryOutput);
			} else {
				logger.info("RERUN of table(s) " + rerunTables);
				String[] names = rerunTables.split(",");
				for (String n : names) {
					PathFinder inputPathFinder = new PathFinder(conf,
							hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, ""));
					inputPathFinder.setTableName(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, ""));
					inputPathFinder.setPartition(
							EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "")));
					inputPathFinder.setFileName(n + ".");

					for (Path file : inputPathFinder.getFiles()) {
						logger.info("Adding input file: " + file);
						MultipleInputs.addInputPath(job, file, CFInputFormat.class);
					}

					EdmHdpIfCommon.deletePath(fileSystem, rowidOutput + n);
					EdmHdpIfCommon.deletePath(fileSystem, rowhistoryOutput + n);
				}

				// If no input paths set (e.g. rerun for a table that has no
				// file), then set
				// input path to empty directory so that job succeeds
				if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
					EdmHdpIfCommon.setEmptyInputPath(job, fileSystem, outputPath);
				}
			}
			job.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_ROWID_OUTPUT, rowidOutput);
			job.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_OUTPUT, rowhistoryOutput);

			FileOutputFormat.setOutputPath(job, outputPath);
			MultipleOutputs.addNamedOutput(job, "data", SequenceFileOutputFormat.class, NullWritable.class, Text.class);
			MultipleOutputs.addNamedOutput(job, "rowcounts", SequenceFileOutputFormat.class, NullWritable.class,
					Text.class);

			if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
				// No input paths
				logger.warn("Job not launched: no input paths");
				return 0;
			}
			return (job.waitForCompletion(true) ? 0 : 1);
		} catch (ClassNotFoundException | IOException | InterruptedException e) {
			e.printStackTrace();
			return 1;
		}
	}

	/**
	 * Read a file and return the valid paths.
	 * 
	 * @param path
	 *            The file to read.
	 * @return
	 * @throws IOException
	 */
	private Collection<? extends String> getValidFiles(FileSystem fileSystem, Path path) throws IOException {

		final CompressionCodec codec = new CompressionCodecFactory(fileSystem.getConf()).getCodec(path);

		InputStream is = null;

		if (null != codec) {
			is = codec.createInputStream(fileSystem.open(path));
		} else {
			is = fileSystem.open(path);
		}
		BufferedReader br = new BufferedReader(new InputStreamReader(is));

		String line = null;
		String cols[] = null;
		ArrayList<String> validFiles = new ArrayList<String>();
		// Get the first EOD date from the file
		while ((line = br.readLine()) != null) {
			cols = line.split(COL_SEPARATOR, -1);
			if (cols.length != 3) {
				continue;
			}
			if ("true".equalsIgnoreCase(cols[1])) {
				// valid file, add path to list
				validFiles.add(cols[0]);
			}
		}
		return validFiles;
	}
}
