package com.scb.edmhdpif.filevalidator;

import java.io.IOException;
import java.net.URI;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;

public class CDCRowCountFileValidatorReducer extends Reducer<Text, IntWritable, NullWritable, Text> {

	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
	private Pattern fileNamePattern;
	private static final Logger logger = Logger.getLogger(CDCRowCountFileValidatorReducer.class);
	private final String tcStartTime = EdmHdpIfCommon.getUnixTime();
	private String BUSINESSDAY = "";
	private Context context;

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info("Setup initiated");

		this.context = context;
		fileNamePattern = Pattern.compile(context.getConfiguration().get(
				CDCRowCountFileValidator.EDMHDPIF_FILEVALIDATOR_CDCROWCOUNT_PATTERN));
		logger.info("Using file name pattern: " + fileNamePattern);
		BUSINESSDAY = context.getConfiguration().get(EdmHdpIfConstants.EDMHDPIF_SRI_NEXTWORKINGDATE, BUSINESSDAY);
		COL_SEPARATOR = context.getConfiguration().get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, COL_SEPARATOR);
		logger.info("Setup finished");
	}

	@Override
	protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException,
			InterruptedException {
		int rowCount = 0;
		for (IntWritable value : values) {
			rowCount += value.get();
		}

		// Get the file source path
		Path srcPath = new Path(URI.create(key.toString()));
		// Row count by filename
		int rowCountByFileName = 0;
		Matcher m = fileNamePattern.matcher(srcPath.getName());
		if (!m.find()) {
			context.write(
					NullWritable.get(),
					new Text(getRecord(srcPath, "File name " + srcPath.getName()
							+ " does not match with expected file name pattern: " + fileNamePattern.toString())));
			return;
		}
		rowCountByFileName = Integer.parseInt(m.group(1));

		// Check if the file is correct
		if (rowCount == rowCountByFileName) {
			context.write(NullWritable.get(), new Text(getRecord(srcPath, "")));
		} else {
			context.write(
					NullWritable.get(),
					new Text(getRecord(srcPath, "Row count " + rowCount + " does not match with expected rowcount: "
							+ rowCountByFileName)));
		}
	}

	private String getRecord(Path srcPath, String error) {
		String valid = "false";
		if (error == null || error.isEmpty()) {
			valid = "true";
		}
		StringBuilder strbuilder = new StringBuilder(srcPath.toString()).append(COL_SEPARATOR).append(valid)
				.append(COL_SEPARATOR).append(error).append(COL_SEPARATOR).append(BUSINESSDAY).append(COL_SEPARATOR)
				.append(tcStartTime).append(COL_SEPARATOR).append(context.getJobName()).append(COL_SEPARATOR)
				.append(context.getTaskAttemptID());
		return strbuilder.toString();
	}
}