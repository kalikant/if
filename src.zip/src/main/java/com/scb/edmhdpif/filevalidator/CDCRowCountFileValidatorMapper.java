package com.scb.edmhdpif.filevalidator;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.scb.edmhdpif.lib.input.FileLineWritable;

public class CDCRowCountFileValidatorMapper extends
		Mapper<FileLineWritable, Text, Text, IntWritable> {

	private final static IntWritable one = new IntWritable(1);

	@Override
	protected void map(FileLineWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		context.write(new Text(key.getFileName()), one);
	}
}