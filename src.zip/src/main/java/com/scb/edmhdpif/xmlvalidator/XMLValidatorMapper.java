package com.scb.edmhdpif.xmlvalidator;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.input.FileLineWritable;

public class XMLValidatorMapper extends Mapper<FileLineWritable, Text, Text, Text> {

	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
	private String DATA_SEPARATOR = EdmHdpIfConstants.DATA_SEPARATOR;
	private Configuration conf = null;
	private String validOutputPath = null;
	private String invalidOutputPath = null;

	private static final Logger logger = Logger.getLogger(XMLValidatorMapper.class);

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info("Setup initiated");
		conf = context.getConfiguration();
		COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
				COL_SEPARATOR));
		DATA_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR,
				DATA_SEPARATOR));
		validOutputPath = conf.get(XMLValidator.XMLVALIDATOR_VALID_OUTPUT);
		invalidOutputPath = conf.get(XMLValidator.XMLVALIDATOR_INVALID_OUTPUT);
		logger.info("Setup finished");
	}

	@Override
	protected void map(FileLineWritable key, Text value, Context context) throws IOException, InterruptedException {
		// Parse value as XML
		DocumentBuilder builder;
		try {
			builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			String xml = value.toString().trim();
			Document document = builder.parse(new InputSource(new StringReader(xml)));
			// Convert the nodes to columns, using the columns separator
			StringBuilder row = new StringBuilder();
			NodeList nodeList = document.getChildNodes();
			for (int i = 0; i < nodeList.getLength(); i++) {
				if (i > 0) {
					row.append(DATA_SEPARATOR);
				}
				row.append(nodeList.item(i).getTextContent());
			}
			context.write(getFileName(validOutputPath, key), new Text(row.toString()));
		} catch (Exception e) {
			context.write(getFileName(invalidOutputPath, key),
					new Text(value.toString() + COL_SEPARATOR + e.getMessage()));
		}
	}

	private Text getFileName(String outputPath, FileLineWritable key) {
		Path file = new Path(key.getFileName());
		String filename = file.getName().split("-")[0];
		return new Text(outputPath + "-" + filename);
	}
}