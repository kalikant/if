package com.scb.edmhdpif.xmlvalidator;

import java.io.IOException;
import java.nio.channels.ClosedChannelException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;

public class XMLValidatorReducer extends Reducer<Text, Text, NullWritable, Text> {

	private String outputPath = null;

	private Configuration conf;
	private MultipleOutputs<NullWritable, Text> mout;
	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;

	private String validPrefix;
	private String invalidPrefix;

	private Set<String> files = new HashSet<String>();

	private static final Logger logger = Logger.getLogger(XMLValidatorReducer.class);

	private final String tcStartTime = EdmHdpIfCommon.getUnixTime();
	private final Map<String, String> rowCountPathsMap = new HashMap<>();
	private Context context;
	private String rowCountPath = null;

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info(this.getClass() + " setup initiated");
		conf = context.getConfiguration();
		this.context = context;
		outputPath = conf.get(XMLValidator.XMLVALIDATOR_OUTPUT_PATH);
		COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
				COL_SEPARATOR));

		validPrefix = conf.get(XMLValidator.EDMHDPIF_XMLVALIDATOR_VALID_PREFIX);
		invalidPrefix = conf.get(XMLValidator.EDMHDPIF_XMLVALIDATOR_INVALID_PREFIX);

		rowCountPath = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "") + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_ROWCOUNTS_DATABASE, "") + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_ROWCOUNTS_TABLE, "") + "/"
				+ EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_ROWCOUNTS_PARTITION, ""));
		logger.info(this.getClass() + " setup finished");

	}

	@Override
	protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

		// Open outputs
		mout = new MultipleOutputs<NullWritable, Text>(context);

		logger.info("Writing values in " + key.toString());
		int writeCount = 0;
		for (Text t : values) {
			mout.write("output", NullWritable.get(), t, key.toString());
			writeCount++;
		}

		// Write type of file: valid or invalid
		boolean valid = false;
		if (key.toString().contains(validPrefix)) {
			if (!key.toString().contains(invalidPrefix)) {
				valid = true;
			} else {
				// key contains both valid and invalid prefix
				if (validPrefix.length() > invalidPrefix.length()) {
					valid = true;
				}
			}
		}
		String text = key.toString() + COL_SEPARATOR + valid + COL_SEPARATOR;
		if (!valid) {
			text = text + "Rejected messages";
		}
		files.add(text);

		// Write rowcount
		String table = new Path(key.toString()).getName();
		writeRowCount(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, ""),
				conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, ""), writeCount, table);

		// Force write to save memory
		try {
			mout.close();
		} catch (ClosedChannelException e) {
			// If we use compression, then the channel could be already closed.
			// Ignore the exception
		}
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		// Open outputs
		mout = new MultipleOutputs<NullWritable, Text>(context);
		// Write output paths
		for (String f : files) {
			mout.write("output", NullWritable.get(), new Text(f), outputPath);
		}

		// Write row count
		Text writeValue = new Text();
		String fileName = rowCountPath + "/xmlvalidator-" + UUID.randomUUID();
		for (String row : rowCountPathsMap.values()) {
			String[] splittedRow = row.split(COL_SEPARATOR, -1);
			String database = splittedRow[0];
			String outputtable = splittedRow[1];
			String count = splittedRow[2];
			String table = splittedRow[3];
			logger.info("Adding row count information for table " + database + "." + outputtable + " for " + table
					+ " Count: " + count + " File: " + fileName);
			writeValue.set(row);
			mout.write("rowcounts", NullWritable.get(), writeValue, fileName);
		}

		// Close outputs
		try {
			mout.close();
		} catch (ClosedChannelException e) {
			// If we use compression, then the channel could be already closed.
			// Ignore the exception
		}
	}

	/**
	 * Write a row count line. The row count is wrote in the cleanup method,
	 * this method stores the count in a Map, or modifies the stored line if
	 * already exists.
	 * 
	 * @param database
	 *            Database field of the RowCount table.
	 * @param outputTable
	 *            Table field of the RowCount table.
	 * @param writeCount
	 *            Row count to be set or added.
	 * @param tableName
	 *            The functional table name
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void writeRowCount(String database, String outputTable, int writeCount, String tableName)
			throws IOException, InterruptedException {

		// Use composite key since tableName alone counts rowid + rowhist
		// together
		String composite = new StringBuilder(database).append("#").append(outputTable).append("#").append(tableName)
				.toString();
		String row = rowCountPathsMap.get(composite);
		if (row == null) {
			row = new StringBuilder(database).append(COL_SEPARATOR).append(outputTable).append(COL_SEPARATOR)
					.append(writeCount).append(COL_SEPARATOR).append(tableName).append(COL_SEPARATOR)
					.append(tcStartTime).append(COL_SEPARATOR).append(context.getJobName()).append(COL_SEPARATOR)
					.append(context.getTaskAttemptID()).toString();
		} else {
			Integer count = Integer.valueOf(row.split(COL_SEPARATOR, -1)[2]);
			row = new StringBuilder(database).append(COL_SEPARATOR).append(outputTable).append(COL_SEPARATOR)
					.append((count + writeCount)).append(COL_SEPARATOR).append(tableName).append(COL_SEPARATOR)
					.append(tcStartTime).append(COL_SEPARATOR).append(context.getJobName()).append(COL_SEPARATOR)
					.append(context.getTaskAttemptID()).toString();
		}
		rowCountPathsMap.put(composite, row);
	}
}