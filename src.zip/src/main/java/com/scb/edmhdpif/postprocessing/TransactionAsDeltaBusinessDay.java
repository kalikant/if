package com.scb.edmhdpif.postprocessing;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.CombineSequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.PathFinder;
import com.scb.edmhdpif.lib.PathFinder.MatchType;
import com.scb.edmhdpif.sri.SRIMapperTxn;
import com.scb.edmhdpif.sri.SRIOpenMapper;
import com.scb.edmhdpif.sri.SRIReducer;

public class TransactionAsDeltaBusinessDay extends Configured implements Tool {

	private static final Logger logger = Logger
			.getLogger(TransactionAsDeltaBusinessDay.class);

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(),
				new TransactionAsDeltaBusinessDay(), args);
		System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {

		Configuration conf = super.getConf();

		String oozieConfigurationLocation = System
				.getProperty("oozie.action.conf.xml");
		if (oozieConfigurationLocation != null) {
			logger.info("Loading Oozie configuration from "
					+ oozieConfigurationLocation);
			conf.addResource(new Path(oozieConfigurationLocation));
		}
		EdmHdpIfCommon.checkRequiredParameters(conf, new String[] {
				EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE,
				EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH,
				EdmHdpIfConstants.EDMHDPIF_INDIVIDUAL_TABLEPREFIX,
				EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE,
				EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION,
				EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS,
				EdmHdpIfConstants.EDMHDPIF_POSTPROCESSING_DATABASE,
				EdmHdpIfConstants.EDMHDPIF_POSTPROCESSING_PARTITION,
				EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE,
				EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE,
				EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_PARTITION,
				EdmHdpIfConstants.EDMHDPIF_BATCHTOPARTITION_DATABASE,
				EdmHdpIfConstants.EDMHDPIF_BATCHTOPARTITION_TABLE });

		// Check next working date
		if (conf.get(EdmHdpIfConstants.EDMHDPIF_EOD_MARKER) == null) {
			throw new Exception("No End Of Day marker, exiting");
		}

		// Get all partitions between current business day and previous business
		// day
		List<String> partitions = getPartitionsBetweenCurrentAndPreviousDay(conf);
		// Set parameters for SRIReducer
		conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE,
				conf.get(EdmHdpIfConstants.EDMHDPIF_POSTPROCESSING_DATABASE));

		Job job = Job.getInstance(conf,
				"EdmHdpIf-TransactionAsDeltaBusinessDay");

		job.setJarByClass(TransactionAsDeltaBusinessDay.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(SRIOpenMapper.class);
		job.setReducerClass(SRIReducer.class);

		// Delete output folder
		FileSystem fileSystem = FileSystem.get(conf);
		Path outputPath = new Path(
				conf.get(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH));
		logger.info("Output path set to " + outputPath);
		EdmHdpIfCommon.deletePath(fileSystem, outputPath + "/");

		String hiveWarehouse = conf.get(
				EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/");

		final String inputLocation = hiveWarehouse + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE) + "/";
		final Path inputPath = new Path(inputLocation);
		final String inputPartition = EdmHdpIfCommon.getPartition(conf
				.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION));
		final String inputPartitionDate = EdmHdpIfCommon.getPartitionDate(conf
				.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION));
		final String tablePrefix = conf
				.get(EdmHdpIfConstants.EDMHDPIF_INDIVIDUAL_TABLEPREFIX);
		final String postProcessingLocation = hiveWarehouse + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_POSTPROCESSING_DATABASE)
				+ "/";
		final String rerunTables = conf
				.get(EdmHdpIfConstants.EDMHDPIF_RERUN_TABLE);
		logger.info("Open table location: " + inputLocation);
		logger.info("Post processing table location: " + postProcessingLocation);

		List<Path> outputPathList = new ArrayList<Path>();

		try {
			// If not a rerun, load all tables
			if (rerunTables == null) {
				// Add SRI input files
				if (!fileSystem.exists(inputPath)) {
					logger.info("Input path doesn't exist, skipping: "
							+ inputPath);

				}
				PathFinder inputFiles = new PathFinder(conf, inputLocation);
				inputFiles.setTableName(tablePrefix);
				inputFiles.setTableMatchType(MatchType.STARTSWITH);
				inputFiles.setTableSourceType("txn");
				List<String> transitionTables = new ArrayList<String>();
				for (Path file : inputFiles.getFiles()) {
					String table = file.getName();

					transitionTables.add(table);
					// Do delta type processing on tables with key columns
					String keycols = (String) conf
							.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE
									+ table + ".keycols");
					if (keycols != null && !keycols.trim().isEmpty()
							&& !"NA".equalsIgnoreCase(keycols)) {
						logger.info("Table " + table
								+ ": is as transaction table with key columns.");
						conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE
								+ table + ".sourcetype", "delta");
						job.getConfiguration().set(
								EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE
										+ table + ".sourcetype", "delta");
					} else {
						logger.info("Table "
								+ table
								+ ": is as transaction table without key columns.");
					}
				}

				for (String table : transitionTables) {
					final PathFinder sriFilesFinder = new PathFinder(conf,
							inputLocation);
					sriFilesFinder.setTableName(table);
					String sourceType = conf.get(
							EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE
									+ table + ".sourcetype", "delta");
					for (String partition : partitions) {
						String currentPartition = inputPartition.replaceAll(
								inputPartitionDate, partition);
						sriFilesFinder.setPartition(currentPartition);
						List<Path> sriFiles = sriFilesFinder.getFiles();
						logger.info("Looking for SRI files on location "
								+ inputLocation + " with table name " + table
								+ " on partition " + currentPartition + ": "
								+ sriFiles.size() + " files found.");

						for (Path path : sriFiles) {
							if ("delta".equals(sourceType)) {
								logger.info("Adding SRI delta file: " + path);
								MultipleInputs.addInputPath(job, path,
										CombineSequenceFileInputFormat.class,
										SRIOpenMapper.class);
							} else {
								logger.info("Adding SRI txn file: " + path);
								MultipleInputs.addInputPath(job, path,
										CombineSequenceFileInputFormat.class,
										SRIMapperTxn.class);
							}
						}
					}

					/*
					 * Output directories to delete
					 */
					// Post processing path
					PathFinder postprocessingPath = new PathFinder(conf,
							postProcessingLocation);
					postprocessingPath.setTableName(table);
					postprocessingPath
							.setPartition(EdmHdpIfCommon.getPartition(conf
									.get(EdmHdpIfConstants.EDMHDPIF_POSTPROCESSING_PARTITION)));
					outputPathList.addAll(postprocessingPath.getFiles());

					// Duplicates path
					PathFinder duplicatesPath = new PathFinder(
							conf,
							conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE)
									+ "/"
									+ conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE));
					duplicatesPath
							.setTableName(conf
									.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE));
					duplicatesPath
							.setPartition(EdmHdpIfCommon.getPartition(conf
									.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_PARTITION)));
					duplicatesPath.setFileName(job.getJobName());
					outputPathList.addAll(duplicatesPath.getFiles());
				}

			} else {
				// If it's a rerun, only load the table to rerun
				logger.info("RERUN of table(s) " + rerunTables);
				String[] rerunTableNames = rerunTables.split(",");
				for (String rerunTableName : rerunTableNames) {
					String sourceType = conf
							.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE
									+ rerunTableName + ".sourcetype");
					if (sourceType == null
							|| "delta".equalsIgnoreCase(sourceType)) {
						continue;
					}

					String keycols = (String) conf
							.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE
									+ rerunTableName + ".keycols");
					if (keycols != null && !keycols.trim().isEmpty()
							&& !"NA".equalsIgnoreCase(keycols)) {
						logger.info("Table " + rerunTableName
								+ ": is as transaction table with key columns.");
						conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE
								+ rerunTableName + ".sourcetype", "delta");
						job.getConfiguration().set(
								EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE
										+ rerunTableName + ".sourcetype",
								"delta");
					} else {
						logger.info("Table "
								+ rerunTableName
								+ ": is as transaction table without key columns.");
					}

					final PathFinder sriFilesFinder = new PathFinder(conf,
							inputLocation);
					sriFilesFinder.setTableName(rerunTableName);
					for (String partition : partitions) {
						partition = inputPartition.replaceAll(
								inputPartitionDate, partition);
						// Add SRI input files
						sriFilesFinder.setPartition(partition);
						List<Path> sriFiles = sriFilesFinder.getFiles();
						logger.info("Looking for SRI files on location "
								+ inputLocation + " with table name "
								+ rerunTableName + " on partition " + partition
								+ ": " + sriFiles.size() + " files found.");

						for (Path path : sriFiles) {
							logger.info("Adding SRI file: " + path);
							if ("delta".equalsIgnoreCase(sourceType)) {
								MultipleInputs.addInputPath(job, path,
										CombineSequenceFileInputFormat.class,
										SRIOpenMapper.class);
							} else {
								MultipleInputs.addInputPath(job, path,
										CombineSequenceFileInputFormat.class,
										SRIMapperTxn.class);
							}
						}
						/*
						 * Output directories to delete
						 */
						// Post processing path
						PathFinder postprocessingPath = new PathFinder(conf,
								postProcessingLocation);
						postprocessingPath.setTableName(rerunTableName);
						postprocessingPath
								.setPartition(EdmHdpIfCommon.getPartition(conf
										.get(EdmHdpIfConstants.EDMHDPIF_POSTPROCESSING_PARTITION)));
						outputPathList.addAll(postprocessingPath.getFiles());

						// Duplicates path
						PathFinder duplicatesPath = new PathFinder(
								conf,
								conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE)
										+ "/"
										+ conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE));
						duplicatesPath
								.setTableName(conf
										.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE));
						duplicatesPath
								.setPartition(EdmHdpIfCommon.getPartition(conf
										.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_PARTITION)));
						duplicatesPath.setFileName(job.getJobName() + "-"
								+ rerunTableName);
						outputPathList.addAll(duplicatesPath.getFiles());
					}
				}
				// If no input paths set (e.g. rerun for a table that has no
				// file), then set
				// input path to empty directory so that job succeeds
				if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
					EdmHdpIfCommon.setEmptyInputPath(job, fileSystem,
							outputPath);
				}
			}

			// Delete output paths
			for (Path deletePath : outputPathList) {
				EdmHdpIfCommon.deletePath(fileSystem, deletePath.toString());
			}

			FileOutputFormat.setOutputPath(job, outputPath);
			MultipleOutputs.addNamedOutput(job, "data",
					SequenceFileOutputFormat.class, NullWritable.class,
					Text.class);
			MultipleOutputs.addNamedOutput(job, "rowcounts",
					SequenceFileOutputFormat.class, NullWritable.class,
					Text.class);
			MultipleOutputs.addNamedOutput(job, "duplicates",
					SequenceFileOutputFormat.class, NullWritable.class,
					Text.class);

			if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
				// No input paths
				logger.warn("Job not launched: no input paths");
				return 0;
			}
			return (job.waitForCompletion(true) ? 0 : 1);
		} catch (ClassNotFoundException | IOException | InterruptedException e) {
			logger.error(e.getMessage(), e);
			throw e;
		}
	}

	private List<String> getPartitionsBetweenCurrentAndPreviousDay(
			Configuration conf) throws Exception {

		// As we are in the last partition after the EOD happens, the next
		// working date is the current business day
		String businessDay = conf
				.get(EdmHdpIfConstants.EDMHDPIF_SRI_NEXTWORKINGDATE);

		if (businessDay == null) {
			throw new Exception("Cannot find business day");
		}

		logger.info("Using business day " + businessDay);

		// Read all the files in the BATCH_TO_PARTITION table
		// Get all partitions between current business day and previous business
		// day
		FileSystem fileSystem = FileSystem.get(conf);
		List<String> partitions = new ArrayList<String>();
		PathFinder btpFilesFinder = new PathFinder(
				conf,
				conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE)
						+ "/"
						+ conf.get(EdmHdpIfConstants.EDMHDPIF_BATCHTOPARTITION_DATABASE));
		btpFilesFinder.setTableName(conf
				.get(EdmHdpIfConstants.EDMHDPIF_BATCHTOPARTITION_TABLE));
		btpFilesFinder.setPartition("");

		// Read all the BatchToPartition files and write the content to eods
		BufferedReader reader = null;
		String line;
		for (Path file : btpFilesFinder.getFiles()) {
			try {
				reader = new BufferedReader(new InputStreamReader(
						fileSystem.open(file)));
				while ((line = reader.readLine()) != null) {
					String[] splittedLine = line.split(
							Character.toString('\2'), -1);
					if (splittedLine.length != 4) {
						continue;
					}
					if (businessDay.equals(splittedLine[2])) {
						partitions.add(splittedLine[3]);
					}
				}
			} catch (IOException e) {
				logger.error(
						"Error reading file " + file + ": " + e.getMessage(), e);
			} finally {
				reader.close();
			}
		}
		logger.info("Found " + partitions.size()
				+ " partitions for business day " + businessDay);

		// Set post processing partition
		String postProcessingPartition = EdmHdpIfCommon.getPartition(conf
				.get(EdmHdpIfConstants.EDMHDPIF_POSTPROCESSING_PARTITION));
		postProcessingPartition = postProcessingPartition.replaceAll(
				EdmHdpIfCommon.getPartitionDate(postProcessingPartition),
				businessDay);
		conf.set(EdmHdpIfConstants.EDMHDPIF_POSTPROCESSING_PARTITION,
				postProcessingPartition);
		conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION,
				postProcessingPartition);

		return partitions;
	}
}
