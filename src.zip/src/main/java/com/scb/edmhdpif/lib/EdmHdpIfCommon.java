package com.scb.edmhdpif.lib;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.PathFilter;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.input.CFInputFormat;

public class EdmHdpIfCommon {
	private static final Logger logger = Logger.getLogger(EdmHdpIfCommon.class);

	private final static String UNIX_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	private static SimpleDateFormat unixTimeFormat = new SimpleDateFormat(UNIX_TIME_FORMAT);

	/**
	 * Gets the current time in Unix format
	 * 
	 * @return The current time in Unix format.
	 */
	public static String getUnixTime() {
		// synchronized because DateFormat is unsafe for multithreaded use
		synchronized (unixTimeFormat) {
			return unixTimeFormat.format(Calendar.getInstance().getTime());
		}
	}

	/**
	 * Get the date part of a string representing a partition.
	 * 
	 * @param partitionstr
	 *            The partition string.
	 * @return The date part of the partition.
	 */
	public static String getPartitionDate(String partitionstr) {
		if (partitionstr == null) {
			return null;
		}
		String partition = getPartition(partitionstr);
		if (partition.contains("=")) {
			partition = partition.substring(partition.indexOf('=') + 1).trim();
		}
		return partition;
	}

	/**
	 * Clean the partition string from any symbols.
	 * 
	 * @param partitionstr
	 *            The partition string.
	 * @return The partition string, clean from symbols, like () or ''.
	 */
	public static String getPartition(String partitionstr) {
		if (partitionstr == null) {
			return null;
		}
		String partition = partitionstr.trim();
		if (partition.startsWith("(") && partition.endsWith(")")) {
			partition = partition.substring(1, partition.length() - 1);
		}
		partition = partition.replace("'", "");
		return partition;
	}

	/**
	 * Get files with exact name, from a path using filters.
	 * 
	 * @param fileSystem
	 *            The file system where look for the path.
	 * @param parentPath
	 *            The path.
	 * @param name
	 *            Name to filter files with.
	 * @return The list of files in parentPath starting by name.
	 * @throws IOException
	 */
	private static FileStatus[] getFilteredFilesByName(final FileSystem fileSystem, final Path parentPath,
			final String name) throws IOException {
		try {
			FileStatus[] fileList = fileSystem.listStatus(parentPath, new PathFilter() {
				@Override
				public boolean accept(Path path) {
					if (name == null) {
						return true;
					}
					return path.getName().startsWith(name);
				}
			});
			if (fileList == null) {
				fileList = new FileStatus[] {};
			}
			return fileList;
		} catch (FileNotFoundException e) {
			logger.warn("Ignoring path " + parentPath + ": " + e.getMessage());
			return new FileStatus[] {};
		}
	}

	/**
	 * Delete a path. If the provided path is a directory, delete it
	 * recursively. If it's a file, delete the files starting with the file
	 * name.
	 * 
	 * @param deletePathStr
	 *            Path to delete
	 * @param fileSystem
	 *            Indicates if it's expected to be a directory or not.
	 * @throws IOException
	 */
	public static void deletePath(FileSystem fileSystem, final String deletePathStr) throws IOException {
		// If exists and it's a directory, delete
		boolean directory = deletePathStr.endsWith("/");
		Path deletePath = new Path(deletePathStr);
		if (directory || (fileSystem.exists(deletePath) && fileSystem.isDirectory(deletePath))) {
			if (fileSystem.exists(deletePath)) {
				// Check minimum levels of directory, to avoid deletion of
				// parent directories if parameters are incorrect or not set
				if (deletePath.toString().split("/").length < 4) {
					logger.error("Skipping unsafe delete of directory, please check parameters: " + deletePath);
				} else {
					fileSystem.delete(deletePath, true);
					logger.info("Deleted directory: " + deletePath);
				}
			}
		} else {
			Path parentPath = deletePath.getParent();
			if (fileSystem.exists(parentPath) && fileSystem.isDirectory(parentPath)) {
				// Look for the files matching deletePath
				FileStatus[] fileStatus = getFilteredFilesByName(fileSystem, parentPath, deletePath.getName());
				for (FileStatus file : fileStatus) {
					fileSystem.delete(file.getPath(), true);
					logger.info("Deleted  file: " + file.getPath());
				}
			}
		}
	}

	/**
	 * Check for required parameters, throws an exception if some of the
	 * required parameters are missing.
	 * 
	 * @param conf
	 * @param parameters
	 * @throws RuntimeException
	 */
	public static void checkRequiredParameters(Configuration conf, String[] parameters) throws RuntimeException {
		ArrayList<String> missingParams = new ArrayList<String>();
		for (String param : parameters) {
			if (conf.get(param) == null) {
				missingParams.add(param);
			}
		}
		if (!missingParams.isEmpty()) {
			StringBuilder error = new StringBuilder("Required parameters not set: ");
			for (String param : missingParams) {
				error.append("\n").append(param);
			}
			throw new RuntimeException(error.toString());
		}

	}

	/**
	 * Set the input path to an empty directory, that is formed by concatenating
	 * the keyword "_empty" to the path parameter
	 * 
	 * @param job
	 *            The job to set the input path in
	 * @param fileSystem
	 *            handle to a filesystem (usually HDFS)
	 * @param path
	 *            the path to use as a template to create the _empty directory
	 *            (usually, the output path of the job)
	 */
	public static void setEmptyInputPath(Job job, FileSystem fileSystem, Path path) throws IOException {
		String emptyDir = Path.getPathWithoutSchemeAndAuthority(path) + "_empty";
		logger.info("Setting input path to empty directory: " + emptyDir);
		createDirectory(fileSystem, emptyDir);
		MultipleInputs.addInputPath(job, new Path(emptyDir), CFInputFormat.class);
	}

	/**
	 * Create a directory. If the path already exists, delete it.
	 * 
	 * @param fileSystem
	 *            Filesystem in which to create
	 * @param dirStr
	 *            Directory to create.
	 * @throws IOException
	 */
	public static void createDirectory(FileSystem fileSystem, final String dirStr) throws IOException {
		Path dirPath = new Path(dirStr);
		if (fileSystem.exists(dirPath)) {
			logger.info(dirStr + " exists; so deleting it");
			fileSystem.delete(dirPath, false);
		}
		fileSystem.mkdirs(dirPath);
	}

	public static String getTableNameFromContext(Context context) {
		Path filePath = null;
		String fileName = context.getConfiguration().get("map.input.file");

		if (fileName == null) {
			FileSplit fileSplit = null;
			InputSplit split = context.getInputSplit();
			Class<? extends InputSplit> splitClass = split.getClass();

			if (FileSplit.class.isAssignableFrom(splitClass)) {
				fileSplit = (FileSplit) split;
			} else if ("org.apache.hadoop.mapreduce.lib.input.TaggedInputSplit".equals(splitClass.getName())) {
				// begin reflection hackery...
				try {
					Method getInputSplitMethod = splitClass.getDeclaredMethod("getInputSplit");
					getInputSplitMethod.setAccessible(true);
					fileSplit = (FileSplit) getInputSplitMethod.invoke(split);
				} catch (Exception e) {
					// wrap and re-throw error
					throw new RuntimeException("Error trying to get table name from file: " + e);
				}
				// end reflection hackery
			}
			if (fileSplit == null) {
				throw new RuntimeException("Could not find input file");
			}
			filePath = fileSplit.getPath();
		} else {
			filePath = new Path(fileName);
		}

		return filePath.getParent().getParent().getName();
	}

	public static String unicodeReplacement(String s) {
		StringBuffer buf = new StringBuffer();
		Matcher m = Pattern.compile("\\\\u([0-9A-Fa-f]{4})").matcher(s);
		while (m.find()) {
			try {
				int cp = Integer.parseInt(m.group(1), 16);
				m.appendReplacement(buf, "");
				buf.appendCodePoint(cp);
			} catch (NumberFormatException e) {
			}
		}
		m.appendTail(buf);
		s = buf.toString();
		return s;
	}
}