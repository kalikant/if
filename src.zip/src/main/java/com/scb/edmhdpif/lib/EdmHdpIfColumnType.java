package com.scb.edmhdpif.lib;

import org.apache.hadoop.conf.Configuration;

import com.scb.edmhdpif.verifytypes.checker.VerifySchema;

public class EdmHdpIfColumnType implements Comparable<EdmHdpIfColumnType> {
    private String journalTime;
    private String operationType;

    private final String rowId;
    private String tableName;
    private String transactionId;
    private String userId;
    private String data;

    // Time columns
    private String startDate;
    private String startTime;
    private String endDate;
    private String endTime;
    private String deleteFlag;
    private boolean cdcFields = false;
    private String deleteValue;
    private Integer deleteIndex;
    private String data_separator;
    private static final int _FIXED_CDC_COL_COUNT = 4;
    private static final int _FIXED_TIME_COL_COUNT = 5;
    private static final int NO_DELETE_INDEX = -99;

    public EdmHdpIfColumnType(String line, boolean timeColumns, Configuration conf) {
        this(line, conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, EdmHdpIfConstants.COL_SEPARATOR), conf.get(
                EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, EdmHdpIfConstants.DATA_SEPARATOR), timeColumns, conf);
    }

    public EdmHdpIfColumnType(String line, String col_separator, String data_separator, boolean timeColumns,
            Configuration conf) {

        this.data_separator = data_separator;
        int tcolumns = 0;
        if (timeColumns) {
            tcolumns = _FIXED_TIME_COL_COUNT;
        }
        int cdccol = 0;
        if (conf.getBoolean(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS_BOOLEAN, false)) {
            cdcFields = true;
            cdccol = _FIXED_CDC_COL_COUNT;
        }
        String columns[] = line.split("\\" + col_separator, -1);
        tableName = columns[0];
        if (columns.length < 3 + tcolumns) {
            throw new RuntimeException("Incorrect row format: " + line + ". Minimum columns expected: "
                    + (3 + tcolumns) + ", found: " + columns.length);
        }
        rowId = columns[1];
        int timeColumnOffset = columns.length - tcolumns;
        if (col_separator.equals(data_separator)) {
            if (cdcFields) {
                journalTime = columns[2];
                transactionId = columns[3];
                operationType = columns[4];
                userId = columns[5];
            }
            StringBuilder datasb = new StringBuilder(columns[2 + cdccol]);
            for (int i = 3 + cdccol; i < timeColumnOffset; i++) {
                datasb.append(data_separator).append(columns[i]);
            }
            data = datasb.toString();
        } else {
            data = columns[2];
            if (cdcFields) {
                // Split rowData
                String[] rowData = columns[2].split("\\" + data_separator, -1);
                if (rowData.length < cdccol + 1) {
                    throw new RuntimeException("Incorrect data format. RowData length: " + rowData.length + " RowId: "
                            + rowId + " Data: " + line);
                }
                journalTime = rowData[0];
                transactionId = rowData[1];
                operationType = rowData[2];
                userId = rowData[3];
                data = columns[2].substring(journalTime.length() + transactionId.length() + operationType.length()
                        + userId.length() + 4);
            }
        }
        if (timeColumns) {
            startDate = columns[timeColumnOffset];
            if (columns[timeColumnOffset + 1] != null && !columns[timeColumnOffset + 1].isEmpty()) {
                startTime = columns[timeColumnOffset + 1];
            }
            endDate = columns[timeColumnOffset + 2];
            if (columns[timeColumnOffset + 3] != null && !columns[timeColumnOffset + 3].isEmpty()) {
                endTime = columns[timeColumnOffset + 3];
            }
            deleteFlag = columns[timeColumnOffset + 4];
        }

        // For non-CDC data, try to retrieve the DeleteField value
        if (!cdcFields) {
            Integer deleteIndex = conf.getInt(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
                    + EdmHdpIfConstants.SUFFIX_CONFIG_DELETEINDEX, NO_DELETE_INDEX);
            if (deleteIndex == NO_DELETE_INDEX) {
                // deleteIndex not found for this table
                String deleteField = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
                        + EdmHdpIfConstants.SUFFIX_CONFIG_DELETEFIELD);
                deleteIndex = -1; // No delete field
                if (deleteField != null && !deleteField.trim().isEmpty()) {
                    deleteField = deleteField.trim();
                    // Retrieve schema and look for the delete field
                    VerifySchema schema = new VerifySchema(conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE
                            + tableName + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA), false);
                    for (int index = 0; index < schema.getSchemaColumns().size(); index++) {
                        if (deleteField.equals(schema.getSchemaColumns().get(index).getName())) {
                            deleteIndex = index;
                            break;
                        }
                    }
                }
                conf.setInt(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
                        + EdmHdpIfConstants.SUFFIX_CONFIG_DELETEINDEX, deleteIndex);
            }
            this.deleteIndex = deleteIndex;
            deleteValue = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName
                    + EdmHdpIfConstants.SUFFIX_CONFIG_DELETEVALUE);
        }

    }

    public EdmHdpIfColumnType(EdmHdpIfColumnType other) {
        this.journalTime = other.journalTime;
        this.operationType = other.operationType;
        this.rowId = other.rowId;
        this.tableName = other.tableName;
        this.transactionId = other.transactionId;
        this.userId = other.userId;
        this.data = other.data;
        this.startDate = other.startDate;
        this.startTime = other.startTime;
        this.endDate = other.endDate;
        this.endTime = other.endTime;
        this.cdcFields = other.cdcFields;
        this.deleteFlag = other.deleteFlag;
        this.deleteIndex = other.deleteIndex;
    }

    @Override
    public int compareTo(EdmHdpIfColumnType o) {
        int compare = 0;
        if (cdcFields) {
            if (this.journalTime != null) {
                compare = this.journalTime.compareTo(o.getJournalTime());
                // If same journaltime, compare by transaction id
                if (compare == 0 && this.transactionId != null) {
                    compare = this.transactionId.compareTo(o.transactionId);
                }
            }
        } else {
            // Time not set
            if ("-1".equals(this.startTime)) {
                return 1;
            }
            if ("-1".equals(o.getStartTime())) {
                return -1;
            }
            if (this.startTime != null) {
                compare = this.startTime.compareTo(o.getStartTime());
            }
        }
        return compare == 0 ? 1 : compare;
    }

    /**
     * Get row, without the table name
     * 
     * @return row without the table name
     */
    public String getRow(String col_separator, String data_separator, boolean timeColumns) {
        StringBuilder ret = new StringBuilder(rowId).append(col_separator);
        if (cdcFields) {
            ret.append(journalTime).append(data_separator).append(transactionId).append(data_separator)
                    .append(operationType).append(data_separator).append(userId).append(data_separator);
        }
        ret.append(data);
        if (timeColumns) {
            ret.append(col_separator).append(startDate).append(col_separator)
                    .append(startTime == null ? "" : startTime).append(col_separator).append(endDate)
                    .append(col_separator).append(endTime == null ? "" : endTime).append(col_separator)
                    .append(deleteFlag);
        }
        return ret.toString();
    }

    /**
     * Get row, including the table name
     * 
     * @return row including the table name
     */
    public String getRowWithTableName(String col_separator, String data_separator, boolean timeColumns) {
        return new StringBuilder(tableName).append(col_separator)
                .append(getRow(col_separator, data_separator, timeColumns)).toString();
    }

    public String getJournalTime() {
        return journalTime;
    }

    public void setJournalTime(String journalTime) {
        this.journalTime = journalTime;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public boolean dataEquals(EdmHdpIfColumnType otherColumn) {
        if (otherColumn == null) {
            return false;
        }
        // Compare dataCols
        return data.equals(otherColumn.data);
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (cdcFields ? 1231 : 1237);
        result = prime * result + ((data == null) ? 0 : data.hashCode());
        result = prime * result + ((deleteFlag == null) ? 0 : deleteFlag.hashCode());
        result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
        result = prime * result + ((endTime == null) ? 0 : endTime.hashCode());
        result = prime * result + ((journalTime == null) ? 0 : journalTime.hashCode());
        result = prime * result + ((operationType == null) ? 0 : operationType.hashCode());
        result = prime * result + ((rowId == null) ? 0 : rowId.hashCode());
        result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
        result = prime * result + ((startTime == null) ? 0 : startTime.hashCode());
        result = prime * result + ((tableName == null) ? 0 : tableName.hashCode());
        result = prime * result + ((transactionId == null) ? 0 : transactionId.hashCode());
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EdmHdpIfColumnType other = (EdmHdpIfColumnType) obj;
        if (cdcFields != other.cdcFields)
            return false;
        if (data == null) {
            if (other.data != null)
                return false;
        } else if (!data.equals(other.data))
            return false;
        if (deleteFlag == null) {
            if (other.deleteFlag != null)
                return false;
        } else if (!deleteFlag.equals(other.deleteFlag))
            return false;
        if (endDate == null) {
            if (other.endDate != null)
                return false;
        } else if (!endDate.equals(other.endDate))
            return false;
        if (endTime == null) {
            if (other.endTime != null)
                return false;
        } else if (!endTime.equals(other.endTime))
            return false;
        if (journalTime == null) {
            if (other.journalTime != null)
                return false;
        } else if (!journalTime.equals(other.journalTime))
            return false;
        if (operationType == null) {
            if (other.operationType != null)
                return false;
        } else if (!operationType.equals(other.operationType))
            return false;
        if (rowId == null) {
            if (other.rowId != null)
                return false;
        } else if (!rowId.equals(other.rowId))
            return false;
        if (startDate == null) {
            if (other.startDate != null)
                return false;
        } else if (!startDate.equals(other.startDate))
            return false;
        if (startTime == null) {
            if (other.startTime != null)
                return false;
        } else if (!startTime.equals(other.startTime))
            return false;
        if (tableName == null) {
            if (other.tableName != null)
                return false;
        } else if (!tableName.equals(other.tableName))
            return false;
        if (transactionId == null) {
            if (other.transactionId != null)
                return false;
        } else if (!transactionId.equals(other.transactionId))
            return false;
        if (userId == null) {
            if (other.userId != null)
                return false;
        } else if (!userId.equals(other.userId))
            return false;
        return true;
    }

    public String getRowId() {
        return rowId;
    }

    public boolean isOperationTypeDelete() {
        if (cdcFields) {
            return "D".equalsIgnoreCase(operationType);
        } else {
            if (deleteIndex == -1) {
                return "1".equals(deleteFlag);
            } else {
                String[] cols = data.split("\\" + data_separator, -1);
                if (deleteIndex > cols.length) {
                    throw new RuntimeException("Incorrect delete field. Index: " + deleteIndex + " number of columns:"
                            + cols.length);
                }
                if (deleteValue == null) {
                    return cols[deleteIndex] == null;
                } else {
                    return cols[deleteIndex].equals(deleteValue);
                }
            }
        }
    }

    public void setOperationTypeDelete() {
        if (cdcFields) {
            setOperationType("D");
        } else {
            if (deleteIndex == -1) {
                deleteFlag = "1";
            } else {
                String[] cols = data.split("\\" + data_separator, -1);
                if (deleteIndex > cols.length) {
                    throw new RuntimeException("Incorrect delete field. Index: " + deleteIndex + " number of columns:"
                            + cols.length);
                }
                cols[deleteIndex] = deleteValue;
                // Reconstruct data
                StringBuilder dataBuilder = new StringBuilder();
                for (String c : cols) {
                    if (dataBuilder.length() > 0) {
                        dataBuilder.append(data_separator);
                    }
                    dataBuilder.append(c);
                }
                data = dataBuilder.toString();
            }

        }
    }
}
