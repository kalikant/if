package com.scb.edmhdpif.lib;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HatColumn {

	private int width;

	private boolean validateDate;

	private boolean validateRowCount;

	private String mask;

	private Logger logger = LoggerFactory.getLogger(HatColumn.class);

	public HatColumn(String column) {
		// Expected format:
		// name type(width) [MASK mask] [VALIDATEDATE] [VALIDATEROWCOUNT]
		logger.info("Header/Trailer column: " + column);
		String[] words = column.split("\\s+");
		int len = words.length;
		for (int i = 1; i < len; i++) {
			if (words[i].contains("(") && words[i].contains(")")) {
				// Find width
				String w = words[i].substring(words[i].indexOf('(') + 1);
				w = w.substring(0, w.indexOf(')'));
				width = Integer.valueOf(w);
				continue;
			}
			if ("MASK".equals(words[i])) {
				i++;
				mask = words[i];
				logger.info("Found mask: " + mask);
				continue;
			}
			if ("VALIDATEDATE".equals(words[i])) {
				validateDate = true;
				continue;
			}
			if ("VALIDATEROWCOUNT".equals(words[i])) {
				validateRowCount = true;
				continue;
			}
		}
	}

	public int getWidth() {
		return width;
	}

	public boolean isValidateDate() {
		return validateDate;
	}

	public boolean isValidateRowCount() {
		return validateRowCount;
	}

	public String getMask() {
		return mask;
	}
}
