package com.scb.edmhdpif.lib.input;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.Seekable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.CodecPool;
import org.apache.hadoop.io.compress.CompressionCodec;
import org.apache.hadoop.io.compress.CompressionCodecFactory;
import org.apache.hadoop.io.compress.Decompressor;
import org.apache.hadoop.io.compress.SplitCompressionInputStream;
import org.apache.hadoop.io.compress.SplittableCompressionCodec;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.CombineFileSplit;
import org.apache.hadoop.mapreduce.lib.input.CompressedSplitLineReader;
import org.apache.hadoop.mapreduce.lib.input.SplitLineReader;
import org.apache.log4j.Logger;

import com.google.common.base.Charsets;

public class CFRecordReader extends RecordReader<FileLineWritable, Text> {
	private long start;
	private long end;
	private long pos;
	private final Path path;
	private FileLineWritable key;
	private Text value;

	private final FSDataInputStream fileIn;
	private SplitLineReader in;
	private Decompressor decompressor;
	private boolean isCompressedInput = false;
	private Seekable filePosition;
	private static final Logger logger = Logger.getLogger(CFRecordReader.class);

	// private SplitLineReader in;

	public CFRecordReader(CombineFileSplit split, TaskAttemptContext context,
			Integer index) throws IOException {

		Configuration conf = context.getConfiguration();

		String delimiter = conf.get("textinputformat.record.delimiter");
		byte[] recordDelimiterBytes = null;
		if (null != delimiter) {
			recordDelimiterBytes = delimiter.getBytes(Charsets.UTF_8);
		}

		this.path = split.getPath(index);
		this.start = split.getOffset(index);
		this.end = start + split.getLength(index);

		// open the file and seek to the start of the split
		final FileSystem fs = path.getFileSystem(conf);
		fileIn = fs.open(path);
		logger.info("File opened: " + path);

		final CompressionCodec codec = new CompressionCodecFactory(conf)
				.getCodec(path);

		if (null != codec) {
			logger.info("Codec detected: " + codec.getClass());
			isCompressedInput = true;
			decompressor = CodecPool.getDecompressor(codec);
			if (codec instanceof SplittableCompressionCodec) {
				final SplitCompressionInputStream cIn = ((SplittableCompressionCodec) codec)
						.createInputStream(fileIn, decompressor, start, end,
								SplittableCompressionCodec.READ_MODE.BYBLOCK);
				in = new CompressedSplitLineReader(cIn, conf,
						recordDelimiterBytes);
				start = cIn.getAdjustedStart();
				end = cIn.getAdjustedEnd();
				filePosition = cIn;
			} else {
				in = new SplitLineReader(codec.createInputStream(fileIn), conf,
						recordDelimiterBytes);
				filePosition = fileIn;
			}
		} else {
			fileIn.seek(start);
			in = new SplitLineReader(fileIn, conf, recordDelimiterBytes);
			filePosition = fileIn;
		}

		this.pos = start;
	}

	@Override
	public void initialize(InputSplit arg0, TaskAttemptContext arg1)
			throws IOException, InterruptedException {
		// Won't be called, use custom Constructor
		// `CFRecordReader(CombineFileSplit split, TaskAttemptContext context,
		// Integer index)`
		// instead
	}

	@Override
	public void close() throws IOException {
		logger.info("Closing");
		try {
			if (in != null) {
				in.close();
			}
		} finally {
			if (decompressor != null) {
				CodecPool.returnDecompressor(decompressor);
			}
		}
	}

	@Override
	public float getProgress() throws IOException {
		if (start == end) {
			return 0;
		}
		return Math.min(1.0f, (getFilePosition() - start)
				/ (float) (end - start));
	}

	@Override
	public FileLineWritable getCurrentKey() throws IOException,
			InterruptedException {
		return key;
	}

	@Override
	public Text getCurrentValue() throws IOException, InterruptedException {
		return value;
	}

	@Override
	public boolean nextKeyValue() throws IOException {
		if (key == null) {
			key = new FileLineWritable();
			key.setFileName(path.toString());
		}
		key.setOffset(pos);
		if (value == null) {
			value = new Text();
		}
		int newSize = 0;
		if (getFilePosition() <= end || in.needAdditionalRecordAfterSplit()) {
			newSize = in.readLine(value);
			pos += newSize;
		}
		if (newSize == 0) {
			key = null;
			value = null;
			return false;
		} else {
			return true;
		}
	}

	private long getFilePosition() throws IOException {
		long retVal;
		if (isCompressedInput && null != filePosition) {
			retVal = filePosition.getPos();
		} else {
			retVal = pos;
		}
		return retVal;
	}
}
