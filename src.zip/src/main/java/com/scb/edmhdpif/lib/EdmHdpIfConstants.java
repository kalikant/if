package com.scb.edmhdpif.lib;

import org.apache.hadoop.io.Text;

public class EdmHdpIfConstants {

	// Constants
	public static final String COL_SEPARATOR = Character.toString((char) 2);
	public static final String DATA_SEPARATOR = Character.toString((char) 1);
	public static final String PROP_LINE_SEPARATOR = "\\^";
	public static final Text B_VALUES_TEXT = new Text("#BValues#");
	public static final String PREFIX_CONFIG_EDMHDPIF_TABLE = "edmhdpif.table.";
	public static final String SUFFIX_EOD_VERIFYTYPES_FILES = "-aftereod";
	public static final String SUFFIX_CONFIG_COLSCHEMA = ".col_schema";
	public static final String SUFFIX_CONFIG_DELETEVALUE = ".deletevalue";
	public static final String SUFFIX_CONFIG_DELETEFIELD = ".deletefield";
	public static final String SUFFIX_CONFIG_DELETEINDEX = ".deleteindex";
	public static final String SUFFIX_SRI_FULLDUMP = ".fulldump";

	// Initernal use
	public static final String VERIFYTYPES_OUTPUT_VALID = "edmhdpif.typevalidator.output.valid";
	public static final String VERIFYTYPES_OUTPUT_INVALID = "edmhdpif.typevalidator.output.invalid";
	public static final String VERIFYTYPES_OUTPUT_WARN = "edmhdpif.typevalidator.output.warn";
	public static final String DATATRANSFORM_OUTPUT_VALID = "edmhdpif.datatransform.output.valid";
	public static final String DATATRANSFORM_OUTPUT_INVALID = "edmhdpif.datatransform.output.invalid";
	public static final String EDMHDPIF_CDCCOLUMNS_BOOLEAN = "edmhdpif.cdccolumns.boolean";

	// External configuration parameters
	public static final String EDMHDPIF_COLSEPARATOR = "edmhdpif.delimiter.framework";
	public static final String EDMHDPIF_DATASEPARATOR = "edmhdpif.delimiter.data";
	public static final String EDMHDPIF_OUTPUT_PATH = "edmhdpif.output.path";
	public static final String EDMHDPIF_CDCCOLUMNS = "edmhdpif.cdccolumns";

	public static final String EDMHDPIF_ROWID_OUTPUT = "edmhdpif.rowid.output";
	public static final String EDMHDPIF_ROWHISTORY_OUTPUT = "edmhdpif.rowhistory.output";

	public static final String EDMHDPIF_HIVE_WAREHOUSE = "edmhdpif.hive.warehouse";

	public static final String EDMHDPIF_RERUN_TABLE = "edmhdpif.rerun.table";

	public static final String EDMHDPIF_INPUT_DATABASE = "edmhdpif.input.database";
	public static final String EDMHDPIF_INPUT_TABLE = "edmhdpif.input.table";
	public static final String EDMHDPIF_INPUT_PARTITION = "edmhdpif.input.partition";
	public static final String EDMHDPIF_INPUT_PARTITION_PREVIOUS = "edmhdpif.input.partition.previous";

	public static final String EDMHDPIF_CONTAINERVALIDATOR_DATABASE = "edmhdpif.containervalidator.database";
	public static final String EDMHDPIF_CONTAINERVALIDATOR_TABLE = "edmhdpif.containervalidator.table";
	public static final String EDMHDPIF_CONTAINERVALIDATOR_PARTITION = "edmhdpif.containervalidator.partition";

	public static final String EDMHDPIF_CONTAINERVALIDATOR_ARGS = "edmhdpif.containervalidator.args";
	public static final String EDMHDPIF_CONTAINERVALIDATOR_TYPE = "edmhdpif.containervalidator.type";

	public static final String EDMHDPIF_ROWID_DATABASE = "edmhdpif.rowid.database";
	public static final String EDMHDPIF_ROWID_TABLE = "edmhdpif.rowid.table";
	public static final String EDMHDPIF_ROWID_PARTITION = "edmhdpif.rowid.partition";

	public static final String EDMHDPIF_ROWHISTORY_DATABASE = "edmhdpif.rowhistory.database";
	public static final String EDMHDPIF_ROWHISTORY_TABLE = "edmhdpif.rowhistory.table";
	public static final String EDMHDPIF_ROWHISTORY_PARTITION = "edmhdpif.rowhistory.partition";

	public static final String EDMHDPIF_EOD_MARKER = "edmhdpif.eod.marker";

	public static final String EDMHDPIF_BATCHTOPARTITION_DATABASE = "edmhdpif.batch_to_partition.database";
	public static final String EDMHDPIF_BATCHTOPARTITION_TABLE = "edmhdpif.batch_to_partition.table";

	public static final String EDMHDPIF_INDIVIDUAL_TABLEPREFIX = "edmhdpif.individual.tableprefix";

	public static final String EDMHDPIF_DATATRANSFORM_VALID_DATABASE = "edmhdpif.datatransform.valid.database";
	public static final String EDMHDPIF_DATATRANSFORM_VALID_TABLE = "edmhdpif.datatransform.valid.table";
	public static final String EDMHDPIF_DATATRANSFORM_VALID_PARTITION = "edmhdpif.datatransform.valid.partition";

	public static final String EDMHDPIF_DATATRANSFORM_INVALID_DATABASE = "edmhdpif.datatransform.invalid.database";
	public static final String EDMHDPIF_DATATRANSFORM_INVALID_TABLE = "edmhdpif.datatransform.invalid.table";
	public static final String EDMHDPIF_DATATRANSFORM_INVALID_PARTITION = "edmhdpif.datatransform.invalid.partition";

	public static final String EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_DATABASE = "edmhdpif.typevalidator.validtypes.database";
	public static final String EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_TABLE = "edmhdpif.typevalidator.validtypes.table";
	public static final String EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_PARTITION = "edmhdpif.typevalidator.validtypes.partition";

	public static final String EDMHDPIF_TYPEVALIDATOR_ONETABLE = "edmhdpif.typevalidator.onetable";
	public static final String EDMHDPIF_TYPEVALIDATOR_ARGS = "edmhdpif.typevalidator.args";

	public static final String EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_DATABASE = "edmhdpif.typevalidator.invalidtypes.database";
	public static final String EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_TABLE = "edmhdpif.typevalidator.invalidtypes.table";
	public static final String EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_PARTITION = "edmhdpif.typevalidator.invalidtypes.partition";

	public static final String EDMHDPIF_TYPEVALIDATOR_WARNTYPES_DATABASE = "edmhdpif.typevalidator.warntypes.database";
	public static final String EDMHDPIF_TYPEVALIDATOR_WARNTYPES_TABLE = "edmhdpif.typevalidator.warntypes.table";
	public static final String EDMHDPIF_TYPEVALIDATOR_WARNTYPES_PARTITION = "edmhdpif.typevalidator.warntypes.partition";

	public static final String EDMHDPIF_OPEN_DATABASE = "edmhdpif.open.database";
	public static final String EDMHDPIF_OPEN_PARTITION = "edmhdpif.open.partition";
	public static final String EDMHDPIF_OPEN_PARTITION_PREVIOUS = "edmhdpif.open.partition.previous";

	public static final String EDMHDPIF_NONOPEN_DATABASE = "edmhdpif.nonopen.database";
	public static final String EDMHDPIF_NONOPEN_PARTITION = "edmhdpif.nonopen.partition";

	public static final String EDMHDPIF_POSTPROCESSING_DATABASE = "edmhdpif.postprocessing.database";
	public static final String EDMHDPIF_POSTPROCESSING_PARTITION = "edmhdpif.postprocessing.partition";

	public static final String EDMHDPIF_DUPLICATEDROWS_DATABASE = "edmhdpif.duplicatedrows.database";
	public static final String EDMHDPIF_DUPLICATEDROWS_TABLE = "edmhdpif.duplicatedrows.table";
	public static final String EDMHDPIF_DUPLICATEDROWS_PARTITION = "edmhdpif.duplicatedrows.partition";

	public static final String EDMHDPIF_NWD_DATABASE = "edmhdpif.eod.database";
	public static final String EDMHDPIF_NWD_TABLE = "edmhdpif.eod.table";
	public static final String EDMHDPIF_NWD_PARTITION = "edmhdpif.eod.partition";

	public static final String EDMHDPIF_SRI_NEXTWORKINGDATE = "edmhdpif.sri.nextworkingdate";

	public static final String EDMHDPIF_ROWCOUNTS_DATABASE = "edmhdpif.rowcounts.database";
	public static final String EDMHDPIF_ROWCOUNTS_TABLE = "edmhdpif.rowcounts.table";
	public static final String EDMHDPIF_ROWCOUNTS_PARTITION = "edmhdpif.rowcounts.partition";

	public static final String EDMHDPIF_FIXWIDTH = "edmhdpif.fixwidth";
}
