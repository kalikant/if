package com.scb.edmhdpif.containervalidation;

import java.io.IOException;
import java.util.Calendar;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.HatColumn;
import com.scb.edmhdpif.lib.input.FileLineWritable;

public class HeaderAndTrailerMapper extends Mapper<FileLineWritable, Text, Text, Text> {

	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
	private String DATA_SEPARATOR = EdmHdpIfConstants.DATA_SEPARATOR;
	private Boolean FIXWIDTH = false;
	private Configuration conf = null;
	private Text one = new Text("1");

	private static final Logger logger = Logger.getLogger(HeaderAndTrailerMapper.class);

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info("Setup initiated");
		conf = context.getConfiguration();
		COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
				COL_SEPARATOR));
		DATA_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR,
				DATA_SEPARATOR));
		FIXWIDTH = Boolean.valueOf(conf.get(EdmHdpIfConstants.EDMHDPIF_FIXWIDTH));

		logger.info("Setup finished");
	}

	@Override
	protected void map(FileLineWritable key, Text value, Context context) throws IOException, InterruptedException {
		// Get table name
		String tableName = getTableName(key);
		// See if it's a Header, Data or Trailer row
		int type = value.charAt(0);
		switch (type) {
		case 'H':
			String headerType = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + ".header");
			String headerColumnsStr = conf.get("edmhdpif.header." + headerType);
			if (headerColumnsStr == null) {
				context.write(new Text(key.getFileName()), new Text("Header type " + headerType
						+ " not found for table " + tableName));
				return;
			}
			validateHeaderOrTrailer(context, key, value, headerColumnsStr);
			break;
		case 'D':
			context.write(new Text(key.getFileName()), one);
			break;
		case 'T':
			String trailerType = conf.get(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + tableName + ".trailer");
			String trailerColumnsStr = conf.get("edmhdpif.trailer." + trailerType);
			if (trailerColumnsStr == null) {
				context.write(new Text(key.getFileName()), new Text("Trailer type " + trailerType
						+ " not found for table " + tableName));
				return;
			}
			validateHeaderOrTrailer(context, key, value, trailerColumnsStr);
			break;
		}
	}

	private void validateHeaderOrTrailer(Context context, FileLineWritable key, Text value, String columnsStr)
			throws IOException, InterruptedException {
		// Get header configuration
		String[] headerColumns = columnsStr.split("\\^");
		String[] valueColumns = null;
		int colStart = 0;
		if (!FIXWIDTH) {
			valueColumns = value.toString().split("\\" + DATA_SEPARATOR, -1);
		}
		for (String column : headerColumns) {
			HatColumn col = new HatColumn(column);
			if (col.isValidateDate()) {
				// Validate the date
				String mask = col.getMask();
				String dateValue;
				if (FIXWIDTH) {
					dateValue = value.toString().substring(colStart, colStart + col.getWidth());
				} else {
					dateValue = valueColumns[colStart];
				}
				if (!isValidDate(dateValue, mask)) {
					context.write(new Text(key.getFileName()), new Text("Date validation error: " + dateValue
							+ " is not a valid date masked by " + mask));
					continue;
				}
			}
			if (col.isValidateRowCount()) {
				// Get value
				int rowcountValue;
				if (FIXWIDTH) {
					rowcountValue = Integer.valueOf(value.toString().substring(colStart, colStart + col.getWidth()));
				} else {
					rowcountValue = Integer.valueOf(valueColumns[colStart]);
				}
				// The sum for every table name must be 0
				context.write(new Text(key.getFileName()), new Text("-" + rowcountValue));
			}
			// Update position
			if (FIXWIDTH) {
				colStart += col.getWidth();
			} else {
				// Column count
				colStart++;
			}
		}
	}

	private boolean isValidDate(String dateValue, String mask) {
		if (dateValue == null || mask == null || dateValue.length() != mask.length()) {
			return false;
		}
		Calendar date = Calendar.getInstance();
		try {
			if ("CYYMMDD".equals(mask)) {
				if (!(dateValue.startsWith("0") || dateValue.startsWith("1"))) {
					return false;
				}
				int year = 1900;
				// Integer to date
				if (dateValue.startsWith("1")) {
					year = 2000;
				}
				year = year + Integer.valueOf(dateValue.substring(1, 3));
				if (year > date.getActualMaximum(Calendar.YEAR) || year < date.getActualMinimum(Calendar.YEAR)) {
					return false;
				}
				date.set(Calendar.YEAR, year);
				int month = Integer.valueOf(dateValue.substring(3, 5)) - 1;
				if (month > date.getActualMaximum(Calendar.MONTH) || month < date.getActualMinimum(Calendar.MONTH)) {
					return false;
				}
				date.set(Calendar.MONTH, month);
				int day = Integer.valueOf(dateValue.substring(5, 7));
				if (day > date.getActualMaximum(Calendar.DAY_OF_MONTH)
						|| day < date.getActualMinimum(Calendar.DAY_OF_MONTH)) {
					return false;
				}
			}
			if ("YYYYMMDD".equals(mask)) {
				int year = Integer.valueOf(dateValue.substring(0, 4));
				if (year > date.getActualMaximum(Calendar.YEAR) || year < date.getActualMinimum(Calendar.YEAR)) {
					return false;
				}
				date.set(Calendar.YEAR, year);
				int month = Integer.valueOf(dateValue.substring(4, 6)) - 1;
				if (month > date.getActualMaximum(Calendar.MONTH) || month < date.getActualMinimum(Calendar.MONTH)) {
					return false;
				}
				date.set(Calendar.MONTH, month);
				int day = Integer.valueOf(dateValue.substring(6, 8));
				if (day > date.getActualMaximum(Calendar.DAY_OF_MONTH)
						|| day < date.getActualMinimum(Calendar.DAY_OF_MONTH)) {
					return false;
				}
			}
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	private String getTableName(FileLineWritable key) {
		Path file = new Path(key.getFileName());
		return file.getName().split("\\.")[0];
	}
}