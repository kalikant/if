package com.scb.edmhdpif.containervalidation;

import java.io.IOException;
import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.log4j.Logger;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;

public class HeaderAndTrailerReducer extends Reducer<Text, Text, NullWritable, Text> {

	private String COL_SEPARATOR = EdmHdpIfConstants.COL_SEPARATOR;
	private String DATA_SEPARATOR = EdmHdpIfConstants.DATA_SEPARATOR;
	private Configuration conf = null;

	private static final Logger logger = Logger.getLogger(HeaderAndTrailerReducer.class);
	private final String tcStartTime = EdmHdpIfCommon.getUnixTime();
	private String BUSINESSDAY = "";

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		logger.info(this.getClass() + " setup initiated");
		conf = context.getConfiguration();
		COL_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR,
				COL_SEPARATOR));
		DATA_SEPARATOR = EdmHdpIfCommon.unicodeReplacement(conf.get(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR,
				DATA_SEPARATOR));
		BUSINESSDAY = conf.get(EdmHdpIfConstants.EDMHDPIF_SRI_NEXTWORKINGDATE, BUSINESSDAY);

		logger.info(this.getClass() + " setup finished");

	}

	@Override
	protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

		logger.info("Writing values in " + key.toString());
		// Get the file source path
		Path srcPath = new Path(URI.create(key.toString()));

		int rowcount = 0;
		int expectedRowCount = 0;
		StringBuilder error = new StringBuilder();
		for (Text t : values) {
			try {
				Integer value = Integer.valueOf(t.toString());
				if (value < 0) {
					// There is a negative value - perform rowcount validation
					expectedRowCount = -value;
				}
				rowcount += value;
			} catch (NumberFormatException e) {
				if (error.length() > 0) {
					error.append(DATA_SEPARATOR);
				}
				error.append(t.toString());
			}
		}

		// Rowcount does not match
		if (expectedRowCount != 0 && rowcount != 0) {
			if (error.length() > 0) {
				error.append(DATA_SEPARATOR);
			}
			error.append("Number of rows does not match the expected number of rows " + expectedRowCount);
		}

		boolean valid = true;
		if (error.length() > 0) {
			valid = false;
		}
		context.write(NullWritable.get(),
				new Text(new StringBuilder(srcPath.toString()).append(COL_SEPARATOR).append(valid)
						.append(COL_SEPARATOR).append(error.toString()).append(COL_SEPARATOR).append(BUSINESSDAY)
						.append(COL_SEPARATOR).append(tcStartTime).append(COL_SEPARATOR).append(context.getJobName())
						.append(COL_SEPARATOR).append(context.getTaskAttemptID()).toString()));

	}
}