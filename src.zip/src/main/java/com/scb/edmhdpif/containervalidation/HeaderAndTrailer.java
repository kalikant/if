package com.scb.edmhdpif.containervalidation;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.scb.edmhdpif.lib.EdmHdpIfCommon;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.PathFinder;
import com.scb.edmhdpif.lib.input.CFInputFormat;

public class HeaderAndTrailer extends Configured implements Tool {

	private static final Logger logger = Logger.getLogger(HeaderAndTrailer.class);

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new HeaderAndTrailer(), args);
		System.exit(res);
	}

	@Override
	public int run(String[] args) throws IllegalStateException, ClassNotFoundException, InstantiationException,
			IllegalAccessException, IOException {

		Configuration conf = super.getConf();

		String oozieConfigurationLocation = System.getProperty("oozie.action.conf.xml");
		if (oozieConfigurationLocation != null) {
			logger.info("Loading Oozie configuration from " + oozieConfigurationLocation);
			conf.addResource(new Path(oozieConfigurationLocation));
		}

		EdmHdpIfCommon.checkRequiredParameters(conf,
				new String[] { EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH,
						EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE,
						EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_ARGS,
						EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_DATABASE,
						EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_TABLE,
						EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_PARTITION });

		// Read JSON arguments
		try {
			JSONObject argumentsObject = new JSONObject(conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_ARGS));
			Iterator<?> keys = argumentsObject.keys();
			while (keys.hasNext()) {
				String key = (String) keys.next();
				System.out.println("Argument key: " + key + " value:" + argumentsObject.getString(key));
				conf.set(key, argumentsObject.getString(key));
			}
		} catch (JSONException e) {
			logger.error("Can't read arguments: " + e.getMessage());
			e.printStackTrace();
		}

		Job job;
		try {
			job = Job.getInstance(conf, "EdmHdpIf-H&T Validator");
		} catch (IOException e) {
			e.printStackTrace();
			return 1;
		}

		job.setJarByClass(HeaderAndTrailer.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(HeaderAndTrailerMapper.class);
		job.setReducerClass(HeaderAndTrailerReducer.class);

		job.setInputFormatClass(CFInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		String hiveWarehouse = conf.get(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/");
		String inputDatabase = conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "");
		String inputTable = conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "");
		String inputPartition = EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, ""));
		Path inputPath = new Path(hiveWarehouse + "/" + inputDatabase + "/" + inputTable + "/" + inputPartition);

		String outputPathStr = hiveWarehouse + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_DATABASE, "") + "/"
				+ conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_TABLE, "") + "/"
				+ EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_CONTAINERVALIDATOR_PARTITION, ""))
				+ "/";
		Path outputPath = new Path(outputPathStr);
		logger.info("Output path set to " + outputPathStr);

		try {
			// Delete output path
			EdmHdpIfCommon.deletePath(FileSystem.get(conf), outputPathStr);
			FileOutputFormat.setOutputPath(job, outputPath);

			// If it's a rerun, only load the tables to rerun
			final String rerunTables = conf.get(EdmHdpIfConstants.EDMHDPIF_RERUN_TABLE);
			if (rerunTables == null) {
				logger.info("Adding input path: " + inputPath);
				MultipleInputs.addInputPath(job, inputPath, CFInputFormat.class);
			} else {
				logger.info("RERUN of table(s) " + rerunTables);
				String[] names = rerunTables.split(",");
				for (String n : names) {
					PathFinder inputPathFinder = new PathFinder(conf,
							hiveWarehouse + "/" + conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, ""));
					inputPathFinder.setTableName(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, ""));
					inputPathFinder.setPartition(
							EdmHdpIfCommon.getPartition(conf.get(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "")));
					inputPathFinder.setFileName(n + ".");

					for (Path file : inputPathFinder.getFiles()) {
						logger.info("Adding input file: " + file);
						MultipleInputs.addInputPath(job, file, CFInputFormat.class);
					}
				}

				// If no input paths set (e.g. rerun for a table that has no
				// file), then set
				// input path to empty directory so that job succeeds
				if (job.getConfiguration().get(MultipleInputs.DIR_FORMATS) == null) {
					EdmHdpIfCommon.setEmptyInputPath(job, FileSystem.get(conf), outputPath);
				}
			}
			return (job.waitForCompletion(true) ? 0 : 1);
		} catch (ClassNotFoundException | IOException | InterruptedException e) {
			e.printStackTrace();
			return 1;
		}
	}
}
