package com.scb.edmhdpif.datatransform;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;

@PrepareForTest({ DataTransformReducer.class })
@RunWith(PowerMockRunner.class)
public class DataTransformReducerTest {
	ReduceDriver<Text, Text, NullWritable, Text> reduceDriver;
	DataTransformReducer reducer;

	@Before
	public void setUp() throws IOException {
		reducer = new DataTransformReducer();
		reduceDriver = ReduceDriver.newReduceDriver(reducer);
	}

	@Test
	public void testReducerOK() throws IOException {
		setConfigParameters(reduceDriver.getConfiguration());

		Text data = new Text("D;655209;1;796764372490213;804422938115889;6");

		List<Text> dataList = new ArrayList<>();
		dataList.add(data);
		dataList.add(data);

		reduceDriver.withInput(new Text("/data/database/tableName/partition/tableName"), dataList);

		reduceDriver.withMultiOutput("output", NullWritable.get(), data);
		reduceDriver.withMultiOutput("output", NullWritable.get(), data);
		reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
				new Text("database,tableName,2,tableName," + getTcStartTime() + ",null,attempt__0000_r_000000_0"));

		reduceDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {

		conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH, "/tmp/oozie/rowid02");
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
		conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");
	}

	private String getTcStartTime() {
		try {
			Class<? extends DataTransformReducer> cls = reducer.getClass();
			Field field = cls.getDeclaredField("tcStartTime");
			field.setAccessible(true);
			return (String) field.get(reducer);
		} catch (Exception e) {
			return "";
		}
	}
}
