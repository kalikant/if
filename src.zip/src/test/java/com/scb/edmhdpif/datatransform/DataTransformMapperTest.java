package com.scb.edmhdpif.datatransform;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;

public class DataTransformMapperTest {
    MapDriver<WritableComparable<?>, Text, Text, Text> mapDriver;

    @Before
    public void setUp() throws IOException {
        DataTransformMapper mapper = new DataTransformMapper();
        mapDriver = MapDriver.newMapDriver(mapper);
        setConfigParameters(mapDriver.getConfiguration());
    }

    @Test
    public void testMapperWithSeparator() throws IOException {

        String header = "tableName,rowid,H;12345678;1150718;";
        String data = "tableName,rowid,D;20150923;1;796764372490213;804422938115889;6";
        String trailer = "tableName,rowid,T;000000004;";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(data));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(data));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperWithSeparatorEmptyCols() throws IOException {

        String header = "tableName,rowid,H;12345678;1150718;";
        String data = "tableName,rowid,D;20150923;1;;804422938115889;";
        String trailer = "tableName,rowid,T;000000004;";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(data));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(data));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperHeaderNoTrailer() throws IOException {

        String header = "tableName,rowid,H;12345678;1150718;";
        String data = "tableName,rowid,D;20150923;1;796764372490213;804422938115889;6";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(data));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(data));
        mapDriver.runTest();
    }

    @Test
    public void testMapperNoSeparator() throws IOException {

        mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_FIXWIDTH, "true");

        String header = "tableName,rowid,H123456781150718";
        String data = "tableName,rowid,D65520917967643724902138044229381158896";
        String trailer = "tableName,rowid,T000000004";
        String outputdata = "tableName,rowid,D;655209;1;796764372490213;804422938115889;6";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperNoSeparatorInvalid() throws IOException {

        mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_FIXWIDTH, "true");

        String header = "tableName,rowid,H123456781150718";
        String data = "tableName,rowid,D655209179676437249021380442293811586";
        String trailer = "tableName,rowid,T000000004";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(data + ",Line lenght 37 differs from expected length 39"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(data + ",Line lenght 37 differs from expected length 39"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDrop1() throws IOException {

        mapDriver
                .getConfiguration()
                .set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                        "RECORDTYPE CHAR(1) NOT NULL WIDTH 1^COL2 CHAR(6) NOT NULL DROP WIDTH 6^COL3 CHAR(1) NOT NULL WIDTH 1^COL4 CHAR(15) WIDTH 15^COL5 CHAR(15) WIDTH 15^COL6 CHAR(1) WIDTH 1");

        String header = "tableName,rowid,H;12345678;1150718;";
        String data = "tableName,rowid,D;655209;1;796764372490213;804422938115889;6";
        String outputdata = "tableName,rowid,D;1;796764372490213;804422938115889;6";
        String trailer = "tableName,rowid,T;000000004;";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDrop2() throws IOException {

        mapDriver
                .getConfiguration()
                .set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                        "RECORDTYPE CHAR(1) NOT NULL WIDTH 1^COL2 CHAR(6) NOT NULL DROP WIDTH 6^COL3 CHAR(1) NOT NULL WIDTH 1^COL4 CHAR(15) WIDTH 15^COL5 CHAR(15) WIDTH 15 DROP^COL6 CHAR(1) WIDTH 1");

        String header = "tableName,rowid,H;12345678;1150718;";
        String data = "tableName,rowid,D;655209;1;796764372490213;804422938115889;6";
        String outputdata = "tableName,rowid,D;1;796764372490213;6";
        String trailer = "tableName,rowid,T;000000004;";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperRule1() throws IOException {

        mapDriver
                .getConfiguration()
                .set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                        "RECORDTYPE CHAR(1) NOT NULL WIDTH 1^COL2 CHAR(8) NOT NULL RULES DateYYYYMMDD WIDTH 6^COL3 CHAR(1) NOT NULL WIDTH 1^COL4 CHAR(15) WIDTH 15^COL5 CHAR(15) WIDTH 15^COL6 CHAR(1) WIDTH 1");

        String header = "tableName,rowid,H;12345678;1150718;";
        String data = "tableName,rowid,D;20150923;1;796764372490213;804422938115889;6";
        String outputdata = "tableName,rowid,D;2015-09-23;1;796764372490213;804422938115889;6";
        String trailer = "tableName,rowid,T;000000004;";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperRule2() throws IOException {

        mapDriver
                .getConfiguration()
                .set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                        "RECORDTYPE CHAR(1) NOT NULL WIDTH 1^COL2 CHAR(8) NOT NULL RULES NullDate,DateYYYYMMDD WIDTH 6^COL3 CHAR(1) NOT NULL WIDTH 1^COL4 CHAR(15) WIDTH 15^COL5 CHAR(15) WIDTH 15^COL6 CHAR(1) WIDTH 1");

        String header = "tableName,rowid,H;12345678;1150718;";
        String data = "tableName,rowid,D;20150923;1;796764372490213;804422938115889;6";
        String data2 = "tableName,rowid,D;00000000;1;796764372490213;804422938115889;6";
        String outputdata = "tableName,rowid,D;2015-09-23;1;796764372490213;804422938115889;6";
        String outputdata2 = "tableName,rowid,D;null;1;796764372490213;804422938115889;6";
        String trailer = "tableName,rowid,T;000000004;";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data2));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata2));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperRuleWithParam() throws IOException {

        mapDriver
                .getConfiguration()
                .set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                        "RECORDTYPE CHAR(1) NOT NULL WIDTH 1^COL2 CHAR(8) NOT NULL RULES DIVIDE(100) WIDTH 6^COL3 CHAR(1) NOT NULL WIDTH 1^COL4 CHAR(15) WIDTH 15^COL5 CHAR(15) WIDTH 15^COL6 CHAR(1) WIDTH 1");

        String header = "tableName,rowid,H;12345678;1150718;";
        String data = "tableName,rowid,D;20150923;1;796764372490213;804422938115889;6";
        String outputdata = "tableName,rowid,D;201509.23;1;796764372490213;804422938115889;6";
        String trailer = "tableName,rowid,T;000000004;";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperRule2WithParam() throws IOException {

        mapDriver
                .getConfiguration()
                .set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                        "RECORDTYPE CHAR(1) NOT NULL WIDTH 1^COL2 CHAR(8) NOT NULL RULES NullDate,DIVIDE(100) WIDTH 6^COL3 CHAR(1) NOT NULL WIDTH 1^COL4 CHAR(15) WIDTH 15^COL5 CHAR(15) WIDTH 15^COL6 CHAR(1) WIDTH 1");

        String header = "tableName,rowid,H;12345678;1150718;";
        String data = "tableName,rowid,D;20150923;1;796764372490213;804422938115889;6";
        String data2 = "tableName,rowid,D;00000000;1;796764372490213;804422938115889;6";
        String outputdata = "tableName,rowid,D;201509.23;1;796764372490213;804422938115889;6";
        String outputdata2 = "tableName,rowid,D;null;1;796764372490213;804422938115889;6";
        String trailer = "tableName,rowid,T;000000004;";
        mapDriver.withInput(NullWritable.get(), new Text(header));
        mapDriver.withInput(NullWritable.get(), new Text(data));
        mapDriver.withInput(NullWritable.get(), new Text(data2));
        mapDriver.withInput(NullWritable.get(), new Text(trailer));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(header + ",Record type is not 'Data'"));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID)
                + "tableName"), new Text(outputdata2));
        mapDriver.withOutput(new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID)
                + "tableName"), new Text(trailer + ",Record type is not 'Data'"));
        mapDriver.runTest();
    }

    private void setConfigParameters(Configuration conf) {
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.header", "HeaderType1");
        conf.set("edmhdpif.header.HeaderType1",
                "Record_type char(1)^FileId Char(8)^Efective_date Num(7) MASK CYYMMDD VALIDATEDATE^Filler Varchar");

        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.trailer", "TrailerType1");
        conf.set("edmhdpif.trailer.TrailerType1",
                "Record_type char(1)^Record_count Num(9) VALIDATEROWCOUNT^Filler Varchar");

        conf.set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                "RECORDTYPE CHAR(1) NOT NULL WIDTH 1^COL2 CHAR(6) NOT NULL WIDTH 6^COL3 CHAR(1) NOT NULL WIDTH 1^COL4 CHAR(15) WIDTH 15^COL5 CHAR(15) WIDTH 15^COL6 CHAR(1) WIDTH 1");

        conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
        conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
        conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
        conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
        conf.set(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH, "/tmp/oozie/rowid02");
        conf.set(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID, "/data/database/transform-valid/partition/");
        conf.set(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID, "/data/database/transform-invalid/partition/");
        conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
        conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");

        conf.set("edmhdpif.rules.DIVIDE.params", "N");
        conf.set("edmhdpif.rules.DIVIDE.code", "result=DATA.toInteger()/N.toInteger()");
        conf.set("edmhdpif.rules.DateYYYYMMDD.code",
                "result=DATA.substring(0,4)+\"-\"+DATA.substring(4,6)+\"-\"+DATA.substring(6,8)");
        conf.set("edmhdpif.rules.NullDate.code", "if (\"00000000\".equals(DATA)) result=null; else result=DATA;");
    }
}
