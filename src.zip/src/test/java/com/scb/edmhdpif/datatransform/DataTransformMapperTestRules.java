package com.scb.edmhdpif.datatransform;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;

public class DataTransformMapperTestRules {
	MapDriver<WritableComparable<?>, Text, Text, Text> mapDriver;

	@Before
	public void setUp() throws IOException {
		DataTransformMapper mapper = new DataTransformMapper();
		mapDriver = MapDriver.newMapDriver(mapper);
		setConfigParameters(mapDriver.getConfiguration());
	}

	@Test
	public void testMapperRuleDivide() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL WIDTH 1^COL2 CHAR(8) NOT NULL RULES DIVIDE(100) WIDTH 6^COL3 CHAR(1) NOT NULL WIDTH 1^COL4 CHAR(15) WIDTH 15^COL5 CHAR(15) WIDTH 15^COL6 CHAR(1) WIDTH 1");

		String data = "tableName,rowid,D;20150923;1;796764372490213;804422938115889;6";
		String outputdata = "tableName,rowid,D;201509.23;1;796764372490213;804422938115889;6";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleDateYYYYMMDD() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES DateYYYYMMDD");

		String data = "tableName,rowid,D;20150923";
		String outputdata = "tableName,rowid,D;2015-09-23";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleDateCYYMMDD() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES DateCYYMMDD");

		String data = "tableName,rowid,D;1150923";
		String outputdata = "tableName,rowid,D;2015-09-23";
		String data2 = "tableName,rowid,D;0150923";
		String outputdata2 = "tableName,rowid,D;1915-09-23";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withInput(NullWritable.get(), new Text(data2));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata2));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleDateCEMSMMYY() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES DateCEMSMMYY");

		String data = "tableName,rowid,D;08/15";
		String outputdata = "tableName,rowid,D;0815";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleDateYYYMMDD() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES DateYYYMMDD");

		String data = "tableName,rowid,D;1040923";
		String outputdata = "tableName,rowid,D;2015-09-23";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleDateYYMMDD() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES DateYYMMDD");

		String data = "tableName,rowid,D;990923";
		String outputdata = "tableName,rowid,D;2010-09-23";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleDateYYYMM() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES DateYYYMM");

		String data = "tableName,rowid,D;10409";
		String outputdata = "tableName,rowid,D;201509";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleTimeHHMMSS() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES TimeHHMMSS");

		String data = "tableName,rowid,D;010203";
		String outputdata = "tableName,rowid,D;01:02:03";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleTimeHHMM() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES TimeHHMM");

		String data = "tableName,rowid,D;0102";
		String outputdata = "tableName,rowid,D;01:02";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleTime0HHMMSS() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES Time0HHMMSS");

		String data = "tableName,rowid,D;0010203";
		String outputdata = "tableName,rowid,D;01:02:03";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	@Test
	public void testMapperRuleNull() throws IOException {

		mapDriver.getConfiguration()
				.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL^COL2 CHAR(8) NOT NULL RULES Null('00000000','1900-01-01')");

		String data = "tableName,rowid,D;00000000";
		String outputdata = "tableName,rowid,D;1900-01-01";
		mapDriver.withInput(NullWritable.get(), new Text(data));
		mapDriver.withOutput(
				new Text(mapDriver.getConfiguration().get(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID) + "tableName"),
				new Text(outputdata));
		mapDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {
		conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.header", "HeaderType1");
		conf.set("edmhdpif.header.HeaderType1",
				"Record_type char(1)^FileId Char(8)^Efective_date Num(7) MASK CYYMMDD VALIDATEDATE^Filler Varchar");

		conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.trailer", "TrailerType1");
		conf.set("edmhdpif.trailer.TrailerType1",
				"Record_type char(1)^Record_count Num(9) VALIDATEROWCOUNT^Filler Varchar");

		conf.set(
				EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"RECORDTYPE CHAR(1) NOT NULL WIDTH 1^COL2 CHAR(6) NOT NULL WIDTH 6^COL3 CHAR(1) NOT NULL WIDTH 1^COL4 CHAR(15) WIDTH 15^COL5 CHAR(15) WIDTH 15^COL6 CHAR(1) WIDTH 1");

		conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH, "/tmp/oozie/rowid02");
		conf.set(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_VALID, "/data/database/transform-valid/partition/");
		conf.set(EdmHdpIfConstants.DATATRANSFORM_OUTPUT_INVALID, "/data/database/transform-invalid/partition/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
		conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");

		conf.set("edmhdpif.rules.DIVIDE.params", "N");
		conf.set("edmhdpif.rules.DIVIDE.code", "result=DATA.toInteger()/N.toInteger()");
		conf.set("edmhdpif.rules.DateYYYYMMDD.code",
				"result=DATA.substring(0,4)+\"-\"+DATA.substring(4,6)+\"-\"+DATA.substring(6,8)");
		conf.set("edmhdpif.rules.DateCYYMMDD.code",
				"if (DATA.startsWith(\"0\")) DATA=\"19\"+DATA.substring(1)"
						+ " else if (DATA.startsWith(\"1\")) DATA=\"20\"+DATA.substring(1);"
						+ "result=DATA.substring(0,4)+\"-\"+DATA.substring(4,6)+\"-\"+DATA.substring(6,8);");
		conf.set("edmhdpif.rules.DateCEMSMMYY.code", "result=DATA.replace(\"/\",\"\")");
		conf.set("edmhdpif.rules.DateYYYMMDD.code", "DATA=(DATA.toInteger()+19110000).toString();"
				+ "result=DATA.substring(0,4)+\"-\"+DATA.substring(4,6)+\"-\"+DATA.substring(6,8)");
		conf.set("edmhdpif.rules.DateYYMMDD.code", "DATA=(DATA.toInteger()+19110000).toString();"
				+ "result=DATA.substring(0,4)+\"-\"+DATA.substring(4,6)+\"-\"+DATA.substring(6,8)");
		conf.set("edmhdpif.rules.DateYYYMM.code", "result=(DATA.toInteger()+191100).toString()");
		conf.set("edmhdpif.rules.TimeHHMMSS.code",
				"result=DATA.substring(0,2)+\":\"+DATA.substring(2,4)+\":\"+DATA.substring(4,6)");
		conf.set("edmhdpif.rules.TimeHHMM.code", "result=DATA.substring(0,2)+\":\"+DATA.substring(2,4)");
		conf.set("edmhdpif.rules.Time0HHMMSS.code",
				"result=DATA.substring(1,3)+\":\"+DATA.substring(3,5)+\":\"+DATA.substring(5,7)");
		conf.set("edmhdpif.rules.Null.params", "NullString,NullValue");
		conf.set("edmhdpif.rules.Null.code", "if (DATA==NullString) result=NullValue; else result=DATA;");
		conf.set("edmhdpif.rules.Trim.code", "result=DATA.trim()");
	}
}
