package com.scb.edmhdpif.rowid;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;

@PrepareForTest({ RowIdReducer.class })
@RunWith(PowerMockRunner.class)
public class RowIdReducerTest {
	ReduceDriver<Text, Text, NullWritable, Text> reduceDriver;
	RowIdReducer reducer;

	@Before
	public void setUp() throws IOException {
		reducer = new RowIdReducer();
		reduceDriver = ReduceDriver.newReduceDriver(reducer);
	}

	@Test
	public void testReducerOK() throws IOException {
		setConfigParameters(reduceDriver.getConfiguration());

		List<Text> inputList = new ArrayList<Text>();
		inputList.add(new Text("tableName,attempt__0000_m_000000_0_1,655209;1;796764372490213;804422938115889;6"));
		inputList.add(new Text("tableName,attempt__0000_m_000000_0_2,655219;1;796764372490213;804422938115889;6"));
		inputList.add(new Text("tableName,attempt__0000_m_000000_0_3,655249;1;796764372490213;804422938115889;6"));
		reduceDriver.withInput(new Text("/data/raw/ebbs_sg_rowid/rds=2015_03_23_00/ebbs_sg_rowid"), inputList);
		for (Text t : inputList) {
			reduceDriver.addMultiOutput("data", NullWritable.get(), t);
		}
		reduceDriver.withMultiOutput("rowcounts", NullWritable.get(), new Text("raw,ebbs_sg_rowid," + inputList.size()
				+ ",ebbs_sg_rowid," + getTcStartTime() + ",null,attempt__0000_r_000000_0"));
		reduceDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {

		conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWID_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWID_TABLE, "ebbs_sg_rowid");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWID_PARTITION, "(rds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_TABLE, "ebbs_sg_rowhistory");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_PARTITION, "(rhds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH, "/tmp/oozie/rowid02");
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
	}

	private String getTcStartTime() {
		try {
			Class<? extends RowIdReducer> cls = reducer.getClass();
			Field field = cls.getDeclaredField("tcStartTime");
			field.setAccessible(true);
			return (String) field.get(reducer);
		} catch (Exception e) {
			return "";
		}
	}
}
