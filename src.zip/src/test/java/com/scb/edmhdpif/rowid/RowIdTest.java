package com.scb.edmhdpif.rowid;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.input.FileLineWritable;

public class RowIdTest {
	MapDriver<FileLineWritable, Text, Text, Text> mapDriver;

	@Before
	public void setUp() throws IOException {
		RowIdMapper mapper = new RowIdMapper();
		mapDriver = MapDriver.newMapDriver(mapper);
		setConfigParameters(mapDriver.getConfiguration());
	}

	@Test
	public void testMapperOK() throws IOException {

		FileLineWritable fileLine = new FileLineWritable();
		fileLine.setFileName("/data/tableName");
		fileLine.setOffset(0);
		mapDriver.withInput(fileLine, new Text("655209;1;796764372490213;804422938115889;6"));
		mapDriver.withOutput(new Text("/raw/ebbs_sg_rowid/rds=2015_03_23_00/tableName"),
				new Text("tableName,attempt__0000_m_000000_0_1,655209;1;796764372490213;804422938115889;6"));
		mapDriver.withOutput(new Text("/raw/ebbs_sg_rowhistory/rhds=2015_03_23_00/tableName"),
				new Text("attempt__0000_m_000000_0_1,/data/tableName"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperOtherSeparator() throws IOException {
		mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, "�");

		FileLineWritable fileLine = new FileLineWritable();
		fileLine.setFileName("/data/tableName");
		fileLine.setOffset(0);
		mapDriver.withInput(fileLine, new Text("655209�1�796764372490213�804422938115889�6"));
		mapDriver.withOutput(new Text("/raw/ebbs_sg_rowid/rds=2015_03_23_00/tableName"),
				new Text("tableName,attempt__0000_m_000000_0_1,655209�1�796764372490213�804422938115889�6"));
		mapDriver.withOutput(new Text("/raw/ebbs_sg_rowhistory/rhds=2015_03_23_00/tableName"),
				new Text("attempt__0000_m_000000_0_1,/data/tableName"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperOtherSeparator2() throws IOException {
		mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, "^");

		FileLineWritable fileLine = new FileLineWritable();
		fileLine.setFileName("/data/tableName");
		fileLine.setOffset(0);
		mapDriver.withInput(fileLine, new Text("655209^1^796764372490213^804422938115889^6"));
		mapDriver.withOutput(new Text("/raw/ebbs_sg_rowid/rds=2015_03_23_00/tableName"),
				new Text("tableName,attempt__0000_m_000000_0_1,655209^1^796764372490213^804422938115889^6"));
		mapDriver.withOutput(new Text("/raw/ebbs_sg_rowhistory/rhds=2015_03_23_00/tableName"),
				new Text("attempt__0000_m_000000_0_1,/data/tableName"));
		mapDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {
		conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWID_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWID_TABLE, "ebbs_sg_rowid");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWID_PARTITION, "(rds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWID_OUTPUT, "/raw/ebbs_sg_rowid/rds=2015_03_23_00/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_TABLE, "ebbs_sg_rowhistory");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_PARTITION, "(rhds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_ROWHISTORY_OUTPUT, "/raw/ebbs_sg_rowhistory/rhds=2015_03_23_00/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH, "/tmp/oozie/rowid02");
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
		conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");
	}
}
