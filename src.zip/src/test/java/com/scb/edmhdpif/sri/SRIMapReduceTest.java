package com.scb.edmhdpif.sri;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mrunit.mapreduce.MapReduceDriver;
import org.apache.hadoop.mrunit.types.Pair;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;

@PrepareForTest({ SRIMapper.class, SRIReducer.class })
@RunWith(PowerMockRunner.class)
public class SRIMapReduceTest {
	MapReduceDriver<WritableComparable<?>, Text, Text, Text, NullWritable, Writable> mapReduceDriver;
	SRIReducer reducer;

	@Before
	public void setUp() throws IOException {
		SRIMapper mapper = new SRIMapper();
		reducer = new SRIReducer();
		mapReduceDriver = MapReduceDriver.newMapReduceDriver(mapper, reducer);
		setConfigParameters(mapReduceDriver.getConfiguration());
	}

	@Test
	public void testMapReduce() throws IOException {

		mapReduceDriver.withInput(NullWritable.get(),
				new Text("tableName,0_1,journaltime,transactionid,A,userid,col1,col2,col3"));

		mapReduceDriver
				.withMultiOutput("data", NullWritable.get(),
						new Text("tableName,0_1,journaltime,transactionid,B,userid,col1,col2,col3"))
				.withMultiOutput("data", NullWritable.get(), new Text("tableName,0_1")).withMultiOutput("rowcounts",
						NullWritable.get(),
						new Text("raw,ebbs_sg_rowhistory,1,ebbs_sg_rowhistory," + getTcStartTime()));
		List<Pair<NullWritable, Writable>> realOutput = null;
		try {
			realOutput = mapReduceDriver.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
		assert(!realOutput.isEmpty());
	}

	private void setConfigParameters(Configuration conf) {

		conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE, "outopen");
		conf.set(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE, "nonopen");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION, "(ods=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_NONOPEN_PARTITION, "(nds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.keycols", "MYCOL");
		conf.set(
				EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"MYCOL VARCHAR(10) NOT NULL^MYCOL2 VARCHAR(30) NOT NULL^MYCOL3 VARCHAR(10)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");

	}

	private String getTcStartTime() {
		try {
			Class<? extends SRIReducer> cls = reducer.getClass();
			Field field = cls.getDeclaredField("tcStartTime");
			field.setAccessible(true);
			return (String) field.get(reducer);
		} catch (Exception e) {
			return "";
		}
	}
}
