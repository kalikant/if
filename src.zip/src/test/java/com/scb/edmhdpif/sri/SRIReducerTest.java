package com.scb.edmhdpif.sri;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;

@PrepareForTest({ SRIReducer.class })
@RunWith(PowerMockRunner.class)
public class SRIReducerTest {
    ReduceDriver<Text, Text, NullWritable, Writable> reduceDriver;
    SRIReducer reducer;
    Configuration conf;

    @Before
    public void setUp() throws IOException {
        reducer = new SRIReducer();
        reduceDriver = ReduceDriver.newReduceDriver(reducer);
        conf = reduceDriver.getConfiguration();
        setConfigParameters(conf);
    }

    @Test
    public void testReducer_Transition() throws IOException {

        String inputRow = "0_1;journaltime;transactionid;B;userid;col1;col2;col3";
        List<Text> values = new ArrayList<Text>();
        values.add(new Text("tableName;" + inputRow + ";-1;;-1;;"));
        reduceDriver.withInput(new Text("/data/raw/tableName/rds=2015_03_23_00/tableName"), values);

        reduceDriver.withMultiOutput("data", NullWritable.get(),
                new Text(inputRow + ";2015_03_23_00;" + getTcStartTime() + ";-1;;")).withMultiOutput("rowcounts",
                NullWritable.get(),
                new Text("raw,tableName,1,tableName," + getTcStartTime() + ",null,attempt__0000_r_000000_0"));
        reduceDriver.runTest();
    }

    @Test
    public void testReducer_MultiInput() throws IOException {

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:01:15;transactionid;A;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row3 = "2015-06-01 08:02:15;transactionid;A;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row4 = "2015-06-01 08:03:15;transactionid;A;user;USD;12345;127.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row3 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row4 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row1 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row2 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row3 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput("data", NullWritable.get(),
                        new Text("0_1;" + row4 + ";2015_03_23_00;" + tcStartTime + ";;-1;0"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,3,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_MultiInput_PreviousValues() throws IOException {

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:01:15;transactionid;A;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,2015-03-20 20:15:00,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(),
                new Text("0_1;" + row1 + ";2015_03_20_00;2015-03-20 20:15:00;2015_03_23_00;" + tcStartTime + ";0"))
                .withMultiOutput("data", NullWritable.get(),
                        new Text("0_1;" + row2 + ";2015_03_23_00;" + tcStartTime + ";;-1;0"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_MultiInput_SameTime() throws IOException {

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row3 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row4 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;127.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row3 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row4 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row1 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row2 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row3 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput("data", NullWritable.get(),
                        new Text("0_1;" + row4 + ";2015_03_23_00;" + tcStartTime + ";;-1;0"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,3,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_MultiInput_Delete1() throws IOException {

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:01:15;transactionid;D;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row3 = "2015-06-01 08:02:15;transactionid;A;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row4 = "2015-06-01 08:03:15;transactionid;A;user;USD;12345;127.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row3 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row4 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row1 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row2 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";1"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row3 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput("data", NullWritable.get(),
                        new Text("0_1;" + row4 + ";2015_03_23_00;" + tcStartTime + ";;-1;0"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,3,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_MultiInput_Delete2() throws IOException {

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;D;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:01:15;transactionid;A;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row3 = "2015-06-01 08:02:15;transactionid;A;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row4 = "2015-06-01 08:03:15;transactionid;A;user;USD;12345;127.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row3 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row4 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row1 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";1"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row2 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row3 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput("data", NullWritable.get(),
                        new Text("0_1;" + row4 + ";2015_03_23_00;" + tcStartTime + ";;-1;0"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,3,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_MultiInput_Delete3() throws IOException {

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:01:15;transactionid;A;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row3 = "2015-06-01 08:02:15;transactionid;A;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row4 = "2015-06-01 08:03:15;transactionid;D;user;USD;12345;127.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row3 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row4 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row1 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row2 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row3 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row4 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";1"));
        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,4,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_DuplicatedRows() throws IOException {

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:01:15;transactionid2;A;user2;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row3 = "2015-06-01 08:02:15;transactionid3;A;user3;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row4 = "2015-06-01 08:03:15;transactionid4;A;user4;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_2," + row2 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_3," + row3 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_4," + row4 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text("0_1;" + row1 + ";2015_03_23_00;"
                + tcStartTime + ";;-1;0"));
        reduceDriver.withMultiOutput("duplicates", NullWritable.get(), new Text("0_1,0_2,null"));
        reduceDriver.withMultiOutput("duplicates", NullWritable.get(), new Text("0_1,0_3,null"));
        reduceDriver.withMultiOutput("duplicates", NullWritable.get(), new Text("0_1,0_4,null"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE) + ","
                        + conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE) + ",3,ebbs_sg_febal," + tcStartTime
                        + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_DuplicatedRows_Delete() throws IOException {

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:01:15;transactionid2;A;user2;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row3 = "2015-06-01 08:02:15;transactionid3;D;user3;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row4 = "2015-06-01 08:03:15;transactionid4;A;user4;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_2," + row2 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_3," + row3 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_4," + row4 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row1 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_3;" + row3 + ";2015_03_23_00;" + tcStartTime + ";2015_03_23_00;" + tcStartTime
                                + ";1"))
                .withMultiOutput("data", NullWritable.get(),
                        new Text("0_4;" + row4 + ";2015_03_23_00;" + tcStartTime + ";;-1;0"));
        reduceDriver
                .withMultiOutput(
                        "rowcounts",
                        NullWritable.get(),
                        new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                                + tcStartTime + ",null,attempt__0000_r_000000_0"))
                .withMultiOutput(
                        "rowcounts",
                        NullWritable.get(),
                        new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE) + ","
                                + conf.get(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE) + ",1,ebbs_sg_febal,"
                                + tcStartTime + ",null,attempt__0000_r_000000_0"))
                .withMultiOutput(
                        "rowcounts",
                        NullWritable.get(),
                        new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE)
                                + ",ebbs_sg_febal,2,ebbs_sg_febal," + tcStartTime + ",null,attempt__0000_r_000000_0"));
        reduceDriver.withMultiOutput("duplicates", NullWritable.get(), new Text("0_1,0_2,null"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_NoNonOpen() throws IOException {

        conf.unset(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE);

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:01:15;transactionid;A;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,2015-03-20 20:15:00,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text("0_1;" + row2 + ";2015_03_23_00;"
                + tcStartTime + ";;-1;0"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",Non open records,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_NonCDC() throws IOException {

        conf.set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");
        List<Text> values = new ArrayList<Text>();
        String row1 = "USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "USD;12345;124.2;123.2;123.2;123.2;124.2;123.2;13.2;123.2";
        String row3 = "USD;12345;124.2;123.2;123.2;123.2;126.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,2015-03-20 00:02:38,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",2015_03_20_00,2015-03-20 00:02:38,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row3 + ",2015_03_20_00,2015-03-20 00:02:38,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text("0_1;" + row1
                + ";2015_03_20_00;2015-03-20 00:02:38;2015_03_20_00;2015-03-20 00:02:38;0"));
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text("0_1;" + row2
                + ";2015_03_20_00;2015-03-20 00:02:38;2015_03_20_00;2015-03-20 00:02:38;0"));
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text("0_1;" + row3
                + ";2015_03_20_00;2015-03-20 00:02:38;;-1;0"));
        ;
        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));
        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,2,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_NonCDCDiffTime() throws IOException {

        conf.set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");
        List<Text> values = new ArrayList<Text>();
        String row1 = "USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "USD;12345;124.2;123.2;123.2;123.2;124.2;123.2;13.2;123.2";
        String row3 = "USD;12345;124.2;123.2;123.2;123.2;126.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,2015-03-20 00:02:38,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",2015_03_20_00,2015-03-20 00:04:38,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row3 + ",2015_03_20_00,2015-03-20 00:03:38,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row1
                                + ";2015_03_20_00;2015-03-20 00:02:38;2015_03_20_00;2015-03-20 00:03:38;0"))
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text("0_1;" + row3
                                + ";2015_03_20_00;2015-03-20 00:03:38;2015_03_20_00;2015-03-20 00:04:38;0"))
                .withMultiOutput("data", NullWritable.get(),
                        new Text("0_1;" + row2 + ";2015_03_20_00;2015-03-20 00:04:38;;-1;0"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,2,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_NonCDC_NoTime() throws IOException {

        conf.set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");
        List<Text> values = new ArrayList<Text>();
        String row1 = "USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "USD;12345;124.2;123.2;123.2;123.2;124.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,2015-03-20 00:02:38,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(),
                new Text("0_1;" + row1 + ";2015_03_20_00;2015-03-20 00:02:38;2015_03_23_00;" + tcStartTime + ";0"))
                .withMultiOutput("data", NullWritable.get(),
                        new Text("0_1;" + row2 + ";2015_03_23_00;" + tcStartTime + ";;-1;0"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_NonCDC_NoTime_Reverse() throws IOException {

        conf.set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");
        List<Text> values = new ArrayList<Text>();
        String row1 = "USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "USD;12345;124.2;123.2;123.2;123.2;124.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,2015-03-20 00:02:38,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(),
                new Text("0_1;" + row1 + ";2015_03_20_00;2015-03-20 00:02:38;2015_03_23_00;" + tcStartTime + ";0"))
                .withMultiOutput("data", NullWritable.get(),
                        new Text("0_1;" + row2 + ";2015_03_23_00;" + tcStartTime + ";;-1;0"));
        reduceDriver.withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0")).withMultiOutput(
                "rowcounts",
                NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_FullDump_DeletedRow_CDC() throws IOException {

        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
                        + EdmHdpIfConstants.SUFFIX_SRI_FULLDUMP, "true");

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,20150601000000,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text(
                                "0_1;2015-06-01 08:00:15;transactionid;D;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2;2015_03_20_00;20150601000000;2015_03_23_00;"
                                        + tcStartTime + ";1"));
        ;
        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_FullDump_DeletedRow_NonCDC_Flags() throws IOException {

        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
                        + EdmHdpIfConstants.SUFFIX_SRI_FULLDUMP, "true");
        reduceDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");
        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal.deletefield", "CURRENCYCODE");
        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal.deletevalue", "DEL");

        List<Text> values = new ArrayList<Text>();
        String row1 = "USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,20150601000000,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(
                "0_1;DEL;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2;2015_03_20_00;20150601000000;2015_03_23_00;"
                        + tcStartTime + ";1"));
        ;
        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_FullDump_DeletedRow_NonCDC_NoFlags() throws IOException {

        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
                        + EdmHdpIfConstants.SUFFIX_SRI_FULLDUMP, "true");
        reduceDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,20150601000000,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text("0_1;" + row1
                + ";2015_03_20_00;20150601000000;2015_03_23_00;" + tcStartTime + ";1"));
        ;
        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_FullDump_NewRow() throws IOException {

        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
                        + EdmHdpIfConstants.SUFFIX_SRI_FULLDUMP, "true");

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text(
                "0_1;2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2;2015_03_23_00;"
                        + tcStartTime + ";;-1;0"));
        ;
        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_FullDump_UnchangedRow() throws IOException {

        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
                        + EdmHdpIfConstants.SUFFIX_SRI_FULLDUMP, "true");

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,12345678,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text(
                                "0_1;2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2;2015_03_20_00;12345678;;-1;0"));

        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_FullDump_UnchangedRow_NonCDC() throws IOException {

        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
                        + EdmHdpIfConstants.SUFFIX_SRI_FULLDUMP, "true");
        reduceDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,12345678,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text(
                                "0_1;2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2;2015_03_20_00;12345678;;-1;0"));

        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_FullDump_UnchangedRow_NonCDC_ReverseOrder() throws IOException {

        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
                        + EdmHdpIfConstants.SUFFIX_SRI_FULLDUMP, "true");
        reduceDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",,-1,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,12345678,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver
                .withMultiOutput(
                        "data",
                        NullWritable.get(),
                        new Text(
                                "0_1;2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2;2015_03_20_00;12345678;;-1;0"));

        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    @Test
    public void testReducer_FullDump_UpdatedRow() throws IOException {

        reduceDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
                        + EdmHdpIfConstants.SUFFIX_SRI_FULLDUMP, "true");

        List<Text> values = new ArrayList<Text>();
        String row1 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
        String row2 = "2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;456.2;123.2;13.2;123.2";
        values.add(new Text("ebbs_sg_febal,0_1," + row1 + ",2015_03_20_00,12345678,,-1,0"));
        values.add(new Text("ebbs_sg_febal,0_1," + row2 + ",,-1,,-1,0"));

        reduceDriver.withInput(new Text("#ebbs_sg_febal#USD#12345"), values);

        String tcStartTime = getTcStartTime();
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text("0_1;" + row1
                + ";2015_03_20_00;12345678;2015_03_23_00;" + tcStartTime + ";0"));
        reduceDriver.withMultiOutput("data", NullWritable.get(), new Text("0_1;" + row2 + ";2015_03_23_00;"
                + tcStartTime + ";;-1;0"));

        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));
        reduceDriver.withMultiOutput("rowcounts", NullWritable.get(),
                new Text(conf.get(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE) + ",ebbs_sg_febal,1,ebbs_sg_febal,"
                        + tcStartTime + ",null,attempt__0000_r_000000_0"));

        reduceDriver.runTest();
    }

    private void setConfigParameters(Configuration conf) {

        conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
        conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
        conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
        conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
        conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE, "open");
        conf.set(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE, "nonopen");
        conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION, "(ods=2015_03_23_00)");
        conf.set(EdmHdpIfConstants.EDMHDPIF_NONOPEN_PARTITION, "(nds=2015_03_23_00)");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.keycols", "MYCOL");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                "MYCOL VARCHAR(10) NOT NULL^MYCOL2 VARCHAR(30) NOT NULL^MYCOL3 VARCHAR(10)");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal.sourcetype", "delta");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal.keycols", "CURRENCYCODE,ACCOUNTNO");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA, "CURRENCYCODE CHAR(3) NOT NULL^"
                + "ACCOUNTNO CHAR(20) NOT NULL^" + "LEDGERBALANCE DECIMAL(25,3)^" + "FORWARDCREDIT DECIMAL(25,3)^"
                + "FORWARDDEBIT DECIMAL(25,3)^" + "EARMARKCRBALANCE DECIMAL(25,3)^" + "EARMARKDRBALANCE DECIMAL(25,3)^"
                + "TWOINONELMT DECIMAL(25,3)^" + "EODCRAMT DECIMAL(25,3) COMMENT 'EOD CREDIT AMOUNT'^"
                + "EODDRAMT DECIMAL(25,3) COMMENT 'EOD DEBIT AMOUNT'");
        conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
        conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");
        conf.set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "true");
        conf.set(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_DATABASE, "ops");
        conf.set(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_TABLE, "ebbs_sg_duplicatedrows");
        conf.set(EdmHdpIfConstants.EDMHDPIF_DUPLICATEDROWS_PARTITION, "'drds=2015_03_23_00'");
    }

    private String getTcStartTime() {
        try {
            Class<? extends SRIReducer> cls = reducer.getClass();
            Field field = cls.getDeclaredField("tcStartTime");
            field.setAccessible(true);
            return (String) field.get(reducer);
        } catch (Exception e) {
            return "";
        }
    }
}
