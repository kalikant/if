package com.scb.edmhdpif.sri;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;

public class SRIMapperTest {
	MapDriver<WritableComparable<?>, Text, Text, Text> mapDriver;

	@Before
	public void setUp() throws IOException {
		SRIMapper mapper = new SRIMapper();
		mapDriver = MapDriver.newMapDriver(mapper);
		setConfigParameters(mapDriver.getConfiguration());
	}

	@Test
	public void testMapperTransition() throws IOException {

		mapDriver.withInput(NullWritable.get(),
				new Text("tableName,0_1,journaltime;transactionid;A;userid;col1;col2;col3"));
		mapDriver.addOutput(new Text("/data/outopen/tableName/ods=2015_03_23_00/tableName"),
				new Text("tableName;0_1;journaltime;transactionid;A;userid;col1;col2;col3;;-1;;-1;0"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperDelta() throws IOException {

		mapDriver.getConfiguration().set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.sourcetype",
				"delta");
		mapDriver.withInput(NullWritable.get(),
				new Text("tableName,0_1,journaltime;transactionid;A;userid;col1;col2;col3"));
		mapDriver.addOutput(new Text("#tableName#col1"),
				new Text("tableName,0_1,journaltime;transactionid;A;userid;col1;col2;col3,,-1,,-1,0"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperDeltaOneKeyMultiValues() throws IOException {

		String row1 = "ebbs_sg_febal,0_1,2015-06-01 08:00:15;transactionid;B;user;USD;12345;123.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row2 = "ebbs_sg_febal,0_1,2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row3 = "ebbs_sg_febal,0_1,2015-06-01 08:01:15;transactionid;B;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row4 = "ebbs_sg_febal,0_1,2015-06-01 08:01:15;transactionid;A;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row5 = "ebbs_sg_febal,0_1,2015-06-01 08:02:15;transactionid;B;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row6 = "ebbs_sg_febal,0_1,2015-06-01 08:02:15;transactionid;A;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row7 = "ebbs_sg_febal,0_1,2015-06-01 08:03:15;transactionid;B;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row8 = "ebbs_sg_febal,0_1,2015-06-01 08:03:15;transactionid;A;user;USD;12345;127.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		mapDriver.withInput(NullWritable.get(), new Text(row1)).withInput(NullWritable.get(), new Text(row2))
				.withInput(NullWritable.get(), new Text(row3)).withInput(NullWritable.get(), new Text(row4))
				.withInput(NullWritable.get(), new Text(row5)).withInput(NullWritable.get(), new Text(row6))
				.withInput(NullWritable.get(), new Text(row7)).withInput(NullWritable.get(), new Text(row8));
		mapDriver.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row2 + ",,-1,,-1,0"))
				.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row4 + ",,-1,,-1,0"))
				.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row6 + ",,-1,,-1,0"))
				.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row8 + ",,-1,,-1,0"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperDeltaMultiKeys() throws IOException {

		String row1 = "ebbs_sg_febal,0_1,2015-06-01 08:00:15;transactionid;B;user;USD;12345;123.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row2 = "ebbs_sg_febal,0_1,2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row3 = "ebbs_sg_febal,0_1,2015-06-01 08:01:15;transactionid;B;user;EUR;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row4 = "ebbs_sg_febal,0_1,2015-06-01 08:01:15;transactionid;A;user;EUR;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row5 = "ebbs_sg_febal,0_1,2015-06-01 08:02:15;transactionid;B;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row6 = "ebbs_sg_febal,0_1,2015-06-01 08:02:15;transactionid;A;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row7 = "ebbs_sg_febal,0_1,2015-06-01 08:03:15;transactionid;B;user;CHF;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row8 = "ebbs_sg_febal,0_1,2015-06-01 08:03:15;transactionid;A;user;CHF;12345;127.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		mapDriver.withInput(NullWritable.get(), new Text(row1)).withInput(NullWritable.get(), new Text(row2))
				.withInput(NullWritable.get(), new Text(row3)).withInput(NullWritable.get(), new Text(row4))
				.withInput(NullWritable.get(), new Text(row5)).withInput(NullWritable.get(), new Text(row6))
				.withInput(NullWritable.get(), new Text(row7)).withInput(NullWritable.get(), new Text(row8));
		mapDriver.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row2 + ",,-1,,-1,0"))
				.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#EUR#12345"), new Text(row4 + ",,-1,,-1,0"))
				.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row6 + ",,-1,,-1,0"))
				.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#CHF#12345"), new Text(row8 + ",,-1,,-1,0"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperDeltaDelete1() throws IOException {

		String row1 = "ebbs_sg_febal,0_1,2015-06-01 08:00:15;transactionid;D;user;USD;12345;123.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row3 = "ebbs_sg_febal,0_1,2015-06-01 08:01:15;transactionid;B;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row4 = "ebbs_sg_febal,0_1,2015-06-01 08:01:15;transactionid;A;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row5 = "ebbs_sg_febal,0_1,2015-06-01 08:02:15;transactionid;B;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row6 = "ebbs_sg_febal,0_1,2015-06-01 08:02:15;transactionid;A;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		mapDriver.withInput(NullWritable.get(), new Text(row1)).withInput(NullWritable.get(), new Text(row3))
				.withInput(NullWritable.get(), new Text(row4)).withInput(NullWritable.get(), new Text(row5))
				.withInput(NullWritable.get(), new Text(row6));
		mapDriver.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row1 + ",,-1,,-1,0"))
				.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row4 + ",,-1,,-1,0"))
				.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row6 + ",,-1,,-1,0"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperDeltaDelete2() throws IOException {

		String row1 = "ebbs_sg_febal,0_1,2015-06-01 08:00:15;transactionid;B;user;USD;12345;123.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row2 = "ebbs_sg_febal,0_1,2015-06-01 08:00:15;transactionid;A;user;USD;12345;124.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row4 = "ebbs_sg_febal,0_1,2015-06-01 08:01:15;transactionid;D;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row5 = "ebbs_sg_febal,0_1,2015-06-01 08:02:15;transactionid;B;user;USD;12345;125.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		String row6 = "ebbs_sg_febal,0_1,2015-06-01 08:02:15;transactionid;A;user;USD;12345;126.2;123.2;123.2;123.2;123.2;123.2;13.2;123.2";
		mapDriver.withInput(NullWritable.get(), new Text(row1)).withInput(NullWritable.get(), new Text(row2))
				.withInput(NullWritable.get(), new Text(row4)).withInput(NullWritable.get(), new Text(row5))
				.withInput(NullWritable.get(), new Text(row6));
		mapDriver.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row2 + ",,-1,,-1,0"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row4 + ",,-1,,-1,0"))
				.withOutput(new Text("#BValues#"), new Text("ebbs_sg_febal"))
				.withOutput(new Text("#ebbs_sg_febal#USD#12345"), new Text(row6 + ",,-1,,-1,0"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperOperationTypeB() throws IOException {

		mapDriver.getConfiguration().set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.sourcetype",
				"delta");

		mapDriver.withInput(NullWritable.get(),
				new Text("tableName,0_1,journaltime;transactionid;B;userid;col1;col2;col3"));
		mapDriver.withOutput(new Text("#BValues#"), new Text("tableName"));
		mapDriver.runTest();
	}

	@Test
	public void testMapper_NonCDCData() throws IOException {

		mapDriver.getConfiguration().set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.sourcetype",
				"delta");
		mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");
		mapDriver.withInput(NullWritable.get(), new Text("tableName,0_1,col1;col2;col3"));
		mapDriver.withInput(NullWritable.get(), new Text("tableName,0_1,col1;col3;col4"));
		mapDriver.withInput(NullWritable.get(), new Text("tableName,0_1,col1;col4;col5"));
		mapDriver.addOutput(new Text("#tableName#col1"), new Text("tableName,0_1,col1;col2;col3,,-1,,-1,0"));
		mapDriver.addOutput(new Text("#tableName#col1"), new Text("tableName,0_1,col1;col3;col4,,-1,,-1,0"));
		mapDriver.addOutput(new Text("#tableName#col1"), new Text("tableName,0_1,col1;col4;col5,,-1,,-1,0"));
		mapDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {

		conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE, "outopen");
		conf.set(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE, "nonopen");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION, "(ods=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_NONOPEN_PARTITION, "(nds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.keycols", "MYCOL");
		conf.set(
				EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"MYCOL VARCHAR(10) NOT NULL^MYCOL2 VARCHAR(30) NOT NULL^MYCOL3 VARCHAR(10)");
		conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal.sourcetype", "delta");
		conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal.keycols", "CURRENCYCODE,ACCOUNTNO");
		conf.set(
				EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "ebbs_sg_febal"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"CURRENCYCODE CHAR(3) NOT NULL^" + "ACCOUNTNO CHAR(20) NOT NULL^" + "LEDGERBALANCE DECIMAL(25,3)^"
						+ "FORWARDCREDIT DECIMAL(25,3)^" + "FORWARDDEBIT DECIMAL(25,3)^"
						+ "EARMARKCRBALANCE DECIMAL(25,3)^" + "EARMARKDRBALANCE DECIMAL(25,3)^"
						+ "TWOINONELMT DECIMAL(25,3)^" + "EODCRAMT DECIMAL(25,3) COMMENT 'EOD CREDIT AMOUNT'^"
						+ "EODDRAMT DECIMAL(25,3) COMMENT 'EOD DEBIT AMOUNT'");
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
		conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");
		conf.set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "true");

	}
}
