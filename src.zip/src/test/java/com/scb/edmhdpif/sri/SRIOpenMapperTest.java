package com.scb.edmhdpif.sri;

import static org.mockito.Mockito.when;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.input.FileLineWritable;
import com.scb.edmhdpif.sri.mock.SRIMockInputSplit;

public class SRIOpenMapperTest {
	MapDriver<WritableComparable<?>, Text, Text, Text> mapDriver;

	@Before
	public void setUp() throws IOException {
		SRIOpenMapper mapper = new SRIOpenMapper();
		mapDriver = MapDriver.newMapDriver(mapper);
		setConfigParameters(mapDriver.getConfiguration());
	}

	@Test
	public void testMapperDelta() throws IOException {

		when(mapDriver.getContext().getInputSplit()).thenAnswer(new Answer<InputSplit>() {
			@Override
			public InputSplit answer(InvocationOnMock invocation) throws Throwable {
				return new SRIMockInputSplit(new Path("/data/outopen/tableName/ods=2015_03_22_00/part-r-00000"));
			}
		});

		FileLineWritable flw = new FileLineWritable();
		flw.setOffset(0);
		flw.setFileName("/data/tableName/vds=2015_03_23_00/part-r-00000");
		mapDriver.getConfiguration().set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.sourcetype",
				"delta");
		mapDriver.withInput(NullWritable.get(),
				new Text("0_1;journaltime;transactionid;A;userid;col1;col2;col3;2015_03_22_00;1431434325;;-1;0"));
		mapDriver.addOutput(new Text("#tableName#col1"), new Text(
				"tableName,0_1,journaltime;transactionid;A;userid;col1;col2;col3,2015_03_22_00,1431434325,,-1,0"));
		mapDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {

		conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_DATABASE, "outopen");
		conf.set(EdmHdpIfConstants.EDMHDPIF_NONOPEN_DATABASE, "nonopen");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OPEN_PARTITION, "(ods=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_NONOPEN_PARTITION, "(nds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.keycols", "MYCOL");
		conf.set(
				EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
						+ EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
				"MYCOL VARCHAR(10) NOT NULL^MYCOL2 VARCHAR(30) NOT NULL^MYCOL3 VARCHAR(10)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
		conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");
		conf.set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "true");

	}
}
