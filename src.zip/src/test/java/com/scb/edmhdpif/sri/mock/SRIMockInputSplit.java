package com.scb.edmhdpif.sri.mock;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

public class SRIMockInputSplit extends FileSplit {

	private final Path path;

	public SRIMockInputSplit(Path mockPath) {
		super(mockPath, 0, 0, (String[]) null);
		path = mockPath;
	}

	@Override
	public String toString() {
		return path.toString();
	}
}
