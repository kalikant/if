package com.scb.edmhdpif.verify;

import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.verifytypes.VerifyTypesMapper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

public class VerifyTypesTest {
    MapDriver<WritableComparable<?>, Text, Text, Text> mapDriver;
    private Object obj;

    @Before
    public void setUp() throws IOException {
        VerifyTypesMapper mapper = new VerifyTypesMapper();
        mapDriver = MapDriver.newMapDriver(mapper);
        setConfigParameters(mapDriver.getConfiguration());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof VerifyTypesTest))
            return false;

        VerifyTypesTest that = (VerifyTypesTest) o;

        if (!mapDriver.equals(that.mapDriver))
            return false;
        return obj.equals(that.obj);

    }

    @Override
    public int hashCode() {
        int result = mapDriver.hashCode();
        result = 31 * result + obj.hashCode();
        return result;
    }

    @Test
    public void testMapperCharOK() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableChar,0_1,journaltime;transactionid;operationtype;userid;0123456789;123"));
        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableChar"), new Text(
                "tableChar,0_1,journaltime;transactionid;operationtype;userid;0123456789;123"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperCharFail() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableChar,0_1,journaltime;transactionid;operationtype;userid;655209;1"));
        mapDriver
                .addOutput(
                        new Text("/raw/ebbs_sg_invalidtypes/vds=2015_03_23_00/tableChar"),
                        new Text(
                                "tableChar,0_1,journaltime;transactionid;operationtype;userid;655209;1,ERROR: '655209' for column 'MYCOL' not of type CHAR(10), type enforced='655209    ';ERROR: '1' for column 'MYCOL2' not of type CHAR(3), type enforced='1  '"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperVarCharOK() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableVarChar,0_1,journaltime;transactionid;operationtype;userid;0123456789;123"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableVarChar"), new Text(
                "tableVarChar,0_1,journaltime;transactionid;operationtype;userid;0123456789;123"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperVarCharOKOtherSeparator() throws IOException {

        mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, "^");
        mapDriver.withInput(NullWritable.get(), new Text(
                "tableVarChar,0_1,journaltime^transactionid^operationtype^userid^0123456789^123"));
        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableVarChar"), new Text(
                "tableVarChar,0_1,journaltime^transactionid^operationtype^userid^0123456789^123"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperVarCharFail() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableVarChar,0_1,journaltime;transactionid;operationtype;userid;655fasdfasdf209;asdfasd1"));

        mapDriver
                .withOutput(
                        new Text("/raw/ebbs_sg_invalidtypes/vds=2015_03_23_00/tableVarChar"),
                        new Text(
                                "tableVarChar,0_1,journaltime;transactionid;operationtype;userid;655fasdfasdf209;asdfasd1,ERROR: '655fasdfasdf209' for column 'MYCOL' not of type VARCHAR(10), type enforced='655fasdfas';ERROR: 'asdfasd1' for column 'MYCOL2' not of type VARCHAR(3), type enforced='asd'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDecimalOK() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableDecimal,0_1,journaltime;transactionid;operationtype;userid;12345;12.123"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableDecimal"), new Text(
                "tableDecimal,0_1,journaltime;transactionid;operationtype;userid;12345;12.123"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDecimal0OK() throws IOException {
        mapDriver.withInput(NullWritable.get(), new Text(
                "tableDecimal,0_1,journaltime;transactionid;operationtype;userid;12345;0.123"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableDecimal"), new Text(
                "tableDecimal,0_1,journaltime;transactionid;operationtype;userid;12345;0.123"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDecimalWithZeros() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableDecimal,0_1,journaltime;transactionid;operationtype;userid;12345.00;012.120"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableDecimal"), new Text(
                "tableDecimal,0_1,journaltime;transactionid;operationtype;userid;12345;12.12"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDecimalNoDecimalPart() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableDecimalND,0_1,journaltime;transactionid;operationtype;userid;12345;121"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableDecimalND"), new Text(
                "tableDecimalND,0_1,journaltime;transactionid;operationtype;userid;12345;121"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDecimalFail() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableDecimal,0_1,journaltime;transactionid;operationtype;userid;aaaa;2342343"));

        mapDriver
                .addOutput(
                        new Text("/raw/ebbs_sg_invalidtypes/vds=2015_03_23_00/tableDecimal"),
                        new Text(
                                "tableDecimal,0_1,journaltime;transactionid;operationtype;userid;aaaa;2342343,ERROR: 'aaaa' for column 'MYCOL' not of type DECIMAL(10,2), type enforced='null';ERROR: '2342343' for column 'MYCOL2' not of type DECIMAL(5,3), type enforced='null'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDateOK() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableDate,0_1,journaltime;transactionid;operationtype;userid;2015-01-01;2016-03-12"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableDate"), new Text(
                "tableDate,0_1,journaltime;transactionid;operationtype;userid;2015-01-01;2016-03-12"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDateFail() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableDate,0_1,journaltime;transactionid;operationtype;userid;655209;2016-02-30"));
        mapDriver
                .addOutput(
                        new Text("/raw/ebbs_sg_invalidtypes/vds=2015_03_23_00/tableDate"),
                        new Text(
                                "tableDate,0_1,journaltime;transactionid;operationtype;userid;655209;2016-02-30,ERROR: '655209' for column 'MYCOL' not of type DATE, type enforced='null';ERROR: '2016-02-30' for column 'MYCOL2' not of type DATE, type enforced='2016-03-01'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDateFail2() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableDate,0_1,journaltime;transactionid;operationtype;userid;2015-01-01;1911-00-01"));
        mapDriver
                .addOutput(
                        new Text("/raw/ebbs_sg_invalidtypes/vds=2015_03_23_00/tableDate"),
                        new Text(
                                "tableDate,0_1,journaltime;transactionid;operationtype;userid;2015-01-01;1911-00-01,ERROR: '1911-00-01' for column 'MYCOL2' not of type DATE, type enforced='null'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperDateFail3() throws IOException {

        mapDriver
                .getConfiguration()
                .set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableDate"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                        "RECORD_IDENTIFIER VARCHAR(1) NOT NULL COMMENT 'Record Identifier'^MB_AMASS_DAYS BIGINT COMMENT 'days of net balance'^MB_DEPKIND BIGINT NOT NULL COMMENT 'account branch+product code'^MB_ACNO DECIMAL(9,0) NOT NULL COMMENT 'account no.'^IDNOF VARCHAR(10) COMMENT 'Customer ID no'^IDNOL VARCHAR(1) COMMENT 'the last number of customer ID'^MB_AREA VARCHAR(1) COMMENT 'area of opening'^MB_OLD_BAL DECIMAL(19,2) COMMENT 'Previous Day Balance'^MB_AMASS DECIMAL(20,0) COMMENT 'Net balaces'^MB_DISHONOR_QTY BIGINT COMMENT 'Bounce Check Count'^MB_CANCEL_QTY BIGINT COMMENT 'Mark Check Count'^MB_LAST_AMASS_YMD DATE COMMENT 'Net Balance for Calculation Date' RULES Replace('0',''),DateYYYMMDD^MB_OPEN_YMD DATE COMMENT 'Open Date' RULES Replace('0',''),DateYYYMMDD^MB_BUSINESS_KIND BIGINT COMMENT 'The kind of business'^MB_PERID BIGINT COMMENT 'Referral ID'^MB_CANCEL VARCHAR(1) COMMENT 'account status'^MB_TX_KIND VARCHAR(1) COMMENT 'the type of organization'^MB_BIRTH_YMD DATE COMMENT 'birthday' RULES Replace('0',''),DateYYYMMDD^MB_CM_IDNO VARCHAR(11) COMMENT 'comany president's ID'^MB_CM_NAME VARCHAR(35) COMMENT 'comany president's name'^DV_ACNO DECIMAL(20,0) NOT NULL COMMENT 'Derived Account Number Field'^DV_IDNO VARCHAR(13) NOT NULL COMMENT 'Derived ID Number Field'");

        mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "false");

        mapDriver
                .withInput(
                        NullWritable.get(),
                        new Text(
                                "tableDate,0_1,D;0;4050;638;22683817;;3;24151.00;0;0;0;961231;781125;10602;7417;;4;11111;H100400008;�XX;4050000000638;22683817"));
        mapDriver
                .addOutput(
                        new Text("/raw/ebbs_sg_invalidtypes/vds=2015_03_23_00/tableDate"),
                        new Text(
                                "tableDate,0_1,D;0;4050;638;22683817;;3;24151;0;0;0;961231;781125;10602;7417;;4;11111;H100400008;�XX;4050000000638;22683817,ERROR: '961231' for column 'MB_LAST_AMASS_YMD' not of type DATE, type enforced='null';ERROR: '781125' for column 'MB_OPEN_YMD' not of type DATE, type enforced='null';ERROR: '11111' for column 'MB_BIRTH_YMD' not of type DATE, type enforced='null'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperIntOK() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableInt,0_1,journaltime;transactionid;operationtype;userid;2134;22"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableInt"), new Text(
                "tableInt,0_1,journaltime;transactionid;operationtype;userid;2134;22"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperIntWithZerosOK() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableInt,0_1,journaltime;transactionid;operationtype;userid;0004423;000"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableInt"), new Text(
                "tableInt,0_1,journaltime;transactionid;operationtype;userid;4423;0"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperIntFail() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableInt,0_1,journaltime;transactionid;operationtype;userid;adsfa;adsfas"));
        mapDriver
                .addOutput(
                        new Text("/raw/ebbs_sg_invalidtypes/vds=2015_03_23_00/tableInt"),
                        new Text(

                                "tableInt,0_1,journaltime;transactionid;operationtype;userid;adsfa;adsfas,ERROR: 'adsfa' for column 'MYCOL' not of type INT, type enforced='null';ERROR: 'adsfas' for column 'MYCOL2' not of type INT, type enforced='null'"));
        mapDriver.runTest();

    }

    @Test
    public void testDefaultValueSubstitution() throws IOException {
        mapDriver.withInput(NullWritable.get(), new Text(
                "tableReplaceNullwithDefault,0_1,MYCOL1;MYCOL2;MYCOL3;MYCOL4;;"));
        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableReplaceNullwithDefault"),
                new Text("tableReplaceNullwithDefault,0_1,MYCOL1;MYCOL2;MYCOL3;MYCOL4;2658922;2658922,WARNING"));
        mapDriver.addOutput(new Text("/raw/ebbs_sg_warntypes/wds=2015_03_23_00/tableReplaceNullwithDefault"), new Text(
                "tableReplaceNullwithDefault,0_1,MYCOL1;MYCOL2;MYCOL3;MYCOL4;2658922;2658922,WARNING"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperBigIntOK() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableBigInt,0_1,journaltime;transactionid;operationtype;userid;2134;22"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableBigInt"), new Text(
                "tableBigInt,0_1,journaltime;transactionid;operationtype;userid;2134;22"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperBigIntWithZerosOK() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableBigInt,0_1,journaltime;transactionid;operationtype;userid;000442030;00200"));

        mapDriver.addOutput(new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableBigInt"), new Text(
                "tableBigInt,0_1,journaltime;transactionid;operationtype;userid;442030;200"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperBigIntFail() throws IOException {

        mapDriver.withInput(NullWritable.get(), new Text(
                "tableBigInt,0_1,journaltime;transactionid;operationtype;userid;adsfa;adsfas"));
        mapDriver
                .addOutput(
                        new Text("/raw/ebbs_sg_invalidtypes/vds=2015_03_23_00/tableBigInt"),
                        new Text(
                                "tableBigInt,0_1,journaltime;transactionid;operationtype;userid;adsfa;adsfas,ERROR: 'adsfa' for column 'MYCOL' not of type BIGINT, type enforced='null';ERROR: 'adsfas' for column 'MYCOL2' not of type BIGINT, type enforced='null'"));
        mapDriver.runTest();
    }

    @Test
    public void testMapperEOD() throws IOException {

        mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_EOD_MARKER, "2015-03-23T00:25:00Z");
        mapDriver.getConfiguration().set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.keycols", "MYCOL");
        mapDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                "MYCOL VARCHAR(10) NOT NULL^MYCOL2 VARCHAR(30) NOT NULL^MYCOL3 VARCHAR(10)");
        mapDriver.getConfiguration().set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.sourcetype",
                "delta");

        mapDriver
                .withInput(
                        NullWritable.get(),
                        new Text("tableName,0_1,2015-03-23T00:10:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withInput(
                        NullWritable.get(),
                        new Text("tableName,0_1,2015-03-23T00:20:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withInput(
                        NullWritable.get(),
                        new Text("tableName,0_1,2015-03-23T00:30:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withInput(
                        NullWritable.get(),
                        new Text("tableName,0_1,2015-03-23T01:30:00Z;transactionid;operationtype;userid;col1;col2;col3"));

        mapDriver
                .withOutput(
                        new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableName"),
                        new Text("tableName,0_1,2015-03-23T00:10:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withOutput(
                        new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableName"),
                        new Text("tableName,0_1,2015-03-23T00:20:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withOutput(
                        new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableName"
                                + EdmHdpIfConstants.SUFFIX_EOD_VERIFYTYPES_FILES),
                        new Text("tableName,0_1,2015-03-23T00:30:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withOutput(
                        new Text("/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/tableName"
                                + EdmHdpIfConstants.SUFFIX_EOD_VERIFYTYPES_FILES),
                        new Text("tableName,0_1,2015-03-23T01:30:00Z;transactionid;operationtype;userid;col1;col2;col3"));
        mapDriver.runTest();

    }

    @Test
    public void testMapperEODMultipleTables() throws IOException {

        mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_EOD_MARKER, "2015-03-23T00:25:00Z");
        mapDriver.getConfiguration().set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.keycols", "MYCOL");
        mapDriver.getConfiguration().set(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_VALID, "/raw/");
        mapDriver.getConfiguration().set(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_INVALID, "/raw/");
        mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_ONETABLE, "false");
        mapDriver.getConfiguration().set(
                EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName"
                        + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                "MYCOL VARCHAR(10) NOT NULL^MYCOL2 VARCHAR(30) NOT NULL^MYCOL3 VARCHAR(10)");
        mapDriver.getConfiguration().set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.sourcetype",
                "delta");

        mapDriver
                .withInput(
                        NullWritable.get(),
                        new Text("tableName,0_1,2015-03-23T00:10:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withInput(
                        NullWritable.get(),
                        new Text("tableName,0_1,2015-03-23T00:20:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withInput(
                        NullWritable.get(),
                        new Text("tableName,0_1,2015-03-23T00:30:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withInput(
                        NullWritable.get(),
                        new Text("tableName,0_1,2015-03-23T01:30:00Z;transactionid;operationtype;userid;col1;col2;col3"));

        mapDriver
                .withOutput(new Text("/raw/tableName/vds=2015_03_23_00/tableName"),
                        new Text("0_1;2015-03-23T00:10:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withOutput(new Text("/raw/tableName/vds=2015_03_23_00/tableName"),
                        new Text("0_1;2015-03-23T00:20:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withOutput(new Text("/raw/tableName/vds=2015_03_23_00/tableName"),
                        new Text("0_1;2015-03-23T00:30:00Z;transactionid;operationtype;userid;col1;col2;col3"))
                .withOutput(new Text("/raw/tableName/vds=2015_03_23_00/tableName"),
                        new Text("0_1;2015-03-23T01:30:00Z;transactionid;operationtype;userid;col1;col2;col3"));
        mapDriver.runTest();
    }

    private void setConfigParameters(Configuration conf) {
        conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
        conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
        conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
        conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_DATABASE, "raw");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_TABLE, "ebbs_sg_verifytypes");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_VALIDTYPES_PARTITION, "(vds=2015_03_23_00)");
        conf.set(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_VALID, "/raw/ebbs_sg_verifytypes/vds=2015_03_23_00/");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_DATABASE, "raw");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_TABLE, "ebbs_sg_invalidtypes");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_INVALIDTYPES_PARTITION, "(vds=2015_03_23_00)");
        conf.set(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_INVALID, "/raw/ebbs_sg_invalidtypes/vds=2015_03_23_00/");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_DATABASE, "raw");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_TABLE, "ebbs_sg_warntypes");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_WARNTYPES_PARTITION, "(wds=2015_03_23_00)");
        conf.set(EdmHdpIfConstants.VERIFYTYPES_OUTPUT_WARN, "/raw/ebbs_sg_warntypes/wds=2015_03_23_00/");
        conf.set("mapreduce.output.fileoutputformat.outputdir", "/tmp/");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableChar"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA, "MYCOL CHAR(10) NOT NULL^MYCOL2 CHAR(3) NOT NULL");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableVarChar"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA, "MYCOL VARCHAR(10) NOT NULL^MYCOL2 VARCHAR(3) NOT NULL");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableDecimal"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                "MYCOL DECIMAL(10,2) NOT NULL^MYCOL2 DECIMAL(5,3) NOT NULL");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableDecimalND"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA, "MYCOL DECIMAL(10) NOT NULL^MYCOL2 DECIMAL(5) NOT NULL");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableDate"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA, "MYCOL DATE^MYCOL2 DATE");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableInt"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA, "MYCOL INT NOT NULL^MYCOL2 INT NOT NULL");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableBigInt"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA, "MYCOL BIGINT NOT NULL^MYCOL2 BIGINT NOT NULL");
        conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableReplaceNullwithDefault"
                + EdmHdpIfConstants.SUFFIX_CONFIG_COLSCHEMA,
                "MYCOL BIGINT NOT NULL DEFAULT 2658922^MYCOL2 BIGINT NOT NULL DEFAULT 2658922");
        conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
        conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");
        conf.set(EdmHdpIfConstants.EDMHDPIF_CDCCOLUMNS, "true");
        conf.set(EdmHdpIfConstants.EDMHDPIF_TYPEVALIDATOR_ONETABLE, "true");
    }

    /*
     * public int hashCode() { final int prime = 31; int result = 1; result =
     * prime * result + ((firstName == null) ? 0 : firstName.hashCode()); result
     * = prime * result + ((lastName == null) ? 0 : lastName.hashCode()); return
     * result; }
     * 
     * @Override /* public boolean equals(Object obj) { if (this == obj) return
     * true; if (obj == null) return false; if (getClass() != obj.getClass())
     * return false; String inputPath=mapDriver.getMapInputPath().toString();
     * String outputPath=mapDriver.getExpectedOutputs().toString(); if
     * (inputPath == null) { if (inputPath != null) return false; } else if
     * (!inputPath.equals(outputPath)) return false; if (outputPath == null) {
     * if (outputPath != null) return false; } else if
     * (!lastName.equals(other.lastName)) return false; return true; }
     */
}
