package com.scb.edmhdpif.verify;

import com.scb.edmhdpif.verifytypes.checker.VerifySchemaColumn;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FunctionUnitTests {

	final String varcharType = "CITYNAME VARCHAR(50)";
	final String dateType = "MAKERDATE DATE";
	/*
	 * Since Hive date verification uses a ThreadLocal TimeZone variable, it is
	 * needed to run the TimeZone tests in different threads to ensure the
	 * validity of the tests
	 */
	private static ExecutorService threadpool = Executors.newFixedThreadPool(100);

	@Test
	public void extendedASCIITest1() throws IOException {
		VerifySchemaColumn v = new VerifySchemaColumn(varcharType);

		String row = (new StringBuilder("HOLB")).append((char) 195).append("K").toString();
		String error = v.verify(row);
		if (error.contains("ERROR"))
			Assert.assertNull(error);
	}

	@Test
	public void extendedASCIITest2() throws IOException {
		VerifySchemaColumn v = new VerifySchemaColumn(varcharType);

		String row = (new StringBuilder("BANCO CREDICOOP")).append((char) 194).append((char) 166).toString();
		String error = v.verify(row);
		if (error.contains("ERROR"))
			Assert.assertNull(error);
	}

	@Test
	public void extendedASCIITest3() throws IOException {
		VerifySchemaColumn v = new VerifySchemaColumn(varcharType);
		String row = (new StringBuilder("6G Europ")).append((char) 239).append((char) 191).append((char) 189)
				.append("e Organisation zur SicLuftfahrt").toString();
		String error = v.verify(row);
		if (error.contains("ERROR"))
			Assert.assertNull(error);
	}

	@Test
	public void replaceNullValueTest() throws IOException {
		VerifySchemaColumn v = new VerifySchemaColumn(varcharType);
		String buf[] = varcharType.split("\\s");
		v.setDefaultValue(buf[0], "Tampines");
		String error = v.verify("");
		if (error.contains("ERROR"))
			Assert.assertNull(error);
	}

	@Test
	public void nullValueErrorTest() throws IOException {
		VerifySchemaColumn v = new VerifySchemaColumn(varcharType);
		String error = v.verify(null);
		Assert.assertNull(error);
	}

	@Test
	public void specialDatesTest() throws InterruptedException, ExecutionException {

		DateTzTesting task = new DateTzTesting("1973-04-22", "Asia/Hong_Kong");
		String error = threadpool.submit(task).get();
		if (error == null)
			Assert.assertNull(error);
	}

	@Test
	public void specialDatesTest2() throws InterruptedException, ExecutionException {
		DateTzTesting task = new DateTzTesting("1941-12-25", "Asia/Hong_Kong");
		String error = threadpool.submit(task).get();
		if (error == null)
			Assert.assertNull(error);
	}

	@Test
	public void specialDatesTestAllHongKong() throws InterruptedException, ExecutionException {
		DateTzTestingAll task = new DateTzTestingAll("Asia/Hong_Kong");
		String error = threadpool.submit(task).get();
		if (error == null)
			Assert.assertNull(error);
	}

	@Test
	public void specialDatesTestAllSydney() throws InterruptedException, ExecutionException {
		DateTzTestingAll task = new DateTzTestingAll("Australia/Sydney");
		String error = threadpool.submit(task).get();
		if (error == null)
			Assert.assertNull(error);
	}

	@Test
	public void specialDatesTestAllJerusalem() throws InterruptedException, ExecutionException {
		DateTzTestingAll task = new DateTzTestingAll("Asia/Jerusalem");
		String error = threadpool.submit(task).get();
		if (error == null)
			Assert.assertNull(error);
	}

	@Test
	public void wrongDate() throws IOException {
		VerifySchemaColumn v = new VerifySchemaColumn(dateType);

		String row = "1973-02-31";
		String error = v.verify(row);

		Assert.assertEquals(error,
				"ERROR: '1973-02-31' for column 'MAKERDATE' not of type DATE, type enforced='1973-03-03'");
	}

	class DateTzTesting implements Callable<String> {

		private final String date;
		private final String timezone;

		public DateTzTesting(String date, String timezone) {
			this.date = date;
			this.timezone = timezone;
		}

		@Override
		public String call() throws Exception {
			VerifySchemaColumn v = new VerifySchemaColumn(dateType);

			TimeZone defaultTz = TimeZone.getDefault();
			TimeZone tz = TimeZone.getTimeZone(timezone);
			TimeZone.setDefault(tz);
			String error = v.verify(date);

			TimeZone.setDefault(defaultTz);
			return error;
		}

	}

	class DateTzTestingAll implements Callable<String> {

		private final String timezone;

		public DateTzTestingAll(String timezone) {
			this.timezone = timezone;
		}

		@Override
		public String call() throws Exception {
			VerifySchemaColumn v = new VerifySchemaColumn(dateType);

			TimeZone defaultTz = TimeZone.getDefault();
			TimeZone tz = TimeZone.getTimeZone(timezone);
			TimeZone.setDefault(tz);

			Calendar c = Calendar.getInstance(tz);
			c.clear();
			c.setTimeZone(tz);
			c.set(Calendar.YEAR, 1900);
			c.set(Calendar.MONTH, Calendar.JANUARY);
			c.set(Calendar.DAY_OF_MONTH, 1);
			Calendar today = Calendar.getInstance(tz);

			java.sql.Date date = new java.sql.Date(c.getTimeInMillis());
			try {
				while (c.before(today)) {
					String error = v.verify(date.toString());

					if (error != null) {
						return error;
					}
					c.add(Calendar.DAY_OF_MONTH, 1);
					date = new java.sql.Date(c.getTimeInMillis());
				}
			} finally {
				TimeZone.setDefault(defaultTz);
			}
			return null;
		}

	}
}