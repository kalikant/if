package com.scb.edmhdpif.containervalidator;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpif.containervalidation.HeaderAndTrailerMapper;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;
import com.scb.edmhdpif.lib.input.FileLineWritable;

public class HeaderAndTrailerMapperTest {
	MapDriver<FileLineWritable, Text, Text, Text> mapDriver;

	@Before
	public void setUp() throws IOException {
		HeaderAndTrailerMapper mapper = new HeaderAndTrailerMapper();
		mapDriver = MapDriver.newMapDriver(mapper);
		setConfigParameters(mapDriver.getConfiguration());
	}

	@Test
	public void testMapperWithSeparator() throws IOException {

		FileLineWritable fileLine = new FileLineWritable();
		fileLine.setFileName("/data/tableName");
		fileLine.setOffset(0);
		mapDriver.withInput(fileLine, new Text("H;12345678;1150718;"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("T;000000004;"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("-4"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperWithSeparator_EmtpyCols() throws IOException {

		FileLineWritable fileLine = new FileLineWritable();
		fileLine.setFileName("/data/tableName");
		fileLine.setOffset(0);
		mapDriver.withInput(fileLine, new Text("H;;1150718;"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("T;000000004;"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("-4"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperNoSeparator() throws IOException {

		FileLineWritable fileLine = new FileLineWritable();
		fileLine.setFileName("/data/tableName");
		fileLine.setOffset(0);
		mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_FIXWIDTH, "true");

		mapDriver.withInput(fileLine, new Text("H123456781150718"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("T000000004"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("-4"));
		mapDriver.runTest();
	}

	@Test
	public void testMapperInvalidDate() throws IOException {

		FileLineWritable fileLine = new FileLineWritable();
		fileLine.setFileName("/data/tableName");
		fileLine.setOffset(0);
		mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_FIXWIDTH, "true");

		mapDriver.withInput(fileLine, new Text("H123456781151518"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("T000000004"));
		mapDriver.withOutput(new Text("/data/tableName"),
				new Text("Date validation error: 1151518 is not a valid date masked by CYYMMDD"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("-4"));

		mapDriver.runTest();
	}

	@Test
	public void testMapperNothingToValidate() throws IOException {

		FileLineWritable fileLine = new FileLineWritable();
		fileLine.setFileName("/data/tableName");
		fileLine.setOffset(0);
		mapDriver.getConfiguration().set(EdmHdpIfConstants.EDMHDPIF_FIXWIDTH, "true");
		mapDriver.getConfiguration().set("edmhdpif.header.HeaderType1",
				"Record_type char(1)^FileId Char(8)^Efective_date Num(7) MASK CYYMMDD^Filler Varchar");

		mapDriver.getConfiguration().set("edmhdpif.trailer.TrailerType1",
				"Record_type char(1)^Record_count Num(9)^Filler Varchar");


		mapDriver.withInput(fileLine, new Text("H123456781151518"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("D;655209;1;796764372490213;804422938115889;6"));
		mapDriver.withInput(fileLine, new Text("T000000004"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));
		mapDriver.withOutput(new Text("/data/tableName"), new Text("1"));

		mapDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {
		conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.header", "HeaderType1");
		conf.set("edmhdpif.header.HeaderType1",
				"Record_type char(1)^FileId Char(8)^Efective_date Num(7) MASK CYYMMDD VALIDATEDATE^Filler Varchar");

		conf.set(EdmHdpIfConstants.PREFIX_CONFIG_EDMHDPIF_TABLE + "tableName.trailer", "TrailerType1");
		conf.set("edmhdpif.trailer.TrailerType1",
				"Record_type char(1)^Record_count Num(9) VALIDATEROWCOUNT^Filler Varchar");

		conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH, "/tmp/oozie/rowid02");
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
		conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");
	}
}
