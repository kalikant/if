package com.scb.edmhdpif.containervalidator;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;

import com.scb.edmhdpif.containervalidation.HeaderAndTrailerReducer;
import com.scb.edmhdpif.lib.EdmHdpIfConstants;

public class HeaderAndTrailerReducerTest {
	ReduceDriver<Text, Text, NullWritable, Text> reduceDriver;
	HeaderAndTrailerReducer reducer;

	@Before
	public void setUp() throws IOException {
		reducer = new HeaderAndTrailerReducer();
		reduceDriver = ReduceDriver.newReduceDriver(reducer);
	}

	@Test
	public void testReducerOK() throws IOException {
		setConfigParameters(reduceDriver.getConfiguration());

		List<Text> inputList = new ArrayList<>();
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("-4"));
		reduceDriver.withInput(new Text("/data/tableName"), inputList);
		reduceDriver.withOutput(NullWritable.get(),
				new Text("/data/tableName,true,,2015-03-23," + getTcStartTime() + ",null,attempt__0000_r_000000_0"));
		reduceDriver.runTest();
	}

	@Test
	public void testReducerCountError() throws IOException {
		setConfigParameters(reduceDriver.getConfiguration());

		List<Text> inputList = new ArrayList<>();
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("-4"));
		reduceDriver.withInput(new Text("/data/tableName"), inputList);
		reduceDriver.withOutput(NullWritable.get(),
				new Text("/data/tableName,false,Number of rows does not match the expected number of rows 4,2015-03-23,"
						+ getTcStartTime() + ",null,attempt__0000_r_000000_0"));
		reduceDriver.runTest();
	}

	@Test
	public void testReducerOneErrorOneOk() throws IOException {
		setConfigParameters(reduceDriver.getConfiguration());

		List<Text> inputList = new ArrayList<>();
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("-4"));
		reduceDriver.withInput(new Text("/data/tableName"), inputList);
		List<Text> inputErrorList = new ArrayList<>();
		inputErrorList.add(new Text("error"));
		reduceDriver.withInput(new Text("/data/tableName2"), inputErrorList);
		reduceDriver.withOutput(NullWritable.get(),
				new Text("/data/tableName,true,,2015-03-23," + getTcStartTime() + ",null,attempt__0000_r_000000_0"));
		reduceDriver.withOutput(NullWritable.get(), new Text(
				"/data/tableName2,false,error,2015-03-23," + getTcStartTime() + ",null,attempt__0000_r_000000_0"));
		reduceDriver.runTest();
	}

	@Test
	public void testReducerTwoErrorsOneOK() throws IOException {
		setConfigParameters(reduceDriver.getConfiguration());

		List<Text> inputList = new ArrayList<>();
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("-4"));
		reduceDriver.withInput(new Text("/data/tableName"), inputList);
		List<Text> inputErrorList = new ArrayList<>();
		inputErrorList.add(new Text("error"));
		inputErrorList.add(new Text("error2"));
		reduceDriver.withInput(new Text("/data/tableName2"), inputErrorList);
		reduceDriver.withOutput(NullWritable.get(),
				new Text("/data/tableName,true,,2015-03-23," + getTcStartTime() + ",null,attempt__0000_r_000000_0"));
		reduceDriver.withOutput(NullWritable.get(), new Text("/data/tableName2,false,error;error2,2015-03-23,"
				+ getTcStartTime() + ",null,attempt__0000_r_000000_0"));
		reduceDriver.runTest();
	}

	@Test
	public void testReducerNoValidation() throws IOException {
		setConfigParameters(reduceDriver.getConfiguration());

		List<Text> inputList = new ArrayList<>();
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		inputList.add(new Text("1"));
		reduceDriver.withInput(new Text("/data/tableName"), inputList);
		reduceDriver.withOutput(NullWritable.get(),
				new Text("/data/tableName,true,,2015-03-23," + getTcStartTime() + ",null,attempt__0000_r_000000_0"));
		reduceDriver.runTest();
	}

	private void setConfigParameters(Configuration conf) {

		conf.set(EdmHdpIfConstants.EDMHDPIF_HIVE_WAREHOUSE, "/data/");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_DATABASE, "raw");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_TABLE, "ebbs_sg");
		conf.set(EdmHdpIfConstants.EDMHDPIF_INPUT_PARTITION, "(ds=2015_03_23_00)");
		conf.set(EdmHdpIfConstants.EDMHDPIF_SRI_NEXTWORKINGDATE, "2015-03-23");
		conf.set(EdmHdpIfConstants.EDMHDPIF_OUTPUT_PATH, "/tmp/oozie/rowid02");
		conf.set(EdmHdpIfConstants.EDMHDPIF_COLSEPARATOR, ",");
		conf.set(EdmHdpIfConstants.EDMHDPIF_DATASEPARATOR, ";");
	}

	private String getTcStartTime() {
		try {
			Class<? extends HeaderAndTrailerReducer> cls = reducer.getClass();
			Field field = cls.getDeclaredField("tcStartTime");
			field.setAccessible(true);
			return (String) field.get(reducer);
		} catch (Exception e) {
			return "";
		}
	}
}
